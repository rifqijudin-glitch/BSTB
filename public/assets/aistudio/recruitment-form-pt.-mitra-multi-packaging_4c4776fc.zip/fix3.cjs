const fs = require('fs');
let code = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

const regex = /{new Date\(\)\.getFullYear\(\)} HCGA PT\. Mitra Multi Packaging/;
code = code.replace(regex, 'Copyright - HCGA PT. Mitra Multi Packaging');

fs.writeFileSync('src/pages/FormPage.tsx', code);
