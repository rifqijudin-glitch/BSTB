const fs = require('fs');
let code = fs.readFileSync('src/components/FormStep2.tsx', 'utf8');

const replacement = `                            {tingkat === 'SLTA/SMU' ? (
                                <select className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_smu">
                                    <option value="">-- Pilih Jurusan --</option>
                                    <option value="MIPA">MIPA</option>
                                    <option value="IPS">IPS</option>
                                    <option value="Ekonomi">Ekonomi</option>
                                    <option value="Bahasa dan Budaya">Bahasa dan Budaya</option>
                                    <option value="Teknik Konstruksi dan Perumahan">Teknik Konstruksi dan Perumahan</option>
                                    <option value="Teknik Geomatika dan Geospasial">Teknik Geomatika dan Geospasial</option>
                                    <option value="Teknik Ketenagalistrikan">Teknik Ketenagalistrikan</option>
                                    <option value="Teknik Mesin">Teknik Mesin</option>
                                    <option value="Teknik Otomotif">Teknik Otomotif</option>
                                    <option value="Teknik Elektronika">Teknik Elektronika</option>
                                    <option value="Teknik Perkapalan">Teknik Perkapalan</option>
                                    <option value="Pengembangan Perangkat Lunak dan Gim (PPLG)">Pengembangan Perangkat Lunak dan Gim (PPLG)</option>
                                    <option value="Teknik Jaringan Komputer dan Telekomunikasi (TJKT)">Teknik Jaringan Komputer dan Telekomunikasi (TJKT)</option>
                                    <option value="Layanan Kesehatan">Layanan Kesehatan</option>
                                    <option value="Farmasi">Farmasi</option>
                                    <option value="Pekerjaan Sosial">Pekerjaan Sosial</option>
                                    <option value="Akuntansi dan Keuangan Lembaga (AKL)">Akuntansi dan Keuangan Lembaga (AKL)</option>
                                    <option value="Manajemen Perkantoran dan Layanan Bisnis (MPLB)">Manajemen Perkantoran dan Layanan Bisnis (MPLB)</option>
                                    <option value="Pemasaran">Pemasaran</option>
                                    <option value="Kuliner">Kuliner</option>
                                    <option value="Perhotelan">Perhotelan</option>
                                    <option value="Usaha Layanan Pariwisata">Usaha Layanan Pariwisata</option>
                                    <option value="Tata Kecantikan dan Rambut">Tata Kecantikan dan Rambut</option>
                                    <option value="Tata Busana">Tata Busana</option>
                                    <option value="Desain Komunikasi Visual (DKV)">Desain Komunikasi Visual (DKV)</option>
                                    <option value="Animasi">Animasi</option>
                                    <option value="Penyiaran dan Produksi Film">Penyiaran dan Produksi Film</option>
                                    <option value="Seni Pertunjukan">Seni Pertunjukan</option>
                                    <option value="Kriya Kreatif">Kriya Kreatif</option>
                                    <option value="Agribisnis Tanaman">Agribisnis Tanaman</option>
                                    <option value="Agribisnis Ternak">Agribisnis Ternak</option>
                                    <option value="Agriteknologi Pengolahan Hasil Pertanian (APHP)">Agriteknologi Pengolahan Hasil Pertanian (APHP)</option>
                                    <option value="Kehutanan">Kehutanan</option>
                                    <option value="Nautika Kapal Penangkap Ikan / Niaga">Nautika Kapal Penangkap Ikan / Niaga</option>
                                    <option value="Teknika Kapal Penangkap Ikan / Niaga">Teknika Kapal Penangkap Ikan / Niaga</option>
                                    <option value="Mesin kapal.Agribisnis Perikanan">Mesin kapal.Agribisnis Perikanan</option>
                                    <option value="Teknik Perminyakan">Teknik Perminyakan</option>
                                    <option value="Teknik Pertambangan">Teknik Pertambangan</option>
                                    <option value="Teknik Kimia Industri">Teknik Kimia Industri</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                            ) : (tingkat === 'S1' || tingkat === 'D1/D2/D3') ? (
                                <select className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_s1">
                                    <option value="">-- Pilih Jurusan --</option>
                                    <option value="Pendidikan Dokter">Pendidikan Dokter</option>
                                    <option value="Pendidikan Dokter Gigi">Pendidikan Dokter Gigi</option>
                                    <option value="Kedokteran Hewan">Kedokteran Hewan</option>
                                    <option value="Ilmu Keperawatan">Ilmu Keperawatan</option>
                                    <option value="Kebidanan">Kebidanan</option>
                                    <option value="Farmasi">Farmasi</option>
                                    <option value="Kesehatan Masyarakat">Kesehatan Masyarakat</option>
                                    <option value="Gizi Kesehatan">Gizi Kesehatan</option>
                                    <option value="Fisioterapi">Fisioterapi</option>
                                    <option value="Okupasi Terapi">Okupasi Terapi</option>
                                    <option value="Sains Kedokteran Tropis">Sains Kedokteran Tropis</option>
                                    <option value="Keselamatan dan Kesehatan Kerja">Keselamatan dan Kesehatan Kerja</option>
                                    <option value="Teknik Sipil">Teknik Sipil</option>
                                    <option value="Teknik Arsitektur">Teknik Arsitektur</option>
                                    <option value="Teknik Mesin">Teknik Mesin</option>
                                    <option value="Teknik Elektro">Teknik Elektro</option>
                                    <option value="Teknik Kimia">Teknik Kimia</option>
                                    <option value="Teknik Industri">Teknik Industri</option>
                                    <option value="Teknik Lingkungan">Teknik Lingkungan</option>
                                    <option value="Teknik Perencanaan Wilayah dan Kota">Teknik Perencanaan Wilayah dan Kota</option>
                                    <option value="Teknik Metalurgi dan Material">Teknik Metalurgi dan Material</option>
                                    <option value="Teknik Dirgantara">Teknik Dirgantara</option>
                                    <option value="Teknik Kelautan">Teknik Kelautan</option>
                                    <option value="Teknik Nuklir">Teknik Nuklir</option>
                                    <option value="Teknik Biomedis">Teknik Biomedis</option>
                                    <option value="Teknik Informatika">Teknik Informatika</option>
                                    <option value="Sistem Informasi">Sistem Informasi</option>
                                    <option value="Ilmu Komputer">Ilmu Komputer</option>
                                    <option value="Sains Data">Sains Data</option>
                                    <option value="Keamanan Siber">Keamanan Siber</option>
                                    <option value="Rekayasa Perangkat Lunak">Rekayasa Perangkat Lunak</option>
                                    <option value="Matematika">Matematika</option>
                                    <option value="Fisika">Fisika</option>
                                    <option value="Kimia">Kimia</option>
                                    <option value="Biologi">Biologi</option>
                                    <option value="Astronomi">Astronomi</option>
                                    <option value="Geofisika">Geofisika</option>
                                    <option value="Meteorologi">Meteorologi</option>
                                    <option value="Statistika">Statistika</option>
                                    <option value="Aktuaria">Aktuaria</option>
                                    <option value="Agroteknologi">Agroteknologi</option>
                                    <option value="Agribisnis">Agribisnis</option>
                                    <option value="Ilmu Kelautan">Ilmu Kelautan</option>
                                    <option value="Oseanografi">Oseanografi</option>
                                    <option value="Teknologi Pangan">Teknologi Pangan</option>
                                    <option value="Manajemen Sumberdaya Perairan">Manajemen Sumberdaya Perairan</option>
                                    <option value="Kehutanan">Kehutanan</option>
                                    <option value="Hubungan Internasional">Hubungan Internasional</option>
                                    <option value="Ilmu Komunikasi">Ilmu Komunikasi</option>
                                    <option value="Jurnalistik">Jurnalistik</option>
                                    <option value="Penyiaran">Penyiaran</option>
                                    <option value="Hubungan Masyarakat">Hubungan Masyarakat</option>
                                    <option value="Ilmu Pemerintahan">Ilmu Pemerintahan</option>
                                    <option value="Ilmu Politik">Ilmu Politik</option>
                                    <option value="Sosiologi">Sosiologi</option>
                                    <option value="Antropologi Sosial">Antropologi Sosial</option>
                                    <option value="Ilmu Administrasi Publik">Ilmu Administrasi Publik</option>
                                    <option value="Ilmu Administrasi Bisnis">Ilmu Administrasi Bisnis</option>
                                    <option value="Kriminologi">Kriminologi</option>
                                    <option value="Psikologi">Psikologi</option>
                                    <option value="Akuntansi">Akuntansi</option>
                                    <option value="Manajemen">Manajemen</option>
                                    <option value="Manajemen Keuangan">Manajemen Keuangan</option>
                                    <option value="Manajemen Pemasaran">Manajemen Pemasaran</option>
                                    <option value="Manajemen Sumber Daya Manusia">Manajemen Sumber Daya Manusia</option>
                                    <option value="Ilmu Ekonomi">Ilmu Ekonomi</option>
                                    <option value="Ekonomi Pembangunan">Ekonomi Pembangunan</option>
                                    <option value="Ekonomi Syariah">Ekonomi Syariah</option>
                                    <option value="Perbankan Syariah">Perbankan Syariah</option>
                                    <option value="Ilmu Hukum">Ilmu Hukum</option>
                                    <option value="Hukum Perdata">Hukum Perdata</option>
                                    <option value="Hukum Pidana">Hukum Pidana</option>
                                    <option value="Hukum Internasional">Hukum Internasional</option>
                                    <option value="Hukum Tata Negara">Hukum Tata Negara</option>
                                    <option value="Sastra Inggris">Sastra Inggris</option>
                                    <option value="Sastra Indonesia">Sastra Indonesia</option>
                                    <option value="Sastra Jepang">Sastra Jepang</option>
                                    <option value="Sastra Arab">Sastra Arab</option>
                                    <option value="Sastra Korea">Sastra Korea</option>
                                    <option value="Sastra Mandarin">Sastra Mandarin</option>
                                    <option value="Linguistik">Linguistik</option>
                                    <option value="Ilmu Sejarah">Ilmu Sejarah</option>
                                    <option value="Arkeologi">Arkeologi</option>
                                    <option value="Ilmu Filsafat">Ilmu Filsafat</option>
                                    <option value="Desain Interior">Desain Interior</option>
                                    <option value="Desain Produk">Desain Produk</option>
                                    <option value="Seni Rupa Murni">Seni Rupa Murni</option>
                                    <option value="Fotografi">Fotografi</option>
                                    <option value="Etnomusikologi">Etnomusikologi</option>
                                    <option value="Penciptaan Musik">Penciptaan Musik</option>
                                    <option value="Seni Teater">Seni Teater</option>
                                    <option value="Pendidikan Guru Sekolah Dasar">Pendidikan Guru Sekolah Dasar</option>
                                    <option value="Pendidikan Guru Anak Usia Dini">Pendidikan Guru Anak Usia Dini</option>
                                    <option value="Pendidikan Luar Biasa">Pendidikan Luar Biasa</option>
                                    <option value="Bimbingan dan Konseling">Bimbingan dan Konseling</option>
                                    <option value="Pendidikan Bahasa Indonesia">Pendidikan Bahasa Indonesia</option>
                                    <option value="Pendidikan Bahasa Inggris">Pendidikan Bahasa Inggris</option>
                                    <option value="Pendidikan Matematika">Pendidikan Matematika</option>
                                    <option value="Pendidikan Fisika">Pendidikan Fisika</option>
                                    <option value="Pendidikan Kimia">Pendidikan Kimia</option>
                                    <option value="Pendidikan Biologi">Pendidikan Biologi</option>
                                    <option value="Pendidikan Sejarah">Pendidikan Sejarah</option>
                                    <option value="Pendidikan Geografi">Pendidikan Geografi</option>
                                    <option value="Pendidikan Ekonomi">Pendidikan Ekonomi</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                            ) : tingkat === 'S2/S3' ? (
                                <select className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_s2">
                                    <option value="">-- Pilih Program Studi --</option>
                                    <option value="Magister Manajemen">Magister Manajemen</option>
                                    <option value="Magister Hukum">Magister Hukum</option>
                                    <option value="Magister Ilmu Komunikasi">Magister Ilmu Komunikasi</option>
                                    <option value="Magister Administrasi Publik">Magister Administrasi Publik</option>
                                    <option value="Magister Teknik Sipil">Magister Teknik Sipil</option>
                                    <option value="Magister Kenotariatan">Magister Kenotariatan</option>
                                    <option value="Magister Psikologi Profesi">Magister Psikologi Profesi</option>
                                    <option value="Doktor Ilmu Hukum">Doktor Ilmu Hukum</option>
                                    <option value="Doktor Ilmu Ekonomi">Doktor Ilmu Ekonomi</option>
                                    <option value="Doktor Ilmu Manajemen">Doktor Ilmu Manajemen</option>
                                    <option value="Doktor Ilmu Sosial">Doktor Ilmu Sosial</option>
                                    <option value="Lainnya">Lainnya</option>
                                </select>
                            ) : (`;

const regex = /                            \{tingkat === 'SLTA\/SMU' \? \([\s\S]*?Lainnya<\/option>\s*<\/select>\s*\)\s*:\s*\(/;

if (regex.test(code)) {
    code = code.replace(regex, replacement);
    fs.writeFileSync('src/components/FormStep2.tsx', code);
    console.log("Success");
} else {
    console.log("Regex missed");
}
