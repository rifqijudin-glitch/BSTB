const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const target = `             matchEdu = appliedEduFilters.some(filter => {
                return rows.some((row: string) => {
                   const cols = row.split(' | ');
                   if (cols.length >= 4) {
                       const tingkatMatch = !filter.tingkat || filter.tingkat === 'Semua' || cols[0].trim() === filter.tingkat;
                       const jurusanMatch = !filter.jurusan || cols[3].toLowerCase().includes(filter.jurusan.toLowerCase());
                       return tingkatMatch && jurusanMatch;
                   }
                   return false;
                });
             });`;

const replacement = `             matchEdu = appliedEduFilters.some(filter => {
                let highestMatch = false;
                if (!filter.tingkat || filter.tingkat === 'Semua') {
                    highestMatch = true;
                } else {
                    const mappedTingkat: Record<string, string> = {
                        'SD': 'SD/Sederajat',
                        'SLTP': 'SMP/SLTP',
                        'SLTA/SMU/SMK': 'SMA/SMK/SLTA',
                        'SLTA/SMU': 'SMA/SMK/SLTA'
                    };
                    const expectedPendidikan = mappedTingkat[filter.tingkat] || filter.tingkat;
                    highestMatch = (app.pendidikan === expectedPendidikan);
                }

                if (!highestMatch) return false;

                return rows.some((row: string) => {
                   const cols = row.split(' | ');
                   if (cols.length >= 4) {
                       let rowTingkat = cols[0].trim();
                       if (rowTingkat === 'SLTA/SMU') rowTingkat = 'SLTA/SMU/SMK'; // handle historic data
                       
                       const targetFilterTingkat = filter.tingkat === 'SLTA/SMU' ? 'SLTA/SMU/SMK' : filter.tingkat;
                       const tingkatMatch = !targetFilterTingkat || targetFilterTingkat === 'Semua' || rowTingkat === targetFilterTingkat;
                       
                       const jurusanMatch = !filter.jurusan || cols[3].toLowerCase().includes(filter.jurusan.toLowerCase());
                       return tingkatMatch && jurusanMatch;
                   }
                   return false;
                });
             });`;

if (code.includes('return rows.some((row: string) => {')) {
    code = code.replace(target, replacement);
    fs.writeFileSync('src/pages/DashboardPage.tsx', code);
    console.log('Replaced successfully');
} else {
    console.log('Target not found');
}
