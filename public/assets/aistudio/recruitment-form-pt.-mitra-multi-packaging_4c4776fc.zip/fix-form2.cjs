const fs = require('fs');

let c2 = fs.readFileSync('src/components/FormStep2.tsx', 'utf8');

c2 = c2.replace(/<input type="text" list="jurusan_smu_list"/g, '<><input type="text" list="jurusan_smu_list"');
c2 = c2.replace(/<\/datalist>\n                            \) : \(tingkat === 'S1' \|\| tingkat === 'D1\/D2\/D3'\)/g, '</datalist></>\n                            ) : (tingkat === \'S1\' || tingkat === \'D1/D2/D3\')');

// Better to just rewrite correctly! Let's do it clean:
c2 = c2.replace(/<><input/g, '<input');
c2 = c2.replace(/<\/datalist><\/>/g, '</datalist>');


// Let's use string manipulation to wrap datalist and input in Fragments
c2 = c2.replace(/(<input type="text" list="jurusan_(smu|s1|pilihan)_list"[\s\S]*?<\/datalist>)/g, '<>$1</>');

fs.writeFileSync('src/components/FormStep2.tsx', c2);
console.log("Fixed FormStep2!");
