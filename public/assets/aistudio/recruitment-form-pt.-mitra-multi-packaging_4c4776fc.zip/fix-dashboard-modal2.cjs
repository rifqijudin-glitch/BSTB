const fs = require('fs');
let d = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

// The modal mapping block:
// return (
//    <div key={key} className="flex flex-col border-b border-gray-100 pb-2">
//       <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">{key}</span>
//       <FormatAsReactTable text={String(value)} />
//    </div>
// );

const mapStart = /return \(\n\s*<div key=\{key\} className="flex flex-col border-b border-gray-100 pb-2">/g;

const modalImageCode = `
                              if (key === 'foto_pelamar' && value && String(value).startsWith('data:image')) {
                                 return (
                                    <div key={key} className="flex flex-col border-b border-gray-100 pb-2">
                                       <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">Foto Pelamar</span>
                                       <img src={String(value)} alt="Foto Pelamar" className="max-h-48 max-w-xs rounded shadow-sm border mt-1" />
                                    </div>
                                 );
                              }
                              if (key === 'cv_pelamar') {
                                 return (
                                     <div key={key} className="flex flex-col border-b border-gray-100 pb-2">
                                       <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">CV Pelamar</span>
                                       <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium border border-green-200 self-start mt-1">Dilampirkan (CV format PDF disubmit)</span>
                                    </div>
                                 );
                              }
                              
                              let displayValue = value;
                              if (key === 'Tanggal Lahir') displayValue = formatTanggalLahirIndo(String(value));
                              if (key === 'Timestamp (Waktu Submit)') {
                                 displayValue = formatDateTimeIndo(String(value));
                              }
                              
                              return (
                                 <div key={key} className="flex flex-col border-b border-gray-100 pb-2">`;

d = d.replace(mapStart, modalImageCode);

// After replacement, we need to change `<FormatAsReactTable text={String(value)} />` to displayValue.
// Wait! `FormatAsReactTable` takes text={String(value)}!
// I'll replace `text={String(value)}` with `text={String(displayValue)}`!

d = d.replace(/<FormatAsReactTable text=\{String\(value\)\} \/>/g, '<FormatAsReactTable text={String(displayValue)} />');

fs.writeFileSync('src/pages/DashboardPage.tsx', d);
console.log('Fixed Modal Detail UI');
