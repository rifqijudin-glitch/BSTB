fetch('https://sheetdb.io/api/v1/g6pseexgmqoyq/Timestamp%20(Waktu%20Submit)/' + encodeURIComponent('6/3/2026, 14:41:59'), {method: 'DELETE'})
  .then(r=>r.json())
  .then(console.log);
