const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', error => console.log('PAGE ERROR:', error.message));

  await page.goto('http://localhost:3000/form');
  
  // Wait for the button
  await page.waitForSelector('button');
  
  // Click Next until reaching step 5
  for (let i = 0; i < 4; i++) {
     try {
       await page.evaluate(() => {
          const buttons = Array.from(document.querySelectorAll('button'));
          const nextBtn = buttons.find(b => b.textContent && b.textContent.includes('Selanjutnya'));
          if (nextBtn) nextBtn.click();
       });
       await new Promise(r => setTimeout(r, 500));
       const stepText = await page.evaluate(() => {
          return document.body.innerText.includes('Kuesioner') ? 'Reached Kuesioner' : 'Not there';
       });
       console.log('Step ' + (i+2) + ' Text Check:', stepText);
       
       const errorBoundary = await page.evaluate(() => {
          return document.body.innerText.includes('Something went wrong') ? 'CRASHED' : 'FINE';
       });
       if (errorBoundary === 'CRASHED') {
          console.log('CRASH DETECTED');
       }
     } catch (e) {
       console.log("Error clicking next:", e);
     }
  }
  
  await new Promise(r => setTimeout(r, 1000));
  await browser.close();
})();
