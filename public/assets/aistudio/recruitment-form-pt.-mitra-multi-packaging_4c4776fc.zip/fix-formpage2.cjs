const fs = require('fs');
let text = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

text = text.replace(/if \([^)]+\) \{\n\s*input\.required = isFieldRequired;\n\s*\}/g, match => {
   return `if (input.hasAttribute('disabled')) isFieldRequired = false;\n             ${match}`;
});

fs.writeFileSync('src/pages/FormPage.tsx', text);
