const ts = '6/3/2026, 15:26:53';
fetch('https://sheetdb.io/api/v1/g6pseexgmqoyq/Timestamp (Waktu Submit)/' + encodeURIComponent(ts) + '?sheet=Sheet1', {method: 'DELETE'})
  .then(r=>r.json())
  .then(console.log);
