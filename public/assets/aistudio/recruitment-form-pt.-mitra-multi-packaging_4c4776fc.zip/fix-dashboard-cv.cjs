const fs = require('fs');
let d = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const regexKTP = /if \(actionName === 'Lihat KTP'\) \{[\s\S]*?\} else if \(actionName === 'Lihat cv pelamar'\) \{[\s\S]*?\}\s*\}/;

const newHandler = `if (actionName === 'Lihat cv pelamar') {
        const cvData = app.rawData?.['cv_pelamar'];
        if (cvData && cvData.startsWith('data:application/pdf')) {
            const pdfWindow = window.open("");
            if(pdfWindow) {
               pdfWindow.document.write("<iframe width='100%' height='100%' src='" + cvData + "'></iframe><style>body{margin:0;overflow:hidden;}</style>");
            }
        } else {
            setViewFileModal({
               isOpen: true,
               title: \`CV - \${app.nama}\`,
               content: \`CV Tidak tersedia atau bukan format PDF.\`
            });
        }
    }`;

d = d.replace(regexKTP, newHandler);
fs.writeFileSync('src/pages/DashboardPage.tsx', d);

// Fix bug in formstep1 mapping
let c1 = fs.readFileSync('src/components/FormStep1.tsx', 'utf8');
c1 = c1.replace('<option value="Belum Sekolah">Belum Sekolah</option>', '');
c1 = c1.replace('<option value="Lainnya">Lainnya</option>', '');
c1 = c1.replace('<option value="S3">S3</option>', '<option value="S3">S3</option>\n                              <option value="Belum Sekolah">Belum Sekolah</option>\n                              <option value="Lainnya">Lainnya</option>');
// wait, I already added it once. Better not duplicate it.
// I will not touch formStep1 since it worked.
