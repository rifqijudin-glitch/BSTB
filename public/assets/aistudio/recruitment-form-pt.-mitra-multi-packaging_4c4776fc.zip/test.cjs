const { JSDOM } = require("jsdom");
const dom = new JSDOM(`
<table>
  <tbody class="table-pendidikan">
    <tr>
      <td>SD</td>
      <td><input type="text" value="SMA 1" /></td>
      <td><input type="text" value="" /></td>
    </tr>
    <tr>
      <td>SMP</td>
      <td><input type="text" value="" /></td>
      <td><input type="text" value="" /></td>
    </tr>
  </tbody>
</table>
`);
const document = dom.window.document;
const table = document.querySelector('.table-pendidikan');
const rows = Array.from(table.querySelectorAll('tr'));
const rowsData = rows.map((tr) => {
    const cols = Array.from(tr.querySelectorAll('td'));
    const rowValues = cols.map((td) => {
        const tdInputs = Array.from(td.querySelectorAll('input, select, textarea'));
        if (tdInputs.length > 0) {
            const activeInputs = tdInputs.filter(i => (i.type === 'radio' || i.type === 'checkbox') ? i.checked : true);
            if (activeInputs.length > 0) {
                return activeInputs.map(i => i.value.trim()).filter(v => v !== '').join(', ');
            }
            return ""; 
        }
        return td.textContent?.trim() || "";
    });
    return rowValues.join(' | ');
}).filter(rowStr => rowStr && rowStr.replace(/ \| /g, '').trim() !== "");

console.log(rowsData);
