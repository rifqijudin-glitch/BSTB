fetch('https://sheetdb.io/api/v1/g6pseexgmqoyq/Nama%20Lengkap/Judin%20Alfatah', {method: 'DELETE'})
  .then(r=>r.json())
  .then(console.log);
