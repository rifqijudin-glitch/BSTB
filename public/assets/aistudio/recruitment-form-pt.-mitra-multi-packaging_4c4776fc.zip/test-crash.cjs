const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  const logs = [];
  page.on('console', msg => logs.push(msg.text()));
  page.on('pageerror', error => logs.push(error.message));

  await page.goto('http://localhost:3000/form');
  
  await page.waitForSelector('button');
  
  for (let i = 0; i < 4; i++) {
       await page.evaluate(() => {
          const buttons = Array.from(document.querySelectorAll('button'));
          const nextBtn = buttons.find(b => b.textContent && b.textContent.includes('Selanjutnya'));
          if (nextBtn) nextBtn.click();
       });
       await new Promise(r => setTimeout(r, 500));
  }
  
  const text = await page.evaluate(() => document.body.innerText);
  console.log("PAGE TEXT:", text);
  console.log("PAGE LOGS:", logs);
  
  await browser.close();
})();
