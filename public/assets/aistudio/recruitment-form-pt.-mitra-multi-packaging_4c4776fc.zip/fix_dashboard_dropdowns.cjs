const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const JOB_OPTIONS = [
    "DIREKTUR PABRIKASI", "DIREKTUR UTAMA", "GENERAL MANAGER", "IT, TEKNIK MANAGER", "SUPPLY CHAIN MANAGER",
    "QA MANAGER", "PRODUKSI MANAGER", "SALES MANAGER", "HCGA MANAGER", "FAT MANAGER", "PROCUREMENT MANAGER",
    "TEKNIK SUPERVISOR", "PRODUKSI SUPERVISOR", "QC SUPERVISOR", "WAREHOUSE SUPERVISOR", "LABORATORIUM SUPERVISOR",
    "PPIC SUPERVISOR", "R & D SUPERVISOR", "QMS SUPERVISOR", "FINANCE SUPERVISOR", "STAFF COLOR MATCHING",
    "OPERATOR TINTA", "OPERATOR PRINTING", "OPERATOR DRY", "OPERATOR SLITTING", "OPERATOR REWIND",
    "OPERATOR INSPECTION", "OPERATOR BAG MAKING", "INSPEKTOR LAMINASI", "INSPEKTOR PRINTING",
    "INSPEKTOR SLITTING", "INSPEKTOR BAG MAKING", "STAFF ADMIN QA", "INSPEKTOR LAB", "STAFF TEKNIK",
    "CORPORATE SALES", "STAFF ADMIN SALES", "STAFF CASHIER", "STAFF ADMIN GA", "STAFF ADMIN PRODUKSI LAPANGAN",
    "STAFF HUMAS", "STAFF ADMIN HC", "STAFF ADMIN INVENTORY", "STAFF ADMIN WAREHOUSE FG",
    "STAFF ADMIN SUPPLY CHAIN", "STAFF ADMIN PPIC", "STAFF ADMIN PRODUKSI SYSTEM", "STAFF ADMIN ACCOUNTING",
    "STAFF ADMIN TEKNIK & IT", "STAFF ADMIN WAREHOUSE RM", "STAFF ADMIN CYLINDER", "STAFF ADMIN TAX",
    "STAFF ADMIN PROCUREMENT", "STAFF SMO"
];

// 1. Add JOB_OPTIONS const
code = code.replace(/const JURUSAN_S2 = \[([^\]]+)\];/, "const JURUSAN_S2 = [$1];\nconst JOB_OPTIONS = " + JSON.stringify(JOB_OPTIONS) + ";");

// 2. Replace input in quick filter (line 793-799 approx)
const quickFilterRegex = /<input\s+type="text"\s+placeholder="Posisi yg dilamar"\s+className="border border-gray-300 rounded px-2 py-1\.5 text-xs outline-none bg-white text-gray-700 w-full md:w-48 focus:border-blue-500"\s+value=\{posisiFilterDropdown\}\s+onChange=\{\(e\) => setPosisiFilterDropdown\(e\.target\.value\)\}\s+\/>/;

const quickFilterReplacement = `<select 
                        value={posisiFilterDropdown}
                        onChange={(e) => setPosisiFilterDropdown(e.target.value)}
                        className="border border-gray-300 rounded px-2 py-1.5 text-xs outline-none bg-white text-gray-700 w-full md:w-48 focus:border-blue-500"
                     >
                        <option value="">Semua Posisi</option>
                        {JOB_OPTIONS.map(job => <option key={job} value={job}>{job}</option>)}
                     </select>`;

code = code.replace(quickFilterRegex, quickFilterReplacement);

// 3. Replace input in advanced filter (line 1097 approx)
const modalFilterRegex = /<input type="text" value=\{posisiFilterDropdown\} onChange=\{e => setPosisiFilterDropdown\(e\.target\.value\)\} placeholder="Ketik kata kunci opsi posisi\.\.\." className="border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500 w-full" \/>/;

const modalFilterReplacement = `<select value={posisiFilterDropdown} onChange={e => setPosisiFilterDropdown(e.target.value)} className="border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500 w-full">
                        <option value="">Semua Posisi</option>
                        {JOB_OPTIONS.map(job => <option key={job} value={job}>{job}</option>)}
                     </select>`;

code = code.replace(modalFilterRegex, modalFilterReplacement);


// 4. Update the select for Jurusan in Advanced Filter
const oldSelect = /<select value=\{ef\.jurusan\}[^>]*>\s*<option value="">Semua Jurusan<\/option>\s*\{activeJurusanList\.map\(jur => <option key=\{jur\} value=\{jur\}>\{jur\}<\/option>\)\}\s*<\/select>/;

const newSelect = `
                                     {ef.tingkat === 'SLTA/SMU' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_SMU.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : (ef.tingkat === 'S1' || ef.tingkat === 'D1/D2/D3') ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_S1.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : ef.tingkat === 'S2/S3' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_S2.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : ef.tingkat === 'Semua' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {activeJurusanList.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : (
                                        <input type="text" value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} placeholder="Ketik jurusan..." className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border" />
                                     )}
`;

code = code.replace(oldSelect, newSelect.trim());

fs.writeFileSync('src/pages/DashboardPage.tsx', code);
