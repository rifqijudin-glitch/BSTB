const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  await page.setViewport({ width: 1280, height: 800 });
  await page.goto('http://localhost:3000/form');
  
  await page.waitForSelector('button');
  
  // Click Next 4 times
  for (let i = 0; i < 4; i++) {
       await page.evaluate(() => {
          const buttons = Array.from(document.querySelectorAll('button'));
          const nextBtn = buttons.find(b => b.textContent && b.textContent.includes('Selanjutnya'));
          if (nextBtn) nextBtn.click();
       });
       await new Promise(r => setTimeout(r, 500));
  }
  
  await page.screenshot({ path: 'step5.png' });
  
  const errorBoundary = await page.evaluate(() => {
     return document.body.innerText.includes('Something went wrong') ? 'CRASHED' : 'FINE';
  });
  console.log('STATUS:', errorBoundary);
  
  await browser.close();
})();
