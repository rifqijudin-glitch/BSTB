const fs = require('fs');

let content = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

if (!content.includes('ChevronLeft')) {
    content = content.replace(/import \{ /, 'import { Menu, ChevronRight, ChevronLeft, ');
}

const stateMatch = /const \[activeTab, setActiveTab\] = useState\('dashboard'\);/;
if (content.match(stateMatch)) {
    content = content.replace(stateMatch, `const [isSidebarOpen, setIsSidebarOpen] = useState(true);\n  const [activeTab, setActiveTab] = useState('dashboard');`);
}

const sidebarRegex = /<aside className="w-20 bg-\[#2b333e\] min-h-screen flex flex-col items-center py-4">[\s\S]*?<\/aside>/;

const newSidebar = `
      <aside className={\`bg-[#2b333e] min-h-screen flex flex-col py-4 transition-all duration-300 relative \${isSidebarOpen ? 'w-64' : 'w-20 items-center'}\`}>
        <button 
           onClick={() => setIsSidebarOpen(!isSidebarOpen)}
           className="absolute -right-3 top-6 bg-white border border-gray-200 rounded-full p-1 text-gray-500 hover:text-gray-800 shadow-md z-10"
        >
           {isSidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
      
        <div className={\`flex items-center mb-4 shadow-xl \${isSidebarOpen ? 'px-6 gap-3' : 'justify-center w-12 h-12 rounded-full mx-auto'}\`}>
           <div className={\`bg-white text-[#2b333e] flex flex-col items-center justify-center text-[10px] leading-none text-center shadow-inner \${isSidebarOpen ? 'w-10 h-10 rounded-lg shrink-0' : 'w-full h-full rounded-full'}\`}>
             <span className="font-extrabold whitespace-nowrap">MMP</span>
           </div>
           {isSidebarOpen && <span className="text-white font-bold text-lg whitespace-nowrap overflow-hidden">Dashboard Panel</span>}
        </div>
        
        <div className={\`bg-gray-400 flex items-center justify-center text-white mb-6 overflow-hidden \${isSidebarOpen ? 'w-10 h-10 rounded-full mx-6 shrink-0' : 'w-10 h-10 rounded-full mx-auto'}\`}>
           <User className="w-6 h-6" />
        </div>
        
        <nav className="flex flex-col gap-2 w-full px-2 flex-grow mt-2">
           <div onClick={() => setActiveTab('dashboard')} className={\`w-full flex items-center rounded-lg cursor-pointer relative \${isSidebarOpen ? 'px-4 py-3' : 'aspect-square justify-center'} \${activeTab === 'dashboard' ? 'bg-[#6366f1] text-white shadow-lg mb-2' : 'text-gray-400 hover:text-white hover:bg-white/5 bg-transparent'}\`}>
              {activeTab === 'dashboard' && <div className="absolute left-[-8px] top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r"></div>}
              <UserPlus className="w-6 h-6 shrink-0" />
              {isSidebarOpen && <span className="ml-3 font-medium whitespace-nowrap">Dashboard</span>}
           </div>
           <div onClick={() => setActiveTab('settings')} className={\`w-full flex items-center rounded-lg cursor-pointer relative \${isSidebarOpen ? 'px-4 py-3' : 'aspect-square justify-center'} \${activeTab === 'settings' ? 'bg-[#6366f1] text-white shadow-lg mb-2' : 'text-gray-400 hover:text-white hover:bg-white/5 bg-transparent'}\`}>
              {activeTab === 'settings' && <div className="absolute left-[-8px] top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r"></div>}
              <Settings className="w-6 h-6 shrink-0" />
              {isSidebarOpen && <span className="ml-3 font-medium whitespace-nowrap">Pengaturan Sistem</span>}
           </div>
           <div onClick={() => setActiveTab('documents')} className={\`w-full flex items-center rounded-lg cursor-pointer relative \${isSidebarOpen ? 'px-4 py-3' : 'aspect-square justify-center'} \${activeTab === 'documents' ? 'bg-[#6366f1] text-white shadow-lg mb-2' : 'text-gray-400 hover:text-white hover:bg-white/5 bg-transparent'}\`}>
              {activeTab === 'documents' && <div className="absolute left-[-8px] top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r"></div>}
              <FileText className="w-6 h-6 shrink-0" />
              {isSidebarOpen && <span className="ml-3 font-medium whitespace-nowrap">Dokumen & Template</span>}
           </div>
        </nav>

        <div className="flex flex-col gap-2 w-full px-2 mt-auto pt-4 border-t border-slate-700">
           <Link to="/form" target="_blank" title="Lihat Mode Pelamar" className={\`w-full flex items-center text-blue-400 hover:text-white hover:bg-blue-600/50 rounded-lg cursor-pointer transition-colors \${isSidebarOpen ? 'px-4 py-3 gap-3' : 'aspect-square justify-center'}\`}>
              <ExternalLink className="w-5 h-5 shrink-0" />
              {isSidebarOpen && <span className="font-medium whitespace-nowrap">View Form Pelamar</span>}
           </Link>
           <div 
              title="Copy Link Form"
              onClick={() => {
                 navigator.clipboard.writeText(window.location.origin + '/form');
                 alert('Link Form berhasil disalin!\\nBagikan link ini kepada pelamar: ' + window.location.origin + '/form');
              }}
              className={\`w-full flex items-center text-emerald-400 hover:text-white hover:bg-emerald-600/50 rounded-lg cursor-pointer transition-colors \${isSidebarOpen ? 'px-4 py-3 gap-3' : 'aspect-square justify-center'}\`}
           >
              <Copy className="w-5 h-5 shrink-0" />
              {isSidebarOpen && <span className="font-medium whitespace-nowrap">Copy Form Link</span>}
           </div>
        </div>
      </aside>
`;

content = content.replace(sidebarRegex, newSidebar);
fs.writeFileSync('src/pages/DashboardPage.tsx', content);
