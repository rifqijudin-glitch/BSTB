const fs = require('fs');

let content = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

// Update document.title
if (!content.includes('useEffect(() => {')) {
  content = content.replace("export function FormPage() {", `export function FormPage() {\n  React.useEffect(() => {\n    document.title = "Form Data Pelamar - PT. Mitra Multi Packaging";\n  }, []);`);
}

// Change initial state
content = content.replace('useState(1)', 'useState(0)');

const introScreen = `
  if (currentStep === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 py-12 px-4 sm:px-6 lg:px-8 font-sans flex items-center justify-center">
        <div className="max-w-2xl w-full bg-white/80 backdrop-blur-sm shadow-2xl rounded-3xl overflow-hidden border border-white/50 p-8 sm:p-12 text-center ring-1 ring-gray-900/5">
           <div className="inline-flex items-center justify-center p-4 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl mb-6 shadow-xl shadow-blue-200 transform hover:scale-105 transition-transform">
              <FileText className="w-10 h-10 text-white" />
           </div>
           <h1 className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-gray-900 to-gray-700 tracking-tight mb-2">Selamat Datang</h1>
           <p className="text-xl font-semibold text-blue-600 mb-8">Form Data Pelamar - PT. Mitra Multi Packaging</p>
           
           <div className="bg-blue-50 text-blue-800 rounded-xl p-6 text-left mb-8 text-sm leading-relaxed border border-blue-100">
               <p className="font-bold mb-3 text-base">Panduan Pengisian:</p>
               <ul className="list-decimal pl-5 space-y-2">
                   <li>Isilah semua data dengan sebenar-benarnya dan sesuai dengan dokumen resmi Anda.</li>
                   <li>Pastikan nomor HP/Telepon dan Email yang Anda masukkan aktif.</li>
                   <li>Beberapa bagian mungkin memerlukan Anda untuk mengunggah dokumen/berkas (opsional tergantung permintaan).</li>
                   <li>Klik tombol <strong>Lanjutkan</strong> atau <strong>Kembali</strong> untuk navigasi antar halaman.</li>
                   <li>Pastikan Anda mengecek kembali data sebelum mengklik tombol <strong>Kirim Form Lamaran</strong> di tahap akhir.</li>
               </ul>
           </div>
           
           <button
              onClick={() => setCurrentStep(1)}
              className="bg-blue-600 text-white font-medium px-8 py-3.5 rounded-xl hover:bg-blue-700 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 mx-auto"
           >
              Mulai Pengisian <ChevronRight className="w-5 h-5" />
           </button>
        </div>
      </div>
    );
  }
`;

if (!content.includes('if (currentStep === 0)')) {
   content = content.replace("if (showThankYou) {", introScreen + "\n\n  if (showThankYou) {");
}

fs.writeFileSync('src/pages/FormPage.tsx', content);
