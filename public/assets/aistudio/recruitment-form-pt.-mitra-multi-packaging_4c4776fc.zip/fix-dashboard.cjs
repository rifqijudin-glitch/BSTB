const fs = require('fs');

let d = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

// Step 5: Fix Date Formatting for Tanggal Lahir & Waktu Submit in Print + Detail View
// We have `formatTanggalIndo` but we also want a function to format Time "Kamis, 11 Juni 2026 pukul 16.11.00 WIB"
// The prompt says "samakan dengan Dicetak pada: Kamis, 11 Juni 2026 pukul 16.11.00 WIB"
// Instead of replacing existing `formatTanggalIndo`, let's add `formatDateTimeIndo`.

d = d.replace(
  'const formatTanggalIndo = (dateStr: string) => {',
  `const formatDateTimeIndo = (dateStr: string) => {
  if (!dateStr || dateStr === '-') return '-';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  
  const formatter = new Intl.DateTimeFormat('id-ID', { dateStyle: 'full', timeStyle: 'long' });
  return formatter.format(d).replace('pukul', 'pukul').replace(/\\./g, ':'); // Intl gives something close
};

const formatTanggalLahirIndo = (dateStr: string) => {
  if (!dateStr || dateStr === '-') return '-';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  return new Intl.DateTimeFormat('id-ID', { dateStyle: 'full' }).format(d);
};

const formatTanggalIndo = (dateStr: string) => {`
);

// We need to apply `formatDateTimeIndo` for Timestamp (Waktu Submit) and `formatTanggalLahirIndo` for Tanggal Lahir in the printHTML generation.
// It is generated in `const generatePelamarPrintHTML ...` mapping keys.
d = d.replace(
  `let displayValue = value;`,
  `let displayValue = value;
                              if (key === 'Timestamp (Waktu Submit)') {
                                 displayValue = formatDateTimeIndo(value as string);
                              } else if (key === 'Tanggal Lahir') {
                                 displayValue = formatTanggalLahirIndo(value as string);
                              }`
);

// But wait, the previous `const generatePelamarPrintHTML = ...` creates HTML. Let's see how `generatePelamarPrintHTML` loops!
// DashboardPage.tsx has `formatAsTable` and `Object.entries(rawData).forEach(([key, value]) => {`
// Let's replace within `generatePelamarPrintHTML`:
d = d.replace(
  /Object\.entries\(rawData\)\.forEach\(\(\[key, value\]\) => \{/g,
  `Object.entries(rawData).forEach(([key, value]) => {
      let displayValue = value;
      if (key === 'Timestamp (Waktu Submit)') {
         displayValue = formatDateTimeIndo(String(value));
      } else if (key === 'Tanggal Lahir') {
         displayValue = formatTanggalLahirIndo(String(value));
      }
      value = displayValue;
`
);

// And we need to show the image if it exists.
const imageDisplayCode = `
      // Print image
      if (key === 'foto_pelamar' && value && String(value).startsWith('data:image')) {
          html += \`<tr><td class="key-column" style="padding: 8px; border: 1px solid #cbd5e1;">Foto Pelamar</td><td style="padding: 8px; border: 1px solid #cbd5e1;"><img src="\${value}" style="max-height: 200px; max-width: 200px; display: block;" /></td></tr>\`;
          return;
      }
      if (key === 'cv_pelamar') {
          html += \`<tr><td class="key-column" style="padding: 8px; border: 1px solid #cbd5e1;">CV Pelamar</td><td style="padding: 8px; border: 1px solid #cbd5e1;">\${value ? 'Dilampirkan (CV format PDF disubmit)' : '-'}</td></tr>\`;
          return;
      }
`;

d = d.replace(
  `value = displayValue;\n`,
  `value = displayValue;\n` + imageDisplayCode
);

// Detail All Data in modal
const modalImageCode = `
                              if (key === 'foto_pelamar' && value && String(value).startsWith('data:image')) {
                                 return <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">
                                    <div className="text-gray-500 font-medium">Foto Pelamar</div>
                                    <div className="md:col-span-3 text-gray-800"><img src={String(value)} alt="Foto Pelamar" className="max-h-48 rounded" /></div>
                                 </div>;
                              }
                              if (key === 'cv_pelamar') {
                                 return <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">
                                    <div className="text-gray-500 font-medium">CV Pelamar</div>
                                    <div className="md:col-span-3 text-gray-800">{value ? 'Dilampirkan (Format CV Tersubmit)' : '-'}</div>
                                 </div>;
                              }
`;

d = d.replace(
  `                              let displayValue = value as string;`,
  modalImageCode + `                              let displayValue = value as string;`
);

// For modal Tanggal Lahir fix
d = d.replace(
  `                              if (key === 'Timestamp (Waktu Submit)') {`,
  `                              if (key === 'Tanggal Lahir') displayValue = formatTanggalLahirIndo(String(value));
                              if (key === 'Timestamp (Waktu Submit)') {`
);


// Removing "Lihat KTP" and linking CV
d = d.replace(
  /<button onClick=\{\(\) => \{ handleActionClick\(app, 'Lihat KTP'\); toggleDropdown\(app\.id\); \}\} className="w-full text-left px-4 py-2 hover:bg-gray-100 text-gray-700">Lihat KTP<\/button>/g,
  `` // Just remove
);

// We need to implement 'Lihat cv pelamar' link!
// In `handleActionClick`:
const handleActionHtml = `  const handleActionClick = (app: any, actionName: string) => {
    if (actionName === 'Lihat cv pelamar') {
        const cvData = app.rawData?.['cv_pelamar'];
        if (cvData && cvData.startsWith('data:application/pdf')) {
            const pdfWindow = window.open("");
            if(pdfWindow) {
               pdfWindow.document.write("<iframe width='100%' height='100%' src='" + cvData + "'></iframe>");
            }
        } else {
            setViewFileModal({
               isOpen: true,
               title: \`CV - \${app.nama}\`,
               content: \`CV Tidak tersedia atau bukan format PDF.\`
            });
        }
    }`;

d = d.replace(
  `  const handleActionClick = (app: any, actionName: string) => {
    if (actionName === 'Lihat KTP') {
        setViewFileModal({
           isOpen: true,
           title: \`KTP - \${app.nama}\`,
           content: \`Gambar KTP tidak tersedia. (Data tercatat: No KTP \${app.rawData && app.rawData['No KTP'] ? app.rawData['No KTP'] : '-'})\`
        });
    } else if (actionName === 'Lihat cv pelamar') {
        setViewFileModal({
           isOpen: true,
           title: \`CV - \${app.nama}\`,
           content: \`Dokumen CV tidak tersedia dalam sistem saat ini.\`
        });
    }`,
  handleActionHtml
);

fs.writeFileSync('src/pages/DashboardPage.tsx', d);
console.log('Fixed DashboardPage.tsx');
