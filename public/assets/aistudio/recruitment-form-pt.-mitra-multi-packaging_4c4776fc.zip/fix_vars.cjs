const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

// 1. Import Filter
code = code.replace(/import {([^}]+)} from 'lucide-react';/, "import {$1, Filter} from 'lucide-react';");

// 2. Add sendWhatsapp state near the other states
code = code.replace(/const \[updateStatusNote, setUpdateStatusNote\] = useState\(''\);/, "const [updateStatusNote, setUpdateStatusNote] = useState('');\n  const [sendWhatsapp, setSendWhatsapp] = useState(false);");

// 3. Move the block of activeEduLevels, activeJurusanList, skillList
// It is currently near the top, maybe before applicants?
// Let's find it.
const blockRegex = /const activeEduLevels = useMemo\(\(\) => \{.+?\}, \[applicants\]\);/s;
const match = code.match(blockRegex);
if (match) {
    code = code.replace(match[0], '');
    // Insert it after `applicants` is declared
    code = code.replace(/const \[applicants, setApplicants\] = useState<any\[\]>\(\[\]\);/, "const [applicants, setApplicants] = useState<any[]>([]);\n\n" + match[0]);
}

fs.writeFileSync('src/pages/DashboardPage.tsx', code);
