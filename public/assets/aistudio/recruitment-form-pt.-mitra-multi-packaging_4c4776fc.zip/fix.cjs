const fs = require('fs');
let code = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

const regex = /const rowsData = rows\.map\(\(tr: HTMLElement\) => \{[\s\S]*?trim\(\) !== ""\);/m;

const replacement = `const rowsData = rows.map((tr: HTMLElement) => {
               const cols = Array.from(tr.querySelectorAll('td'));
               const rowValues = cols.map((td) => {
                  const tdInputs = Array.from(td.querySelectorAll('input, select, textarea'));
                  if (tdInputs.length > 0) {
                     const activeInputs = tdInputs.filter(i => (i.type === 'radio' || i.type === 'checkbox') ? i.checked : true);
                     if (activeInputs.length > 0) {
                         return activeInputs.map(i => i.value.trim()).filter(v => v !== '').join(', ');
                     }
                     return ""; // Either unchecked radio or empty text
                  }
                  return td.textContent?.trim() || "";
               });
               return rowValues.join(' | ');
            }).filter(rowStr => rowStr && rowStr.replace(/ \\| /g, '').trim() !== "");`;

code = code.replace(regex, replacement);
fs.writeFileSync('src/pages/FormPage.tsx', code);
