const fs = require('fs');
let text = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

text = text.replaceAll(
    `} else if (input.name === 'jurusan_sd_smp') {
                isFieldRequired = false;
             }
             if (input.type !== 'checkbox' && input.type !== 'file') {
                 input.required = isFieldRequired;
             }`,
    `} else if (input.name === 'jurusan_sd_smp') {
                isFieldRequired = false;
             }
             if (input.hasAttribute('disabled')) isFieldRequired = false;
             if (input.type !== 'checkbox' && input.type !== 'file') {
                 input.required = isFieldRequired;
             }`
);

fs.writeFileSync('src/pages/FormPage.tsx', text);
