const fs = require('fs');
let d = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

// The modal mapping loop is:
// .map(([key, value]) => {
//    // Skip empty values ...
//    if (!value ...) return null;
// Find the `return (` string after the 'if (!value'

const mapStart = /return \(\n\s*<div key=\{key\} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">/g;

const modalImageCode = `if (key === 'foto_pelamar' && value && String(value).startsWith('data:image')) {
                                 return <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">
                                    <div className="text-gray-500 font-medium">Foto Pelamar</div>
                                    <div className="md:col-span-3 text-gray-800"><img src={String(value)} alt="Foto Pelamar" className="max-h-48 rounded shadow-sm border" /></div>
                                 </div>;
                              }
                              if (key === 'cv_pelamar') {
                                 return <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">
                                    <div className="text-gray-500 font-medium">CV Pelamar</div>
                                    <div className="md:col-span-3 text-gray-800"><span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium border border-green-200">Dilampirkan</span></div>
                                 </div>;
                              }
                              
                              return (
                                 <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">`;

d = d.replace(mapStart, modalImageCode);

fs.writeFileSync('src/pages/DashboardPage.tsx', d);
console.log('Fixed Modal CV and Foto UI');
