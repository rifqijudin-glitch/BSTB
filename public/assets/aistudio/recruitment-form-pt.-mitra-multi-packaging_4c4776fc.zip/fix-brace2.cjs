const fs = require('fs');

let d = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

d = d.replace(
  `        }
    };

  const executeDeleteApp = async (app: any) => {`,
  `        }
    }
  };

  const executeDeleteApp = async (app: any) => {`
);

fs.writeFileSync('src/pages/DashboardPage.tsx', d);
console.log('Fixed brace missing correctly');
