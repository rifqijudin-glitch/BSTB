const id = '1/1/2026';
fetch('https://sheetdb.io/api/v1/g6pseexgmqoyq/Timestamp (Waktu Submit)/' + encodeURIComponent(id), {method: 'DELETE'})
  .then(r=>r.json())
  .then(console.log);
