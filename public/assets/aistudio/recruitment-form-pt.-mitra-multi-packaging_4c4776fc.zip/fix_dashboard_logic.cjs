const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

// 1. Fix Quick Filter select to instantly apply posisiFilter
const quickSelectRegex = /<select \s*value=\{posisiFilterDropdown\}\s*onChange=\{\(e\) => setPosisiFilterDropdown\(e\.target\.value\)\}\s*className="border border-gray-300 rounded px-2 py-1\.5 text-xs outline-none bg-white text-gray-700 w-full md:w-48 focus:border-blue-500"\s*>/;
const quickSelectReplacement = `<select 
                        value={posisiFilterDropdown}
                        onChange={(e) => {
                           setPosisiFilterDropdown(e.target.value);
                           setPosisiFilter(e.target.value);
                        }}
                        className="border border-gray-300 rounded px-2 py-1.5 text-xs outline-none bg-white text-gray-700 w-full md:w-48 focus:border-blue-500"
                     >`;
code = code.replace(quickSelectRegex, quickSelectReplacement);

// 2. Fix Terapkan Filter button to apply posisiFilter
const applyFilterRegex = /setAppliedSelectedSkills\(\[\.\.\.selectedSkills\]\);\s*setIsFilterModalOpen\(false\);/;
const applyFilterReplacement = `setAppliedSelectedSkills([...selectedSkills]);\n                     setPosisiFilter(posisiFilterDropdown);\n                     setIsFilterModalOpen(false);`;
code = code.replace(applyFilterRegex, applyFilterReplacement);

// 3. Fix Advanced Filter's Tingkat Pendidikan dropdown to have hardcoded levels
const eduTingkatRegex = /<select value=\{ef\.tingkat\} onChange=\{\(e\) => setEduFilters\(eduFilters\.map\(\(f, i\) => i === idx \? \{\.\.\.f, tingkat: e\.target\.value, jurusan: ""\} : f\)\)\} className="border-gray-300 rounded px-2 py-1\.5 outline-none bg-white border">\s*<option value="Semua">Semua Tingkat<\/option>\s*\{activeEduLevels\.map\(lvl => <option key=\{lvl\} value=\{lvl\}>\{lvl\}<\/option>\)\}\s*<\/select>/;
const eduTingkatReplacement = `<select value={ef.tingkat} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, tingkat: e.target.value, jurusan: ""} : f))} className="border-gray-300 rounded px-2 py-1.5 outline-none bg-white border">
                                         <option value="Semua">Semua Tingkat</option>
                                         <option value="SD/SLTP">SD/SLTP</option>
                                         <option value="SLTA/SMU">SLTA/SMU</option>
                                         <option value="D1/D2/D3">D1/D2/D3</option>
                                         <option value="S1">S1</option>
                                         <option value="S2/S3">S2/S3</option>
                                         {activeEduLevels.filter(lvl => !['SD/SLTP', 'SLTA/SMU', 'D1/D2/D3', 'S1', 'S2/S3'].includes(lvl)).map(lvl => <option key={lvl} value={lvl}>{lvl}</option>)}
                                     </select>`;
code = code.replace(eduTingkatRegex, eduTingkatReplacement);


fs.writeFileSync('src/pages/DashboardPage.tsx', code);
