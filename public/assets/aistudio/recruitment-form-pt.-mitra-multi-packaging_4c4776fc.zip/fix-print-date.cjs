const fs = require('fs');
let text = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

text = text.replace(
  `personalInfoKeys.forEach(key => {
     if (rawData[key]) {
        html += \`<tr><td class="key-column" style="padding: 8px; border: 1px solid #cbd5e1;">\${key}</td><td style="padding: 8px; border: 1px solid #cbd5e1;">\${formatAsTable(rawData[key])}</td></tr>\`;
     }
  });`,
  `personalInfoKeys.forEach(key => {
     if (rawData[key]) {
        let displayValue = rawData[key];
        if (key === 'Tanggal Lahir') displayValue = formatTanggalLahirIndo(String(rawData[key]));
        html += \`<tr><td class="key-column" style="padding: 8px; border: 1px solid #cbd5e1;">\${key}</td><td style="padding: 8px; border: 1px solid #cbd5e1;">\${formatAsTable(displayValue)}</td></tr>\`;
     }
  });`
);

fs.writeFileSync('src/pages/DashboardPage.tsx', text);
