const fs = require('fs');
let text = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

text = text.replace(
/let dari[\s\S]*?let alasan[\s\S]*?;/g,
    `let dari = (inputs[0].value.trim() || inputs[1].value.trim()) ? \`\${inputs[0].value.trim()}/\${inputs[1].value.trim()}\` : '';
                  let status = inputs[10].checked ? 'Masih Bekerja' : (inputs[11]?.checked ? 'Berhenti' : '');
                  let sampai = status === 'Masih Bekerja' ? '-' : ((inputs[2].value.trim() || inputs[3].value.trim()) ? \`\${inputs[2].value.trim()}/\${inputs[3].value.trim()}\` : '');
                  let perusahaan = inputs[4].value.trim();
                  let jabatan = inputs[5].value.trim();
                  let jenisUsaha = inputs[6].value.trim();
                  let jmlKar = inputs[7].value.trim();
                  let atasan = inputs[8].value.trim();
                  let direktur = inputs[9].value.trim();
                  let alasan = inputs[12] ? inputs[12].value.trim() : '-';`
);

fs.writeFileSync('src/pages/FormPage.tsx', text);
