const fs = require('fs');
let c1 = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

if (!c1.includes('formatTanggalIndo')) {
  c1 = c1.replace(
      'export function DashboardPage() {',
      `const formatTanggalIndo = (dateStr: string) => {
  if (!dateStr || dateStr === '-') return '-';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  const months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  return \`\${String(d.getDate()).padStart(2, '0')} \${months[d.getMonth()]} \${d.getFullYear()}\`;
};

export function DashboardPage() {`
  );
}

let parts = c1.split('tanggalMasuk: item["Timestamp (Waktu Submit)"]?.split(\',\')[0] || "-",');
c1 = parts.join('tanggalMasuk: formatTanggalIndo(item["Timestamp (Waktu Submit)"]?.split(\',\')[0] || "-"),');

let strOriginal = `                           .map(([key, value]) => {
                              // Skip empty values or standalone dashes
                              if (!value || value === '-' || value === '-\\n-') return null;
                              
                              return (
                                 <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">`;
                                 
let strReplace = `                           .map(([key, value]) => {
                              // Skip empty values or standalone dashes
                              if (!value || value === '-' || value === '-\\n-') return null;
                              
                              let displayValue = value as string;
                              if (key === 'Timestamp (Waktu Submit)') {
                                 displayValue = formatTanggalIndo(String(value).split(',')[0]);
                              }
                              
                              return (
                                 <div key={key} className="grid grid-cols-1 md:grid-cols-4 border-b border-gray-100 last:border-0 pb-3 last:pb-0">`;

c1 = c1.replace(strOriginal, strReplace);

c1 = c1.replace(
  /<div className="whitespace-pre-wrap">\{formatText\(value as string\)\}<\/div>/g,
  `<div className="whitespace-pre-wrap">{formatText(typeof displayValue !== 'undefined' ? displayValue : value as string)}</div>`
);

fs.writeFileSync('src/pages/DashboardPage.tsx', c1);
console.log('done replacing dashboard page date formats');
