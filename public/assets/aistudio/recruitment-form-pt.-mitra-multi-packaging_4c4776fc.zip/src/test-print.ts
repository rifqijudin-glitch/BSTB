const text = "Pertanyaan | Ya/Tidak | Penjelasan Tambahan\nApakah anda bersedia menjalani masa percobaan 3 bulan ? | Ya | -\nApakah anda terikat kontrak | Tidak | -";
const formatAsTable = (text: string) => {
    if (!text || text === '-' || text === '-\n-') return text;
    // Simple heuristik: If it has newlines and pipes, it's likely our serialized table
    if (text.includes('\n') && text.includes('|')) {
      const rows = text.split('\n').filter(r => r.trim());
      let html = '<div class="table-wrapper"><table>';
      if (rows.length > 0) {
        html += '<thead><tr>';
        const headerCells = rows[0].split('|').map(c => c.trim());
        headerCells.forEach(cell => {
           html += `<th>${cell}</th>`;
        });
        html += '</tr></thead><tbody>';
      }
      
      rows.forEach((row, idx) => {
         if (idx === 0) return; // skip header
         html += '<tr>';
         const cells = row.split('|').map(c => c.trim());
         cells.forEach(cell => {
             html += `<td>${cell}</td>`;
         });
         html += '</tr>';
      });
      html += '</tbody></table></div>';
      return html;
    }
    return text;
};
console.log(formatAsTable(text));
