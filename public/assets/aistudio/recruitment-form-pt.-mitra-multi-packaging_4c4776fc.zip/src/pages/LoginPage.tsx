import { LogoMMP } from '../components/LogoMMP';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, Copyright, User, ShieldCheck, KeyRound, CheckCircle2, AlertTriangle, Shield } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { collection, query, where, getDocs, doc, setDoc, getDoc } from 'firebase/firestore';

export function LoginPage() {
  const navigate = useNavigate();
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [companySecurityCode, setCompanySecurityCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResetEmailSent, setIsResetEmailSent] = useState(false);

  // Pre-fetch active company security code from Firestore or fallback
  const [activeSecretCode, setActiveSecretCode] = useState('MMP-ADMIN-2026');

  useEffect(() => {
    const fetchSecurityCode = async () => {
      try {
        const secDoc = await getDoc(doc(db, 'app_settings', 'company_security'));
        if (secDoc.exists() && secDoc.data()?.registrationSecretCode) {
          setActiveSecretCode(secDoc.data()?.registrationSecretCode.trim());
        } else {
          const cached = localStorage.getItem('setting_company_registration_code');
          if (cached) setActiveSecretCode(cached.trim());
        }
      } catch (err) {
        const cached = localStorage.getItem('setting_company_registration_code');
        if (cached) setActiveSecretCode(cached.trim());
      }
    };
    fetchSecurityCode();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setIsSubmitting(true);

    try {
        if (isForgotPassword) {
            const cleanEmail = email.toLowerCase().trim();
            if (!cleanEmail) {
                setErrorMsg('Masukkan email Anda.');
                setIsSubmitting(false);
                return;
            }

            if (!cleanEmail.includes('@')) {
                setErrorMsg('Format email tidak valid. Masukkan alamat email lengkap (misal: user@gmail.com).');
                setIsSubmitting(false);
                return;
            }

            await sendPasswordResetEmail(auth, cleanEmail);
            setIsResetEmailSent(true);
            setIsSubmitting(false);
            return;
        }

        if (isLoginMode) {
            const inputId = userId.trim();
            if (!inputId) {
                setErrorMsg('Masukkan User ID atau Email Anda.');
                setIsSubmitting(false);
                return;
            }

            let loginEmail = inputId.toLowerCase();
            let resolvedUserId = inputId;

            if (!inputId.includes('@')) {
                // Check local cached map first
                const localMap = JSON.parse(localStorage.getItem('admin_user_email_map') || '{}');
                if (localMap[inputId.toLowerCase()]) {
                    loginEmail = localMap[inputId.toLowerCase()];
                } else {
                    // Try querying Firestore admin_users collection safely
                    try {
                        const usersRef = collection(db, 'admin_users');
                        const q = query(usersRef, where('userId', '==', inputId));
                        const snapshot = await getDocs(q);
                        if (!snapshot.empty) {
                            const data = snapshot.docs[0].data();
                            if (data.email) loginEmail = data.email.toLowerCase();
                        }
                    } catch (fsErr) {
                        console.warn("Permission restricted for unauthenticated admin_users query:", fsErr);
                    }
                }
            }

            // If it's still not a valid email, don't call Firebase auth with invalid email format
            if (!loginEmail.includes('@')) {
                setErrorMsg(`User ID "${inputId}" tidak terasosiasi dengan email. Silakan masuk menggunakan Alamat Email lengkap (contoh: user@gmail.com).`);
                setIsSubmitting(false);
                return;
            }

            // Attempt Auth Sign-in with resolved email
            let isAuthSuccess = false;
            let userObj: any = null;

            try {
                const userCredential = await signInWithEmailAndPassword(auth, loginEmail, password);
                userObj = userCredential.user;
                isAuthSuccess = true;
            } catch (authErr: any) {
                console.warn("Standard Firebase Auth login failed, checking Super Admin Manual Password Reset...", authErr);
                
                // Check if Super Admin reset password manually in admin_users collection
                try {
                    const usersRef = collection(db, 'admin_users');
                    let manualMatchDoc: any = null;

                    // Query by email
                    const qEmail = query(usersRef, where('email', '==', loginEmail));
                    const snapEmail = await getDocs(qEmail);

                    if (!snapEmail.empty) {
                        manualMatchDoc = snapEmail.docs.find(d => d.data().manualPassword === password);
                    }

                    // Query by userId
                    if (!manualMatchDoc) {
                        const qUser = query(usersRef, where('userId', '==', inputId));
                        const snapUser = await getDocs(qUser);
                        if (!snapUser.empty) {
                            manualMatchDoc = snapUser.docs.find(d => d.data().manualPassword === password);
                        }
                    }

                    if (manualMatchDoc) {
                        const data = manualMatchDoc.data();
                        resolvedUserId = data.userId || inputId;
                        loginEmail = data.email || loginEmail;
                        isAuthSuccess = true;
                    } else {
                        throw authErr;
                    }
                } catch (fsCheckErr) {
                    throw authErr;
                }
            }

            // Post-login profile sync (if authenticated via Firebase Auth)
            if (userObj) {
                try {
                    const userDocRef = doc(db, 'admin_users', userObj.uid);
                    const userDocSnap = await getDoc(userDocRef);
                    if (userDocSnap.exists()) {
                        const data = userDocSnap.data();
                        if (data && data.userId) resolvedUserId = data.userId;
                    } else {
                        await setDoc(userDocRef, {
                            userId: resolvedUserId,
                            email: userObj.email || loginEmail,
                            uid: userObj.uid,
                            createdAt: new Date().toISOString()
                        }, { merge: true });
                    }
                } catch (syncErr) {
                    console.warn("Could not sync user doc post-login:", syncErr);
                }
            }

            // Cache in localStorage
            localStorage.setItem('admin_user_id', resolvedUserId);
            if (loginEmail) {
                const map = JSON.parse(localStorage.getItem('admin_user_email_map') || '{}');
                map[resolvedUserId.toLowerCase()] = loginEmail.toLowerCase();
                map[loginEmail.toLowerCase()] = loginEmail.toLowerCase();
                localStorage.setItem('admin_user_email_map', JSON.stringify(map));
            }

            navigate('/dashboard');
        } else {
            // Register mode
            const cleanEmail = email.toLowerCase().trim();
            const cleanUserId = userId.trim();
            const inputCode = companySecurityCode.trim();

            if (!cleanEmail || !cleanUserId || !password.trim()) {
                setErrorMsg('Isi email, User ID, dan password dengan lengkap.');
                setIsSubmitting(false);
                return;
            }

            if (!cleanEmail.includes('@')) {
                setErrorMsg('Format email tidak valid. Masukkan alamat email lengkap (misal: user@gmail.com).');
                setIsSubmitting(false);
                return;
            }

            if (password.length < 6) {
                setErrorMsg('Password minimal terdiri dari 6 karakter.');
                setIsSubmitting(false);
                return;
            }

            // ANTI-INTRUDER CHECK:
            // 1. Check if this email is already pre-approved / whitelisted by Super Admin in admin_users
            let isPreApproved = false;
            try {
                const usersRef = collection(db, 'admin_users');
                const qEmail = query(usersRef, where('email', '==', cleanEmail));
                const snapEmail = await getDocs(qEmail);
                if (!snapEmail.empty) {
                    isPreApproved = true;
                }
            } catch (fsErr) {
                console.warn("Could not check pre-approved emails:", fsErr);
            }

            // 2. Fetch the latest Company Security Code from Firestore
            let currentValidCode = activeSecretCode;
            try {
                const secDoc = await getDoc(doc(db, 'app_settings', 'company_security'));
                if (secDoc.exists() && secDoc.data()?.registrationSecretCode) {
                    currentValidCode = secDoc.data()?.registrationSecretCode.trim();
                }
            } catch (secErr) {
                // fallback to activeSecretCode
            }

            // 3. Verify security code if not pre-approved
            if (!isPreApproved && inputCode.toUpperCase() !== currentValidCode.toUpperCase()) {
                setErrorMsg('Akses Ditolak: "Kode Otorisasi Perusahaan" tidak cocok. Untuk melindungi data pelamar dari pihak luar, pendaftaran akun admin baru (termasuk via @gmail.com) wajib menyertakan kode otorisasi resmi dari HCGA / Super Admin.');
                setIsSubmitting(false);
                return;
            }

            // Attempt registration with Firebase Auth
            const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, password);
            const user = userCredential.user;

            try {
                await setDoc(doc(db, 'admin_users', user.uid), {
                    userId: cleanUserId,
                    email: cleanEmail,
                    uid: user.uid,
                    authProvider: cleanEmail.endsWith('@gmail.com') ? 'Gmail (Firebase Auth)' : 'Corporate Email',
                    registeredWithCode: isPreApproved ? 'Pre-Approved by Super Admin' : 'Company Security Code Verified',
                    createdAt: new Date().toISOString()
                }, { merge: true });
            } catch (e) {
                console.error("Error setting admin_users doc during register:", e);
            }

            localStorage.setItem('admin_user_id', cleanUserId);
            const map = JSON.parse(localStorage.getItem('admin_user_email_map') || '{}');
            map[cleanUserId.toLowerCase()] = cleanEmail;
            map[cleanEmail] = cleanEmail;
            localStorage.setItem('admin_user_email_map', JSON.stringify(map));

            setSuccessMsg('Akun berhasil didaftarkan dan terotorisasi. Anda otomatis dialihkan ke Dashboard...');
            setTimeout(() => {
                navigate('/dashboard');
            }, 1000);
        }
    } catch (err: any) {
        console.error(err);
        if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-login-credentials' || err.code === 'auth/invalid-credential') {
            setErrorMsg('Password salah.');
        } else if (err.code === 'auth/user-not-found') {
            setErrorMsg('Akun / Email tidak ditemukan.');
        } else if (err.code === 'auth/email-already-in-use') {
            setErrorMsg('Email sudah terdaftar di sistem. Silakan langsung login atau gunakan fitur Lupa Password.');
        } else if (err.code === 'auth/invalid-email') {
            setErrorMsg('Format email tidak valid. Masukkan email lengkap (misal: nama@gmail.com).');
        } else if (err.message && err.message.includes('permission')) {
            setErrorMsg('Akses ditolak. Gunakan Alamat Email lengkap (misal: user@gmail.com) untuk login.');
        } else {
            setErrorMsg(err.message || 'Terjadi kesalahan sistem.');
        }
    } finally {
        setIsSubmitting(false);
    }
  };

  if (isForgotPassword && isResetEmailSent) {
    const isGmailAccount = email.toLowerCase().endsWith('@gmail.com');
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center font-sans p-4 relative">
        <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8 relative z-10">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-green-50 rounded-full mx-auto flex items-center justify-center mb-4 border border-green-200">
              <Mail className="h-8 w-8 text-green-600 animate-pulse" />
            </div>
            <h2 className="text-2xl font-semibold text-gray-800">
               Reset Link Terkirim!
            </h2>
            <p className="text-sm text-gray-500 mt-2">
               Tautan pemulihan password telah diproses untuk akun Anda.
            </p>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-6 text-center">
            <p className="text-xs text-green-800 font-medium leading-relaxed">
              Tautan reset password aman telah dikirimkan ke:
            </p>
            <p className="text-sm text-green-900 font-bold mt-1 break-all">
              {email}
            </p>
          </div>

          <div className="space-y-4 text-xs text-gray-600 leading-relaxed mb-6">
            {isGmailAccount ? (
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-md text-emerald-950">
                <div className="flex items-center gap-1.5 font-bold mb-1 text-emerald-800">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>AKUN GMAIL TERVERIFIKASI & AMAN</span>
                </div>
                <p className="leading-relaxed">
                  Karena Anda menggunakan akun <b>@gmail.com</b>, email otomatis dari Google Firebase Auth <b>dijamin tembus 100%</b> dan tiba dalam beberapa detik tanpa terhalang firewall korporasi.
                </p>
                <div className="mt-2 pt-2 border-t border-emerald-200/60 font-medium text-[11px] text-emerald-800">
                  👉 Buka aplikasi <b>Gmail</b> (Kotak Masuk / Inbox) Anda, lalu klik tautan reset untuk membuat password baru secara mandiri.
                </div>
              </div>
            ) : (
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-md text-amber-900">
                <div className="flex items-center gap-1.5 font-bold mb-1 text-amber-800">
                  <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
                  <span>PERHATIAN EMAIL KORPORASI ({email.split('@')[1] || 'Perusahaan'}):</span>
                </div>
                Sistem firewall email korporasi Anda memiliki kebijakan keamanan yang ketat. Email otomatis dari domain Firebase (<span className="font-mono">firebaseapp.com</span>) kemungkinan besar tertahan:
                <ul className="list-disc pl-4 mt-1.5 space-y-1 font-medium">
                  <li>Terfilter ke folder <b>Spam</b> atau Junk.</li>
                  <li>Atau <b>dikarantina / diblokir</b> oleh gateway email perusahaan.</li>
                </ul>
                <p className="mt-2 text-[11px] leading-normal font-semibold text-amber-800">
                  💡 Solusi: Hubungi Super Admin (humas@mmpackaging.co.id) untuk reset password instan, atau daftarkan akun Admin menggunakan @gmail.com pribadi/kantor dengan Kode Otorisasi Perusahaan.
                </p>
              </div>
            )}

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-900">
              <span className="font-bold block mb-1">🔑 Standar Keamanan Firebase Auth</span>
              Tautan reset bersifat sekali pakai (one-time token) dan kedaluwarsa otomatis dalam 1 jam untuk mencegah akses tidak sah.
            </div>
          </div>

          <button
            onClick={() => {
              setIsForgotPassword(false);
              setIsResetEmailSent(false);
              setErrorMsg('');
              setSuccessMsg('');
              setEmail('');
            }}
            className="w-full bg-[#6366f1] hover:bg-[#4f46e5] text-white rounded-md py-2.5 font-medium transition-colors shadow-sm text-sm"
          >
            Kembali ke Halaman Login
          </button>
        </div>
        
        <div className="mt-10 text-gray-500 text-xs flex items-center justify-center gap-1">
           <Copyright className="w-3.5 h-3.5" /> 2026 HCGA PT Mitra Multi Packaging
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center font-sans p-4 relative">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8 relative z-10">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-white rounded-full mx-auto flex items-center justify-center mb-4">
            <LogoMMP variant="dots" className="h-12 w-12 object-contain mx-auto" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800">
             {isForgotPassword ? 'Reset Password' : (isLoginMode ? 'Admin Login' : 'Daftar Akun Admin')}
          </h2>
          <p className="text-sm text-gray-500 mt-1">
             {isForgotPassword 
               ? 'Masukkan email akun terdaftar Anda' 
               : (isLoginMode ? 'Silakan masuk ke Dashboard Panel' : 'Pendaftaran resmi staf dengan otorisasi internal')}
          </p>
        </div>

        {errorMsg && (
            <div className="mb-4 bg-red-50 text-red-700 p-3.5 rounded-lg text-xs leading-relaxed border border-red-200 flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-red-600 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
            </div>
        )}
        
        {successMsg && (
            <div className="mb-4 bg-green-50 text-green-700 p-3 rounded-md text-sm border border-green-200">
                {successMsg}
            </div>
        )}

        {/* Informative banner for Register Mode */}
        {!isLoginMode && !isForgotPassword && (
          <div className="mb-4 p-3 bg-indigo-50 border border-indigo-100 rounded-lg text-xs text-indigo-900 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-800">
              <ShieldCheck className="h-4 w-4 text-indigo-600 shrink-0" />
              <span>Dukungan Akun Gmail & Anti-Penyusup</span>
            </div>
            <p className="text-[11px] leading-relaxed text-indigo-800/90">
              Anda dapat mendaftar dengan akun <b>@gmail.com</b> agar pengiriman tautan <i>Reset Password</i> selalu diterima lancar tanpa terblokir firewall korporasi. Demi keamanan, pendaftaran wajib memasukkan <b>Kode Otorisasi Perusahaan</b> dari HRD.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {(!isLoginMode || isForgotPassword) && (
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Alamat Email {!isLoginMode && <span className="text-indigo-600 font-normal">(@gmail.com disarankan)</span>}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="email"
                  required
                  className="pl-9 w-full border border-gray-300 rounded-md py-2 text-sm focus:ring-2 focus:ring-[#6366f1] focus:border-[#6366f1] outline-none"
                  placeholder={!isLoginMode ? "contoh: nama.anda@gmail.com" : "Masukkan email Anda..."}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>
          )}

          {!isForgotPassword && (
             <div>
               <label className="block text-xs font-semibold text-gray-700 mb-1">
                 {isLoginMode ? 'User ID / Email' : 'User ID (Singkat / NIK)'}
               </label>
               <div className="relative">
                 <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                   <User className="h-4 w-4 text-gray-400" />
                 </div>
                 <input
                   type="text"
                   required
                   className="pl-9 w-full border border-gray-300 rounded-md py-2 text-sm focus:ring-2 focus:ring-[#6366f1] focus:border-[#6366f1] outline-none"
                   placeholder={isLoginMode ? "Masukkan User ID atau Email (@gmail.com / co.id)..." : "Contoh: budi / hrd_admin"}
                   value={userId}
                   onChange={(e) => setUserId(e.target.value)}
                 />
               </div>
             </div>
          )}

          {!isForgotPassword && (
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Password</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    className="pl-9 pr-10 w-full border border-gray-300 rounded-md py-2 text-sm focus:ring-2 focus:ring-[#6366f1] focus:border-[#6366f1] outline-none"
                    placeholder="Minimal 6 karakter"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <div 
                     className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                     onClick={() => setShowPassword(!showPassword)}
                     title={showPassword ? "Sembunyikan password" : "Tampilkan password"}
                  >
                     {showPassword ? <EyeOff className="h-4 w-4 text-gray-400 hover:text-gray-600" /> : <Eye className="h-4 w-4 text-gray-400 hover:text-gray-600" />}
                  </div>
                </div>
              </div>
          )}

          {/* Security Code input to block intruders during registration */}
          {!isLoginMode && !isForgotPassword && (
            <div className="pt-1">
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-gray-700">
                  Kode Otorisasi Perusahaan <span className="text-red-500">*</span>
                </label>
                <span className="text-[10px] text-gray-400 font-medium">Dari Super Admin / HRD</span>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <KeyRound className="h-4 w-4 text-indigo-500" />
                </div>
                <input
                  type="text"
                  required
                  value={companySecurityCode}
                  onChange={(e) => setCompanySecurityCode(e.target.value)}
                  className="pl-9 w-full border border-indigo-200 bg-indigo-50/20 rounded-md py-2 text-sm font-mono tracking-wider focus:ring-2 focus:ring-[#6366f1] focus:border-[#6366f1] outline-none"
                  placeholder="Masukkan kode rahasia perusahaan..."
                />
              </div>
              <p className="text-[10px] text-gray-500 mt-1">
                🔒 Pihak luar tidak dapat mendaftar tanpa kode otorisasi internal ini.
              </p>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full text-white rounded-md py-2.5 font-medium transition-colors shadow-sm text-sm ${isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-[#6366f1] hover:bg-[#4f46e5]'}`}
          >
            {isSubmitting ? 'Memproses...' : (isForgotPassword ? 'Kirim Reset Link' : (isLoginMode ? 'Login' : 'Daftarkan Akun'))}
          </button>
        </form>
        
        <div className="mt-6 text-center text-sm text-gray-600 flex flex-col gap-2">
            {!isForgotPassword ? (
               <>
                {isLoginMode ? (
                    <div>
                        Belum punya akun? <button onClick={() => { setIsLoginMode(false); setErrorMsg(''); setSuccessMsg(''); }} className="text-[#6366f1] font-semibold hover:underline">Daftar di sini</button>
                    </div>
                ) : (
                    <div>
                        Sudah punya akun? <button onClick={() => { setIsLoginMode(true); setErrorMsg(''); setSuccessMsg(''); }} className="text-[#6366f1] font-semibold hover:underline">Login sekarang</button>
                    </div>
                )}
                {isLoginMode && (
                    <div>
                        <button onClick={() => { setIsForgotPassword(true); setErrorMsg(''); setSuccessMsg(''); }} className="text-[#6366f1] hover:underline">Lupa Password?</button>
                    </div>
                )}
               </>
            ) : (
                <div>
                   Ingat password Anda? <button onClick={() => { setIsForgotPassword(false); setErrorMsg(''); setSuccessMsg(''); }} className="text-[#6366f1] font-semibold hover:underline">Kembali ke Login</button>
                </div>
            )}
        </div>
      </div>
      
      <div className="mt-10 text-gray-500 text-xs flex items-center justify-center gap-1">
         <Copyright className="w-3.5 h-3.5" /> 2026 HCGA PT Mitra Multi Packaging
      </div>
    </div>
  );
}
