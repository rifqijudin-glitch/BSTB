import { LogoMMP } from '../components/LogoMMP';
import React, { useState, useMemo, useEffect } from 'react';
import { Menu, ChevronRight, ChevronLeft, ChevronUp, Users, UserPlus, UserCheck, User, Search, Settings, FileText, ArrowRight, ChevronDown, Edit, X, Plus, Download, Copy, ExternalLink, Loader2, RefreshCw , Filter, Lock, Shield, Key, Clock, Send, Calendar, CheckCircle2, XCircle, Award, KeyRound, Eye, EyeOff, AlertCircle, Check } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { db, auth } from '../lib/firebase';
import { collection, getDocs, doc, deleteDoc, updateDoc, getDoc, setDoc } from 'firebase/firestore';
import { onAuthStateChanged, updatePassword, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';
import * as XLSX from 'xlsx';

export const formatImageUrl = (url: string | any) => {
  if (!url || url === '-' || url === '-\n-') return '';
  let imgUrl = String(url).trim();
  if (imgUrl.includes('drive.google.com') || imgUrl.includes('docs.google.com') || imgUrl.includes('googleusercontent.com')) {
    const matchId = imgUrl.match(/id=([^&]+)/) || imgUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
    if (matchId && matchId[1]) {
      return `https://lh3.googleusercontent.com/d/${matchId[1]}=s1000`;
    }
  }
  return imgUrl;
};

const JURUSAN_SMU = ["MIPA","IPS","Ekonomi","Bahasa dan Budaya","Teknik Konstruksi dan Perumahan","Teknik Geomatika dan Geospasial","Teknik Ketenagalistrikan","Teknik Mesin","Teknik Otomotif","Teknik Elektronika","Teknik Perkapalan","Pengembangan Perangkat Lunak dan Gim (PPLG)","Teknik Jaringan Komputer dan Telekomunikasi (TJKT)","Layanan Kesehatan","Farmasi","Pekerjaan Sosial","Akuntansi dan Keuangan Lembaga (AKL)","Manajemen Perkantoran dan Layanan Bisnis (MPLB)","Pemasaran","Kuliner","Perhotelan","Usaha Layanan Pariwisata","Tata Kecantikan dan Rambut","Tata Busana","Desain Komunikasi Visual (DKV)","Animasi","Penyiaran dan Produksi Film","Seni Pertunjukan","Kriya Kreatif","Agribisnis Tanaman","Agribisnis Ternak","Agriteknologi Pengolahan Hasil Pertanian (APHP)","Kehutanan","Nautika Kapal Penangkap Ikan / Niaga","Teknika Kapal Penangkap Ikan / Niaga","Agribisnis Perikanan","Teknik Perminyakan","Teknik Pertambangan","Teknik Kimia Industri","Lainnya"];
const JURUSAN_S1 = ["Pendidikan Dokter","Pendidikan Dokter Gigi","Kedokteran Hewan","Ilmu Keperawatan","Kebidanan","Farmasi","Kesehatan Masyarakat","Gizi Kesehatan","Fisioterapi","Okupasi Terapi","Sains Kedokteran Tropis","Keselamatan dan Kesehatan Kerja","Teknik Sipil","Teknik Arsitektur","Teknik Mesin","Teknik Elektro","Teknik Kimia","Teknik Industri","Teknik Lingkungan","Teknik Perencanaan Wilayah dan Kota","Teknik Metalurgi dan Material","Teknik Dirgantara","Teknik Kelautan","Teknik Nuklir","Teknik Biomedis","Teknik Informatika","Sistem Informasi","Ilmu Komputer","Sains Data","Keamanan Siber","Rekayasa Perangkat Lunak","Matematika","Fisika","Kimia","Biologi","Astronomi","Geofisika","Meteorologi","Statistika","Aktuaria","Agroteknologi","Agribisnis","Ilmu Kelautan","Oseanografi","Teknologi Pangan","Manajemen Sumberdaya Perairan","Kehutanan","Hubungan Internasional","Ilmu Komunikasi","Jurnalistik","Penyiaran","Hubungan Masyarakat","Ilmu Pemerintahan","Ilmu Politik","Sosiologi","Antropologi Sosial","Ilmu Administrasi Publik","Ilmu Administrasi Bisnis","Kriminologi","Psikologi","Akuntansi","Manajemen","Manajemen Keuangan","Manajemen Pemasaran","Manajemen Sumber Daya Manusia","Ilmu Ekonomi","Ekonomi Pembangunan","Ekonomi Syariah","Perbankan Syariah","Ilmu Hukum","Hukum Perdata","Hukum Pidana","Hukum Internasional","Hukum Tata Negara","Sastra Inggris","Sastra Indonesia","Sastra Jepang","Sastra Arab","Sastra Korea","Sastra Mandarin","Linguistik","Ilmu Sejarah","Arkeologi","Ilmu Filsafat","Desain Interior","Desain Produk","Seni Rupa Murni","Fotografi","Etnomusikologi","Penciptaan Musik","Seni Teater","Pendidikan Guru Sekolah Dasar","Pendidikan Guru Anak Usia Dini","Pendidikan Luar Biasa","Bimbingan dan Konseling","Pendidikan Bahasa Indonesia","Pendidikan Bahasa Inggris","Pendidikan Matematika","Pendidikan Fisika","Pendidikan Kimia","Pendidikan Biologi","Pendidikan Sejarah","Pendidikan Geografi","Pendidikan Ekonomi","Lainnya"];
const JURUSAN_S2 = ["Magister Manajemen","Magister Hukum","Magister Ilmu Komunikasi","Magister Administrasi Publik","Magister Teknik Sipil","Magister Kenotariatan","Magister Psikologi Profesi","Doktor Ilmu Hukum","Doktor Ilmu Ekonomi","Doktor Ilmu Manajemen","Doktor Ilmu Sosial","Lainnya"];
const HARDSKILLS_OPTIONS = [
  "Operasional Mesin Printing", "Operasional Mesin Extru", "Operasional Mesin Dry",
  "Operasional Mesin Slitting", "Operasional Mesin Bag Making", "Operasional Mesin rewind",
  "Colour Matching", "Pest Control Management", "Pengelolaan Limbah", "Total Quality Maintanance (TQM)",
  "Six Sigma", "5 R", "Keselamatan & Kesehatan Kerja (K3)", "International Standard Organization (ISO)",
  "Manajemen Halal", "Quality Control", "Brevet", "Microsoft Excel", "Interview", "Editing Photo",
  "MySql", "Sales Marketing", "B2B Sales", "B2C Sales", "Legal", "Legal Document", "Admin finance",
  "Corporate finance", "Cost control", "Canva", "Video editing", "Adobe Photoshop", "Purchasing",
  "Procurement", "Production Planning & Inventory Control", "Maintenance", "Warehouse Management",
  "Accounting", "Training Management", "Industrial relation", "General Affair Management", "Audit Management"
];
const JOB_OPTIONS = ["DIREKTUR PABRIKASI","DIREKTUR UTAMA","GENERAL MANAGER","IT, TEKNIK MANAGER","SUPPLY CHAIN MANAGER","QA MANAGER","PRODUKSI MANAGER","SALES MANAGER","HCGA MANAGER","FAT MANAGER","PROCUREMENT MANAGER","TEKNIK SUPERVISOR","PRODUKSI SUPERVISOR","QC SUPERVISOR","WAREHOUSE SUPERVISOR","LABORATORIUM SUPERVISOR","PPIC SUPERVISOR","R & D SUPERVISOR","QMS SUPERVISOR","FINANCE SUPERVISOR","STAFF COLOR MATCHING","OPERATOR TINTA","OPERATOR PRINTING","OPERATOR DRY","OPERATOR SLITTING","OPERATOR REWIND","OPERATOR INSPECTION","OPERATOR BAG MAKING","INSPEKTOR LAMINASI","INSPEKTOR PRINTING","INSPEKTOR SLITTING","INSPEKTOR BAG MAKING","STAFF ADMIN QA","INSPEKTOR LAB","STAFF TEKNIK","CORPORATE SALES","STAFF ADMIN SALES","STAFF CASHIER","STAFF ADMIN GA","STAFF ADMIN PRODUKSI LAPANGAN","STAFF HUMAS","STAFF ADMIN HC","STAFF ADMIN INVENTORY","STAFF ADMIN WAREHOUSE FG","STAFF ADMIN SUPPLY CHAIN","STAFF ADMIN PPIC","STAFF ADMIN PRODUKSI SYSTEM","STAFF ADMIN ACCOUNTING","STAFF ADMIN TEKNIK & IT","STAFF ADMIN WAREHOUSE RM","STAFF ADMIN CYLINDER","STAFF ADMIN TAX","STAFF ADMIN PROCUREMENT","STAFF SMO","HELPER"];


export const printHTML = (htmlContent: string, title?: string, subtitle?: string) => {
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Gagal membuka jendela cetak. Mohon izinkan pop-up untuk situs ini.');
    return;
  }
  
  const pageTitle = title ? `Laporan - ${title}` : document.title;
  const printDate = new Date().toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'long' });
  
  const customStyles = `
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
      
      @page {
        size: A4 portrait;
        margin: 8mm 8mm 10mm 8mm;
      }

      * {
        box-sizing: border-box !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }
      body { 
        padding: 0 !important;
        margin: 0 !important;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
        color: #1e293b;
        background: #ffffff !important;
        font-size: 10.5px;
        line-height: 1.35;
        width: 100% !important;
        max-width: 100% !important;
      }
      .print-doc-container {
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
      }
      img {
        max-width: 100% !important;
        display: inline-block !important;
        page-break-inside: avoid !important;
      }
      .print-header {
        border-bottom: 2px solid #2563eb;
        margin-bottom: 12px;
        padding-bottom: 8px;
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
      }
      .print-header h1 {
        font-size: 18px;
        font-weight: 800;
        color: #0f172a;
        margin: 0;
        line-height: 1.2;
      }
      .print-header .subtitle {
        font-size: 12px;
        font-weight: 600;
        color: #2563eb;
        margin-top: 3px;
        margin-bottom: 0;
      }
      .print-header .print-date {
        font-size: 10px;
        color: #64748b;
        text-align: right;
        margin: 0;
      }
      table { 
        width: 100% !important; 
        max-width: 100% !important;
        border-collapse: collapse !important; 
        font-size: 10px;
        margin-bottom: 10px;
        page-break-inside: auto;
        table-layout: fixed !important;
        box-sizing: border-box;
      }
      tr {
        page-break-inside: avoid;
        page-break-after: auto;
      }
      th, td { 
        border: 1px solid #cbd5e1;
        padding: 4px 6px; 
        text-align: left;
        vertical-align: top;
        word-break: break-word !important;
        overflow-wrap: break-word !important;
        white-space: normal !important;
        box-sizing: border-box;
      }
      th {
        background-color: #f8fafc !important;
        font-weight: 700;
        color: #334155;
        font-size: 10px;
      }
      .table-wrapper {
        margin-top: 4px;
        margin-bottom: 6px;
        width: 100% !important;
        overflow: hidden;
      }
      .section-title {
        font-size: 11px;
        font-weight: 700;
        margin-top: 12px;
        margin-bottom: 6px;
        color: #0f172a;
        background-color: #f1f5f9;
        border-left: 3px solid #2563eb;
        padding: 4px 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        page-break-after: avoid;
      }
      .key-column {
        width: 28% !important;
        background-color: #f8fafc !important;
        font-weight: 600;
        color: #475569;
      }
      .compact-table {
        font-size: 8.5px !important;
      }
      .compact-table th, .compact-table td {
        padding: 3px 4px !important;
        font-size: 8.5px !important;
        line-height: 1.25 !important;
      }
      @media print {
        body { 
          padding: 0 !important; 
          margin: 0 !important;
        }
        .print-header {
          margin-bottom: 8px;
        }
      }
    </style>
  `;

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <meta name="referrer" content="no-referrer" />
        <title>${pageTitle}</title>
        ${customStyles}
      </head>
      <body>
        <div class="print-doc-container">
          ${(title || subtitle) ? `
            <div class="print-header">
              <div>
                ${title ? `<h1>${title}</h1>` : ''}
                ${subtitle ? `<p class="subtitle">${subtitle}</p>` : ''}
              </div>
              <p class="print-date">Dicetak pada: ${printDate}</p>
            </div>
          ` : ''}
          ${htmlContent}
        </div>
        
        <script>
           function triggerPrint() {
             const imgs = Array.from(document.images);
             if (imgs.length === 0) {
               window.focus();
               window.print();
               return;
             }
             let loaded = 0;
             const done = () => {
               loaded++;
               if (loaded >= imgs.length) {
                 setTimeout(() => {
                   window.focus();
                   window.print();
                 }, 400);
               }
             };
             imgs.forEach(img => {
               if (img.complete && img.naturalHeight !== 0) {
                 done();
               } else {
                 img.onload = done;
                 img.onerror = done;
               }
             });
           }
           if (document.readyState === 'complete') {
             setTimeout(triggerPrint, 300);
           } else {
             window.addEventListener('load', () => setTimeout(triggerPrint, 300));
           }
        </script>
      </body>
    </html>
  `);

  printWindow.document.close();
};

export const printElement = (elementId: string, title?: string, subtitle?: string) => {
  const printContent = document.getElementById(elementId);
  if (!printContent) {
    console.error(`Element with id ${elementId} not found.`);
    alert('Area yang akan dicetak tidak ditemukan.');
    return;
  }

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Gagal membuka jendela cetak. Mohon izinkan pop-up untuk situs ini.');
    return;
  }
  
  const pageTitle = title ? `Laporan - ${title}` : document.title;
  const printDate = new Date().toLocaleString('id-ID', { dateStyle: 'full', timeStyle: 'long' });
  
  const customStyles = `
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
      * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }
      body { 
        padding: 1.5rem; 
        font-family: 'Inter', sans-serif; 
        color: #334155;
      }
      img {
        max-width: 100% !important;
        display: inline-block !important;
        page-break-inside: avoid !important;
      }
      .print-header {
        border-bottom: 2px solid #e2e8f0;
        margin-bottom: 1.5rem;
        padding-bottom: 1rem;
      }
      .print-header h1 {
        font-size: 1.875rem;
        font-weight: 800;
        color: #1e293b;
        margin: 0;
      }
      .print-header .subtitle {
        font-size: 1.125rem;
        font-weight: 500;
        color: #64748b;
        margin-top: 0.25rem;
        margin-bottom: 0.5rem;
      }
      .print-header .print-date {
        font-size: 0.875rem;
        color: #475569;
      }
      table { 
        width: 100%; 
        border-collapse: collapse; 
        font-size: 0.875rem;
        page-break-inside: auto;
      }
      tr {
        page-break-inside: avoid;
        page-break-after: auto;
      }
      th, td { 
        border: 1px solid #e2e8f0;
        padding: 10px 12px; 
        text-align: left;
        vertical-align: top;
      }
      thead {
        background-color: #f1f5f9;
        color: #475569;
        display: table-header-group;
      }
      tbody {
        display: table-row-group;
      }
      th { 
        font-weight: 600;
      }
      .font-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
      .font-bold { font-weight: 700; }
      .font-semibold { font-weight: 600; }
      .text-green-600 { color: #16a34a; }
      .text-amber-600 { color: #d97706; }
      .text-blue-700 { color: #1d4ed8; }
      .text-lg { font-size: 1.125rem; }
      .text-center { text-align: center; }
      .flex { display: flex; }
      .justify-between { justify-content: space-between; }
      .items-center { align-items: center; }
      .grid { display: grid; }
      .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .gap-4 { gap: 1rem; }
      .my-4 { margin-top: 1rem; margin-bottom: 1rem; }
      .space-y-4 > :not([hidden]) ~ :not([hidden]) { margin-top: 1rem; }
      .text-2xl { font-size: 1.5rem; }
      .bg-gray-100 { background-color: #f3f4f6; }
      .px-4 { padding-left: 1rem; padding-right: 1rem; }
      .py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
      .rounded-lg { border-radius: 0.5rem; }
      
      .print-section {
        page-break-inside: avoid;
      }
      .print-section + .print-section {
        margin-top: 2.5rem;
        padding-top: 1.5rem;
        border-top: 1px dashed #cbd5e1;
      }

      /* --- PRINT-SPECIFIC OVERRIDES --- */
      .print-hidden, .print\\:hidden { display: none !important; }
      
    </style>
  `;

  // Grab the component styles to apply Tailwind classes correctly if needed
  const styles = Array.from(document.styleSheets)
    .map(styleSheet => {
      try {
        return Array.from(styleSheet.cssRules)
          .map(rule => rule.cssText)
          .join('');
      } catch (e) {
        return '';
      }
    })
    .filter(Boolean)
    .join('\n');

  const contentHTML = printContent.innerHTML;

  printWindow.document.write(`
    <html>
      <head>
        <title>${pageTitle}</title>
        <style>${styles}</style>
        ${customStyles}
      </head>
      <body>
        <div class="print-header">
          ${title ? `<h1>${title}</h1>` : ''}
          ${subtitle ? `<p class="subtitle">${subtitle}</p>` : ''}
          <p class="print-date">Dicetak pada: ${printDate}</p>
        </div>
        ${contentHTML}
        
        <script>
           function triggerPrint() {
             const imgs = Array.from(document.images);
             const promises = imgs.map(img => {
               if (img.complete && img.naturalHeight !== 0) return Promise.resolve();
               return new Promise(resolve => {
                 img.onload = resolve;
                 img.onerror = resolve;
               });
             });
             Promise.all(promises).then(() => {
               setTimeout(() => {
                 window.focus();
                 window.print();
               }, 300);
             });
           }
           if (document.readyState === 'complete') {
             triggerPrint();
           } else {
             window.addEventListener('load', triggerPrint);
           }
        </script>
      </body>
    </html>
  `);

  printWindow.document.close();
};

const parsePipeTable = (text: string) => {
  if (!text || typeof text !== 'string' || !text.includes('|') || !text.includes('\n')) return null;
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (lines.length === 0) return null;
  const headers = lines[0].split('|').map(c => c.trim());
  const rows = lines.slice(1).map(l => l.split('|').map(c => c.trim()));
  return { headers, rows };
};

const getColWidths = (title: string, headers: string[]): string[] => {
  const numCols = headers.length;
  const cleanTitle = title.toLowerCase();

  if (cleanTitle.includes('pekerjaan')) {
    if (numCols === 10) return ['7%', '7%', '16%', '12%', '9%', '6%', '9%', '9%', '8%', '17%'];
    if (numCols === 11) return ['6%', '6%', '15%', '11%', '9%', '6%', '8%', '8%', '7%', '14%', '10%'];
  }
  if (cleanTitle.includes('keluarga')) {
    if (numCols === 7) return ['14%', '22%', '6%', '6%', '17%', '17%', '18%'];
  }
  if (cleanTitle.includes('pendidikan') && cleanTitle.includes('formal')) {
    if (numCols === 7) return ['12%', '24%', '15%', '21%', '9%', '9%', '10%'];
    if (numCols === 8) return ['10%', '22%', '14%', '18%', '8%', '8%', '10%', '10%'];
  }
  if (cleanTitle.includes('kursus') || cleanTitle.includes('pelatihan')) {
    if (numCols === 6) return ['20%', '25%', '18%', '14%', '9%', '14%'];
  }
  if (cleanTitle.includes('bahasa')) {
    if (numCols === 5) return ['28%', '18%', '18%', '18%', '18%'];
  }
  if (cleanTitle.includes('kegiatan') || cleanTitle.includes('sosial')) {
    if (numCols === 4) return ['30%', '32%', '24%', '14%'];
  }
  if (cleanTitle.includes('membaca')) {
    if (numCols === 4) return ['20%', '20%', '40%', '20%'];
  }
  if (cleanTitle.includes('referensi')) {
    if (numCols === 5) return ['20%', '30%', '18%', '17%', '15%'];
  }
  if (cleanTitle.includes('kontak') || cleanTitle.includes('darurat')) {
    if (numCols === 4) return ['25%', '35%', '22%', '18%'];
  }
  if (cleanTitle.includes('kuesioner')) {
    if (numCols === 3) return ['55%', '15%', '30%'];
  }

  const pct = (100 / numCols).toFixed(1) + '%';
  return Array(numCols).fill(pct);
};

const renderPrintTable = (title: string, text: string) => {
  const parsed = parsePipeTable(text);
  if (!parsed || parsed.rows.length === 0) {
    return `<p style="color: #64748b; font-size: 10px; margin: 4px 0;">-</p>`;
  }
  const { headers, rows } = parsed;
  const colWidths = getColWidths(title, headers);
  const isCompact = headers.length >= 8 || title.toLowerCase().includes('pekerjaan');

  let html = `<div class="table-wrapper" style="width: 100%; margin-bottom: 6px;">`;
  html += `<table class="${isCompact ? 'compact-table' : ''}" style="width: 100% !important; table-layout: fixed !important; border-collapse: collapse;">`;
  html += `<colgroup>`;
  colWidths.forEach(w => {
    html += `<col style="width: ${w};" />`;
  });
  html += `</colgroup>`;
  html += `<thead><tr>`;
  headers.forEach((h, i) => {
    html += `<th style="width: ${colWidths[i]}; font-weight: 700;">${h}</th>`;
  });
  html += `</tr></thead><tbody>`;
  rows.forEach(row => {
    html += `<tr>`;
    headers.forEach((_, i) => {
      const cellVal = row[i] !== undefined && row[i] !== '' ? row[i] : '-';
      html += `<td>${cellVal}</td>`;
    });
    html += `</tr>`;
  });
  html += `</tbody></table></div>`;
  return html;
};

export const generatePelamarPrintHTML = (applicant: any) => {
  if (!applicant || !applicant.rawData) return '';
  
  const rawData = applicant.rawData;
  
  // Extract images with fallback key detection
  let rawFoto = rawData['Foto Pelamar (URL)'] || rawData['Foto KTP (URL)'] || rawData['Foto KTP (Base64)'] || rawData['foto_pelamar'] || rawData['Foto Pelamar'] || rawData['Foto'] || rawData['foto'];
  if (!rawFoto) {
    const fotoKey = Object.keys(rawData).find(k => k.toLowerCase().includes('foto pelamar') || k.toLowerCase().includes('foto_pelamar'));
    if (fotoKey) rawFoto = rawData[fotoKey];
  }

  let rawTtd = rawData['Tanda Tangan (URL)'] || rawData['Tanda Tangan (Base64)'] || rawData['Tanda Tangan'] || rawData['ttd'] || rawData['tanda_tangan'] || rawData['Tanda Tangan Pelamar'] || rawData['signature'];
  if (!rawTtd) {
    const ttdKey = Object.keys(rawData).find(k => k.toLowerCase().includes('tanda tangan') || k.toLowerCase().includes('ttd') || k.toLowerCase().includes('signature'));
    if (ttdKey) rawTtd = rawData[ttdKey];
  }

  const fotoUrl = formatImageUrl(rawFoto);
  const ttdUrl = formatImageUrl(rawTtd);
  const kotaTtd = rawData['Tempat/Kota Tanda Tangan'] || rawData['kota_ttd'] || '';
  const tglTtd = rawData['Tanggal Tanda Tangan'] || rawData['tanggal_ttd'] || '';
  const namaPelamar = rawData['Nama Lengkap'] || rawData['Nama Lengkap / Nama Kecil'] || applicant?.nama || 'Pelamar';
  const statusPelamar = applicant?.status && applicant?.status !== '-' ? applicant?.status : (rawData['Status'] || 'Kirim WA');
  const posisiDilamar = rawData['Posisi / Pekerjaan Dilamar'] || applicant?.posisi || '-';
  const noReg = applicant?.kode || '-';
  const tglSubmit = applicant?.tanggalMasuk || rawData['Tanggal Masuk'] || '-';

  let html = '';

  // 1. Profile Header Card
  html += `
    <div style="display: flex; justify-content: flex-start; align-items: center; gap: 16px; border: 2px solid #2563eb; padding: 12px 16px; border-radius: 6px; background-color: #f8fafc; margin-bottom: 12px;">
      ${fotoUrl ? `
        <div style="text-align: center; flex-shrink: 0;">
          <img src="${fotoUrl}" referrerpolicy="no-referrer" style="width: 95px; height: 120px; object-fit: cover; border-radius: 4px; border: 1px solid #cbd5e1; display: block;" />
          <span style="font-size: 9px; color: #64748b; margin-top: 2px; display: block; font-weight: 600;">PAS FOTO</span>
        </div>
      ` : ''}
      <div style="flex: 1;">
        <h2 style="margin: 0 0 2px 0; font-size: 18px; font-weight: 800; color: #0f172a;">${namaPelamar}</h2>
        <p style="margin: 0 0 6px 0; font-size: 13px; font-weight: 700; color: #2563eb;">${posisiDilamar}</p>
        <div style="font-size: 11px; color: #334155; display: flex; flex-wrap: wrap; gap: 12px; align-items: center;">
          <span>No Reg: <strong>${noReg}</strong></span>
          <span>|</span>
          <span>Tgl Submit: <strong>${tglSubmit}</strong></span>
          <span>|</span>
          <span>Status: <strong style="color: #2563eb;">${statusPelamar}</strong></span>
        </div>
      </div>
    </div>
  `;

  // 2. Personal Information (Identitas Diri)
  const personalInfoKeys = [
     'Posisi / Pekerjaan Dilamar', 'Tanggal Masuk', 'Timestamp (Waktu Submit)', 
     'Nama Lengkap', 'Nama Lengkap / Nama Kecil', 
     'Gender', 'Jenis Kelamin', 
     'No KTP', 'Nomor KTP / SIM', 'No NPWP', 'No SIM A', 'No SIM B', 'No SIM C',
     'Tempat Lahir', 'Tanggal Lahir', 
     'Agama', 'Kebangsaan', 'Status Perkawinan', 
     'Alamat Sesuai KTP', 'Alamat Tempat Tinggal Saat Ini', 'Alamat Lengkap KTP', 'Alamat Domisili', 
     'No. Hp/Telp', 'No. Hp/Telp Domisil', 'No. Telepon / HP', 'Email', 
     'Tinggi Badan (cm)', 'Berat Badan (kg)', 
     'Status Tempat Tinggal (Pribadi/Sewa/dll)',
     'Kendaraan (Jenis/Merk/Tahun)',
     'Status Kepemilikan Kendaraan (Pribadi/Orang Tua/dll)'
  ];

  html += '<div class="section-title">1. DATA PRIBADI & IDENTITAS</div>';
  html += '<table style="width: 100% !important; table-layout: fixed !important;"><colgroup><col style="width: 28%;" /><col style="width: 72%;" /></colgroup><tbody>';
  personalInfoKeys.forEach(key => {
    if (rawData[key] && rawData[key] !== '-' && rawData[key] !== '-\n-') {
      let displayValue = rawData[key];
      if (key === 'Tanggal Lahir') displayValue = formatTanggalLahirIndo(String(rawData[key]));
      if (key === 'Timestamp (Waktu Submit)') displayValue = formatDateTimeIndo(String(rawData[key]));
      html += `<tr><td class="key-column">${key}</td><td>${String(displayValue).replace(/\n/g, '<br/>')}</td></tr>`;
    }
  });
  html += '</tbody></table>';

  // 3. Susunan Keluarga (Full Width)
  if (rawData['Data Susunan Keluarga'] && rawData['Data Susunan Keluarga'] !== '-' && rawData['Data Susunan Keluarga'] !== '-\n-') {
    html += '<div class="section-title">2. DATA SUSUNAN KELUARGA</div>';
    html += renderPrintTable('Data Susunan Keluarga', rawData['Data Susunan Keluarga']);
  }

  // 4. Pendidikan Formal (Full Width)
  if (rawData['Riwayat Pendidikan Formal'] || rawData['Tingkat Pendidikan Terakhir']) {
    html += '<div class="section-title">3. RIWAYAT PENDIDIKAN FORMAL</div>';
    if (rawData['Tingkat Pendidikan Terakhir'] && rawData['Tingkat Pendidikan Terakhir'] !== '-') {
      html += `<div style="margin-bottom: 6px; font-size: 11px; color: #334155;"><strong>Tingkat Pendidikan Terakhir:</strong> ${rawData['Tingkat Pendidikan Terakhir']}</div>`;
    }
    if (rawData['Riwayat Pendidikan Formal'] && rawData['Riwayat Pendidikan Formal'] !== '-' && rawData['Riwayat Pendidikan Formal'] !== '-\n-') {
      html += renderPrintTable('Riwayat Pendidikan Formal', rawData['Riwayat Pendidikan Formal']);
    }
  }

  // 5. Kursus / Pelatihan (Full Width)
  if (rawData['Riwayat Kursus / Pelatihan'] && rawData['Riwayat Kursus / Pelatihan'] !== '-' && rawData['Riwayat Kursus / Pelatihan'] !== '-\n-') {
    html += '<div class="section-title">4. RIWAYAT KURSUS & PELATIHAN</div>';
    html += renderPrintTable('Riwayat Kursus / Pelatihan', rawData['Riwayat Kursus / Pelatihan']);
  }

  // 6. Kemampuan Bahasa Asing (Full Width)
  if (rawData['Kemampuan Bahasa Asing'] && rawData['Kemampuan Bahasa Asing'] !== '-' && rawData['Kemampuan Bahasa Asing'] !== '-\n-') {
    html += '<div class="section-title">5. KEMAMPUAN BAHASA ASING</div>';
    html += renderPrintTable('Kemampuan Bahasa Asing', rawData['Kemampuan Bahasa Asing']);
  }

  // 7. Keterampilan & Aktivitas
  const hasSkill = rawData['Teknikal / Hardskill'] && rawData['Teknikal / Hardskill'] !== '-';
  const hasKegiatan = rawData['Kegiatan Sosial / Olahraga / Hobi'] && rawData['Kegiatan Sosial / Olahraga / Hobi'] !== '-';
  const hasHobi = rawData['Hobi dan Minat'] && rawData['Hobi dan Minat'] !== '-';
  const hasMembaca = rawData['Frekuensi Membaca Buku / Majalah'] && rawData['Frekuensi Membaca Buku / Majalah'] !== '-';

  if (hasSkill || hasKegiatan || hasHobi || hasMembaca) {
    html += '<div class="section-title">6. KETERAMPILAN, AKTIVITAS & MINAT</div>';
    if (hasSkill) {
      html += `<table style="width: 100% !important; table-layout: fixed !important; margin-bottom: 6px;"><colgroup><col style="width: 28%;" /><col style="width: 72%;" /></colgroup><tbody><tr><td class="key-column">Teknikal / Hardskill</td><td>${rawData['Teknikal / Hardskill']}</td></tr></tbody></table>`;
    }
    if (hasKegiatan) {
      html += `<div style="font-weight: 600; font-size: 10.5px; margin: 4px 0 2px 0; color: #334155;">Kegiatan Sosial / Olahraga / Organisasi:</div>`;
      html += renderPrintTable('Kegiatan Sosial / Olahraga / Hobi', rawData['Kegiatan Sosial / Olahraga / Hobi']);
    }
    if (hasHobi) {
      html += `<table style="width: 100% !important; table-layout: fixed !important; margin-bottom: 6px;"><colgroup><col style="width: 28%;" /><col style="width: 72%;" /></colgroup><tbody><tr><td class="key-column">Hobi dan Minat</td><td>${rawData['Hobi dan Minat']}</td></tr></tbody></table>`;
    }
    if (hasMembaca) {
      html += `<div style="font-weight: 600; font-size: 10.5px; margin: 4px 0 2px 0; color: #334155;">Frekuensi Membaca Buku / Majalah:</div>`;
      html += renderPrintTable('Frekuensi Membaca Buku / Majalah', rawData['Frekuensi Membaca Buku / Majalah']);
    }
  }

  // 8. Riwayat Pekerjaan Sebelumnya (Full Width Compact Table)
  if (rawData['Riwayat Pekerjaan Sebelumnya'] && rawData['Riwayat Pekerjaan Sebelumnya'] !== '-' && rawData['Riwayat Pekerjaan Sebelumnya'] !== '-\n-') {
    html += '<div class="section-title">7. RIWAYAT PENGALAMAN KERJA</div>';
    html += renderPrintTable('Riwayat Pekerjaan Sebelumnya', rawData['Riwayat Pekerjaan Sebelumnya']);
    
    if (rawData['Uraian Tugas & Tanggung Jawab Sebelumnya'] && rawData['Uraian Tugas & Tanggung Jawab Sebelumnya'] !== '-') {
      html += `<div style="margin-top: 6px; border: 1px solid #cbd5e1; padding: 6px 8px; background-color: #f8fafc; border-radius: 4px; font-size: 10px;">
        <strong style="color: #0f172a; display: block; margin-bottom: 2px;">Uraian Tugas & Tanggung Jawab Sebelumnya:</strong>
        <div style="white-space: pre-wrap; color: #334155;">${rawData['Uraian Tugas & Tanggung Jawab Sebelumnya']}</div>
      </div>`;
    }

    if (rawData['Gambaran Struktur Organisasi Sebelumnya'] && rawData['Gambaran Struktur Organisasi Sebelumnya'] !== '-') {
      html += `<div style="margin-top: 6px; border: 1px solid #cbd5e1; padding: 6px 8px; background-color: #f8fafc; border-radius: 4px; font-size: 10px;">
        <strong style="color: #0f172a; display: block; margin-bottom: 2px;">Gambaran Struktur Organisasi Sebelumnya:</strong>
        <div style="white-space: pre-wrap; color: #334155;">${rawData['Gambaran Struktur Organisasi Sebelumnya']}</div>
      </div>`;
    }
  }

  // 9. Referensi & Kontak Darurat
  const refKey = Object.keys(rawData).find(k => k.toLowerCase().startsWith('referensi'));
  const hasRef = refKey && rawData[refKey] && rawData[refKey] !== '-';
  const hasEmergency = rawData['Kontak Darurat'] && rawData['Kontak Darurat'] !== '-';

  if (hasRef || hasEmergency) {
    html += '<div class="section-title">8. REFERENSI & KONTAK DARURAT</div>';
    if (hasRef) {
      html += `<div style="font-weight: 600; font-size: 10.5px; margin: 4px 0 2px 0; color: #334155;">Referensi (Pihak yang dapat dihubungi):</div>`;
      html += renderPrintTable('Referensi', rawData[refKey]);
    }
    if (hasEmergency) {
      html += `<div style="font-weight: 600; font-size: 10.5px; margin: 4px 0 2px 0; color: #334155;">Kontak Darurat (Emergency Contact):</div>`;
      html += renderPrintTable('Kontak Darurat', rawData['Kontak Darurat']);
    }
  }

  // 10. Kuesioner
  const kuesionerKeys = Object.keys(rawData).filter(k => k.toLowerCase().startsWith('kuesioner'));
  if (kuesionerKeys.length > 0) {
    html += '<div class="section-title">9. KUESIONER & PERNYATAAN KESEDIAAN</div>';
    html += '<table style="width: 100% !important; table-layout: fixed !important;"><colgroup><col style="width: 5%;" /><col style="width: 60%;" /><col style="width: 35%;" /></colgroup><thead><tr><th>No</th><th>Pertanyaan</th><th>Jawaban & Keterangan</th></tr></thead><tbody>';
    kuesionerKeys.forEach((k, idx) => {
      const qText = k.replace(/^kuesioner\s*[-–:]\s*/i, '').trim();
      const answer = rawData[k] || '-';
      html += `<tr><td style="text-align: center;">${idx + 1}</td><td>${qText}</td><td>${answer}</td></tr>`;
    });
    html += '</tbody></table>';
  }

  // 11. Informasi Tambahan
  const infoTambahanKeys = [
    'Sumber Informasi Lowongan',
    'Mengapa Anda Ingin Bekerja di Perusahaan Ini',
    'Jenis Pekerjaan Sesuai Cita-cita',
    'Jenis Pekerjaan Tidak Disenangi & Alasan',
    'Kapan Mulai Siap Bekerja'
  ];
  const hasInfoTambahan = infoTambahanKeys.some(k => rawData[k] && rawData[k] !== '-');
  if (hasInfoTambahan) {
    html += '<div class="section-title">10. INFORMASI TAMBAHAN</div>';
    html += '<table style="width: 100% !important; table-layout: fixed !important;"><colgroup><col style="width: 28%;" /><col style="width: 72%;" /></colgroup><tbody>';
    infoTambahanKeys.forEach(k => {
      if (rawData[k] && rawData[k] !== '-') {
        html += `<tr><td class="key-column">${k}</td><td>${String(rawData[k]).replace(/\n/g, '<br/>')}</td></tr>`;
      }
    });
    html += '</tbody></table>';
  }

  // 12. Lembar Tanda Tangan
  html += `
    <div style="margin-top: 24px; width: 100%; page-break-inside: avoid; display: flex; justify-content: flex-end;">
       <div style="text-align: center; min-width: 220px;">
          <p style="margin: 0 0 4px 0; font-size: 11px; color: #475569;">${kotaTtd ? kotaTtd + ', ' : ''}${tglTtd || tglSubmit}</p>
          <p style="margin: 0 0 6px 0; font-size: 11px; font-weight: 600; color: #334155;">Pelamar Pekerjaan,</p>
          ${ttdUrl ? `
            <div style="height: 70px; display: flex; align-items: center; justify-content: center; margin: 4px 0;">
              <img src="${ttdUrl}" referrerpolicy="no-referrer" style="max-height: 65px; max-width: 180px; object-fit: contain; border: 1px solid #cbd5e1; padding: 2px; background-color: #ffffff; border-radius: 4px;" />
            </div>
          ` : `
            <div style="height: 60px; margin: 6px 0; border-bottom: 1px dashed #94a3b8;"></div>
          `}
          <p style="margin: 4px 0 0 0; font-weight: bold; font-size: 12px; text-decoration: underline; color: #0f172a;">( ${namaPelamar} )</p>
       </div>
    </div>
  `;

  return html;
};

const FormatAsReactTable = ({ text }: { text: string }) => {
   if (!text || text === '-' || text === '-\n-') return <span className="font-medium text-gray-800 text-sm whitespace-pre-wrap">{text}</span>;
   if (text.includes('\n') && text.includes('|')) {
      const rows = text.split('\n').filter(r => r.trim());
      const headerRow = rows[0];
      const dataRows = rows.slice(1);
      
      return (
         <div className="overflow-x-auto rounded border border-gray-200 mt-2">
            <table className="w-full text-sm text-left border-collapse">
               <thead>
                  <tr className="bg-gray-50 text-gray-700 font-semibold border-b">
                     {headerRow.split('|').map((col, j) => (
                        <th key={j} className="p-2 border-r last:border-r-0 whitespace-nowrap font-semibold">{col.trim()}</th>
                     ))}
                  </tr>
               </thead>
               <tbody>
                  {dataRows.map((row, i) => (
                    <tr key={i} className="border-b last:border-b-0 hover:bg-gray-50">
                        {row.split('|').map((col, j) => (
                           <td key={j} className="p-2 border-r last:border-r-0 whitespace-nowrap">{col.trim()}</td>
                        ))}
                    </tr>
                  ))}
               </tbody>
            </table>
         </div>
      );
   }
   if (text.includes('Bulan:') && text.includes('Tahun:')) {
      const entries = text.split('\n\n').filter(r => r.trim());
      return (
         <div className="space-y-2 mt-2">
            {entries.map((entry, i) => (
               <div key={i} className="border border-gray-200 p-3 rounded bg-gray-50 text-sm font-medium text-gray-800 whitespace-pre-wrap">
                  {entry}
               </div>
            ))}
         </div>
      );
   }
   return <span className="font-medium text-gray-800 text-sm whitespace-pre-wrap">{text}</span>;
};

const formatWhatsAppNumber = (phoneStr: string | number) => {
  if (!phoneStr) return '';
  let phone = String(phoneStr).replace(/\D/g, '');
  if (phone.startsWith('0')) return '62' + phone.substring(1);
  if (phone.startsWith('8')) return '62' + phone;
  return phone;
};

const formatDateTimeIndo = (dateStr: string) => {
  if (!dateStr || dateStr === '-') return '-';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  
  const formatter = new Intl.DateTimeFormat('id-ID', { dateStyle: 'full', timeStyle: 'long' });
  return formatter.format(d).replace('pukul', 'pukul').replace(/\./g, ':'); // Intl gives something close
};

const formatTanggalLahirIndo = (dateStr: string) => {
  return formatTanggalIndo(dateStr);
};


function parseDOB(dateStr: string): Date {
   let d = new Date(dateStr);
   if (!isNaN(Number(dateStr)) && Number(dateStr) > 10000 && Number(dateStr) < 100000) {
      d = new Date(Math.round((Number(dateStr) - 25569) * 86400 * 1000));
   }
   return d;
}

const formatTanggalIndo = (dateStr: string) => {
  if (!dateStr || dateStr === '-') return '-';
  const cleanStr = String(dateStr).trim();
  const monthsIndo = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

  // Try standard number (Excel serial date) first
  if (!isNaN(Number(cleanStr)) && Number(cleanStr) > 10000 && Number(cleanStr) < 100000) {
      const d = new Date(Math.round((Number(cleanStr) - 25569) * 86400 * 1000));
      if (!isNaN(d.getTime())) {
         return `${String(d.getDate()).padStart(2, '0')} ${monthsIndo[d.getMonth()]} ${d.getFullYear()}`;
      }
  }

  // Check if it's already in DD MMMM YYYY format
  const matchesIndo = cleanStr.match(/^(\d{1,2})\s+(Januari|Februari|Maret|April|Mei|Juni|Juli|Agustus|September|Oktober|November|Desember)\s+(\d{4})/i);
  if (matchesIndo) {
     return `${String(parseInt(matchesIndo[1], 10)).padStart(2, '0')} ${matchesIndo[2]} ${matchesIndo[3]}`;
  }

  // Try custom split for formats like "DD/MM/YYYY" or "DD-MM-YYYY" or "YYYY-MM-DD"
  const parts = cleanStr.split(/[\/\-\s]+/);
  if (parts.length >= 3) {
     let day = 1, month = 0, year = 1970;
     // Is first part a 4-digit year? "YYYY/MM/DD"
     if (parts[0].length === 4) {
        year = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10) - 1;
        day = parseInt(parts[2], 10);
     } 
     // Is last part a 4-digit year? "DD/MM/YYYY"
     else if (parts[2].length === 4) {
        year = parseInt(parts[2], 10);
        const val1 = parseInt(parts[0], 10);
        const val2 = parseInt(parts[1], 10);
        
        // Indonesian locale typically uses DD/MM/YYYY
        day = val1;
        month = val2 - 1;
        
        // If month is invalid (e.g. > 11), maybe it's MM/DD/YYYY
        if (month > 11 || month < 0) {
           day = val2;
           month = val1 - 1;
        }
     }
     
     if (year > 1000 && month >= 0 && month <= 11 && day >= 1 && day <= 31) {
        return `${String(day).padStart(2, '0')} ${monthsIndo[month]} ${year}`;
     }
  }

  // Fallback to standard JS Date parsing
  let d = new Date(cleanStr);
  if (!isNaN(d.getTime())) {
     return `${String(d.getDate()).padStart(2, '0')} ${monthsIndo[d.getMonth()]} ${d.getFullYear()}`;
  }

  return dateStr;
};

const orderedPayloadKeys = [
  "Timestamp (Waktu Submit)",
  "Tanggal Masuk",
  "Posisi / Pekerjaan Dilamar",
  "Nama Lengkap / Nama Kecil",
  "Nama Lengkap",
  "Alamat Sesuai KTP",
  "Alamat Tempat Tinggal Saat Ini",
  "Alamat Lengkap KTP",
  "No. Hp/Telp",
  "No. Telepon / HP",
  "Email",
  "Alamat Domisili",
  "No. Hp/Telp Domisil",
  "Jenis Kelamin",
  "Gender",
  "Tinggi Badan (cm)",
  "Berat Badan (kg)",
  "Agama",
  "Kebangsaan",
  "Tempat Lahir",
  "Tanggal Lahir",
  "Status Perkawinan",
  "Nomor KTP / SIM",
  "No KTP",
  "No NPWP",
  "No SIM A",
  "No SIM B",
  "No SIM C",
  "Status Tempat Tinggal (Pribadi/Sewa/dll)",
  "Kendaraan (Jenis/Merk/Tahun)",
  "Status Kepemilikan Kendaraan (Pribadi/Orang Tua/dll)",
  "Data Susunan Keluarga",
  "Tingkat Pendidikan Terakhir",
  "Riwayat Pendidikan Formal",
  "Riwayat Kursus / Pelatihan",
  "Kemampuan Bahasa Asing",
  "Teknikal / Hardskill",
  "Kegiatan Sosial / Olahraga / Hobi",
  "Hobi dan Minat",
  "Frekuensi Membaca Buku / Majalah",
  "Riwayat Pekerjaan Sebelumnya",
  "Uraian Tugas & Tanggung Jawab Sebelumnya",
  "Gambaran Struktur Organisasi Sebelumnya",
  "Referensi (Kepada siapa kami dapat menanyakan mengenai diri anda lebih lengkap)",
  "Kontak Darurat",
  "Kuesioner - Bersedia masa percobaan 3 bulan",
  "Kuesioner - Bersedia memberikan waktu 2 bulan bila mengundurkan diri",
  "Kuesioner - Terikat kontrak dengan perusahaan saat ini",
  "Kuesioner - Bersedia dimutasikan",
  "Kuesioner - Memiliki pekerjaan sampingan",
  "Kuesioner - Mempunyai teman/sanak saudara di perusahaan ini",
  "Kuesioner - Pernah menderita sakit kronis / kecelakaan",
  "Kuesioner - Sedang hamil",
  "Kuesioner - Bersedia tidak hamil dalam 1 tahun",
  "Kuesioner - Bersedia ditempatkan di luar kota",
  "Sumber Informasi Lowongan",
  "Mengapa Anda Ingin Bekerja di Perusahaan Ini",
  "Jenis Pekerjaan Sesuai Cita-cita",
  "Jenis Pekerjaan Tidak Disenangi & Alasan",
  "Kapan Mulai Siap Bekerja",
  "Tempat/Kota Tanda Tangan",
  "Tanggal Tanda Tangan",
  "Tanda Tangan (URL)",
  "Tanda Tangan",
  "Foto Pelamar (URL)",
  "foto_pelamar",
  "CV (URL)",
  "cv_pelamar"
];

const normalizeApplicantRawData = (item: any) => {
  if (!item) return {};
  const normalized = { ...item };
  
  const mappings: { [key: string]: string } = {
    "Alamat Luar Kota": "Alamat Sesuai KTP",
    "No HP / Telp Luar Kota": "No. Hp/Telp",
    "Alamat Dalam Kota": "Alamat Domisili",
    "No HP / Telp Dalam Kota": "No. Hp/Telp Domisil",
    "No HP / Telp Sesuai KTP": "No. Hp/Telp",
    "No HP / Telp Domisili": "No. Hp/Telp Domisil",
    "No. Hp/Telp Domisili": "No. Hp/Telp Domisil",
    "No. HP / Telp Domisil": "No. Hp/Telp Domisil",
    "No HP/Telp Domisil": "No. Hp/Telp Domisil",
    "No. HP/Telp Domisil": "No. Hp/Telp Domisil",
    "No HP/Telp": "No. Hp/Telp",
    "No. HP/Telp": "No. Hp/Telp"
  };

  for (const [oldKey, newKey] of Object.entries(mappings)) {
    if (normalized[oldKey] !== undefined) {
      if (normalized[newKey] === undefined || normalized[newKey] === '-' || normalized[newKey] === '') {
        normalized[newKey] = normalized[oldKey];
      }
      if (oldKey !== newKey) {
        delete normalized[oldKey];
      }
    }
  }

  return normalized;
};

const getOrderIndex = (key: string) => {
    const cleanKey = key.trim().toLowerCase();
    let idx = orderedPayloadKeys.findIndex(k => k.trim().toLowerCase() === cleanKey);
    if (idx !== -1) return idx;
    
    idx = orderedPayloadKeys.findIndex(k => {
        const cleanK = k.trim().toLowerCase();
        return cleanK === cleanKey || cleanK.includes(cleanKey) || cleanKey.includes(cleanK);
    });
    return idx === -1 ? 999 : idx;
};

const getTimestampMs = (timestampStr: any) => {
   if (!timestampStr) return 0;
   const str = String(timestampStr).trim();
   if (!str || str === '-') return 0;
   
   let d = new Date(str);
   if (!isNaN(d.getTime())) return d.getTime();
   
   const parts = str.split(/[\/\-\s,:]+/);
   if (parts.length >= 3) {
      let day = 1, month = 0, year = 1970;
      let hours = 0, minutes = 0, seconds = 0;
      
      if (parts[0].length === 4) {
         year = parseInt(parts[0], 10);
         month = parseInt(parts[1], 10) - 1;
         day = parseInt(parts[2], 10);
      } else if (parts[2].length === 4) {
         const val1 = parseInt(parts[0], 10);
         const val2 = parseInt(parts[1], 10);
         year = parseInt(parts[2], 10);
         day = val1;
         month = val2 - 1;
         if (month > 11) {
            day = val2;
            month = val1 - 1;
         }
      }
      
      if (parts.length >= 6) {
         hours = parseInt(parts[3], 10) || 0;
         minutes = parseInt(parts[4], 10) || 0;
         seconds = parseInt(parts[5], 10) || 0;
         
         const lastPart = parts[parts.length - 1].toLowerCase();
         if (lastPart === 'pm' && hours < 12) hours += 12;
         if (lastPart === 'am' && hours === 12) hours = 0;
      }
      
      const parsedDate = new Date(year, month, day, hours, minutes, seconds);
      if (!isNaN(parsedDate.getTime())) return parsedDate.getTime();
   }
   
   return 0;
};

export function DashboardPage() {
  const navigate = useNavigate();

  // Settings State
  const [companyName, setCompanyName] = useState(localStorage.getItem('setting_company_name') || 'PT Tritunggal Multi Cemerlang');
  const [hrEmail, setHrEmail] = useState(localStorage.getItem('setting_hr_email') || 'hr@tmc-indonesia.com');
  const [candidateFormat, setCandidateFormat] = useState(localStorage.getItem('setting_candidate_format') || 'MMP-[ID]');

  // Documents State
  const [templateInterview, setTemplateInterview] = useState(localStorage.getItem('setting_template_interview') || "Hi (Nama Kandidat),\n\nTerima kasih atas ketertarikan Anda untuk mengisi posisi (Nama Posisi) di Perusahaan Kami.\n\nSetelah mempelajari CV Anda, dengan ini kami mengundang untuk interview pada:\n(Hari & tanggal) – (Pukul) --- missal: Rabu, 11 Mei 2022 - Pukul 14:00\n\nJoin Interview Online melalui: (Link Interview)\n\nMohon konfirmasi kehadiran dengan membalas pesan ini.\nTerima kasih");
  const [templateReject, setTemplateReject] = useState(localStorage.getItem('setting_template_reject') || "Hi (Nama Kandidat),\n\nTerima kasih atas ketertarikan Anda melamar posisi (Nama Posisi). Kami senang dengan minat Anda untuk mengejar peluang karir bersama kami.\n\nSetelah mempelajari CV yang dikirimkan, dengan berat hati kami menginformasikan bahwa kami tidak dapat meneruskan ke tahap selanjutnya.\n\nKami berharap yang terbaik untuk karir Anda.\nTerima kasih.");
  const [templateDiterima, setTemplateDiterima] = useState(localStorage.getItem('setting_template_diterima') || "Hi (Nama Kandidat),\n\nSelamat! Kami dari HC/GA menginformasikan bahwa Anda dinyatakan DITERIMA untuk posisi (Nama Posisi).\n\nMohon merespon pesan ini untuk informasi lanjutan mengenai proses administrasi karyawan baru.\n\nTerima kasih.");

  // Master Data State
  const defaultSkills = ["Microsoft Office", "Finance", "B2B Sales", "Printing", "Extrusion", "Dry", "Quality Control", "Laboratorium", "Slitting", "Bag Making", "Warehouse", "PPIC", "Procurement"];
  

  

  const [eduFilters, setEduFilters] = useState<{tingkat: string, jurusan: string}[]>([]);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [appliedEduFilters, setAppliedEduFilters] = useState<{tingkat: string, jurusan: string}[]>([]);
  const [appliedSelectedSkills, setAppliedSelectedSkills] = useState<string[]>([]);

  
  

  

  


  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [adminUserId, setAdminUserId] = useState(localStorage.getItem('admin_user_id') || 'Admin');
  const [adminUserEmail, setAdminUserEmail] = useState(auth.currentUser?.email || localStorage.getItem('admin_user_email') || '');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const userDocRef = doc(db, 'admin_users', user.uid);
          const userDocSnap = await getDoc(userDocRef);
          let resolvedUserId = user.email ? user.email.split('@')[0] : 'Admin';
          let userEmail = user.email || '';
          
          if (userDocSnap.exists()) {
            const userData = userDocSnap.data();
            if (userData && userData.userId) {
              resolvedUserId = userData.userId;
            }
            if (userData && userData.email) {
              userEmail = userData.email;
            }
          }
          
          setAdminUserId(resolvedUserId);
          setAdminUserEmail(userEmail || user.email || '');
          localStorage.setItem('admin_user_id', resolvedUserId);
          if (userEmail) localStorage.setItem('admin_user_email', userEmail);

          if (userEmail) {
            const map = JSON.parse(localStorage.getItem('admin_user_email_map') || '{}');
            map[resolvedUserId.toLowerCase()] = userEmail.toLowerCase();
            map[userEmail.toLowerCase()] = userEmail.toLowerCase();
            localStorage.setItem('admin_user_email_map', JSON.stringify(map));
          }
        } catch (err) {
          console.error("Error fetching admin user id:", err);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const isSuperAdmin = useMemo(() => {
    const emailLower = (adminUserEmail || auth.currentUser?.email || '').toLowerCase();
    const idLower = (adminUserId || '').toLowerCase();
    return emailLower === 'humas@mmpackaging.co.id' || idLower === 'humas' || idLower === 'humas@mmpackaging.co.id';
  }, [adminUserEmail, adminUserId]);

  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [posisiFilterDropdown, setPosisiFilterDropdown] = useState('');
  const [posisiFilter, setPosisiFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [openDropdownId, setOpenDropdownId] = useState<number | null>(null);
  const [openStatusModalId, setOpenStatusModalId] = useState<number | null>(null);
  const [updateStatusVal, setUpdateStatusVal] = useState('');
  const [updateStatusNote, setUpdateStatusNote] = useState('');
  const [sendWhatsapp, setSendWhatsapp] = useState(false);
  const [generatedMessage, setGeneratedMessage] = useState('');
  const [viewFileModal, setViewFileModal] = useState<{isOpen: boolean, title: string, content: string} | null>(null);
  const [confirmDeleteModal, setConfirmDeleteModal] = useState<{isOpen: boolean, app: any | null}>({isOpen: false, app: null});

  // Super Admin Manual Reset Password States
  const [adminUsersList, setAdminUsersList] = useState<any[]>([]);
  const [isLoadingAdminUsers, setIsLoadingAdminUsers] = useState(false);
  const [selectedUserForReset, setSelectedUserForReset] = useState<any | null>(null);
  const [manualResetPasswordInput, setManualResetPasswordInput] = useState('');
  const [isSavingManualReset, setIsSavingManualReset] = useState(false);
  const [resetSuccessData, setResetSuccessData] = useState<{ userId: string; email: string; pass: string } | null>(null);
  const [isAddAdminModalOpen, setIsAddAdminModalOpen] = useState(false);
  const [newAdminUserId, setNewAdminUserId] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');

  // Self-Service Change Password State (Accessible by all admin users, including non-superadmin)
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [isChangingOwnPass, setIsChangingOwnPass] = useState(false);
  const [ownPassError, setOwnPassError] = useState('');
  const [ownPassSuccess, setOwnPassSuccess] = useState('');

  const handleUpdateOwnPassword = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setOwnPassError('');
    setOwnPassSuccess('');

    const curr = currentPassword.trim();
    const next = newPassword.trim();
    const conf = confirmPassword.trim();

    if (!curr) {
      setOwnPassError('Mohon masukkan password saat ini.');
      return;
    }
    if (!next) {
      setOwnPassError('Mohon masukkan password baru.');
      return;
    }
    if (next.length < 6) {
      setOwnPassError('Password baru minimal harus terdiri dari 6 karakter.');
      return;
    }
    if (next === curr) {
      setOwnPassError('Password baru tidak boleh sama dengan password saat ini.');
      return;
    }
    if (next !== conf) {
      setOwnPassError('Konfirmasi password tidak cocok dengan password baru.');
      return;
    }

    setIsChangingOwnPass(true);

    try {
      const user = auth.currentUser;
      const effectiveEmail = user?.email || adminUserEmail || localStorage.getItem('admin_user_email') || '';

      // 1. If user is authenticated in Firebase Auth, attempt re-authentication & password update
      if (user && effectiveEmail) {
        try {
          const credential = EmailAuthProvider.credential(effectiveEmail, curr);
          await reauthenticateWithCredential(user, credential);
          await updatePassword(user, next);
        } catch (authErr: any) {
          console.warn("Firebase Auth re-auth/updatePassword error:", authErr);
          if (authErr?.code === 'auth/wrong-password' || authErr?.code === 'auth/invalid-credential') {
            setOwnPassError('Password saat ini tidak sesuai. Pastikan Anda memasukkan kata sandi yang benar.');
            setIsChangingOwnPass(false);
            return;
          }
        }
      }

      // 2. Persist update in Firestore admin_users so manual authentication fallback recognizes the new password
      try {
        if (user?.uid) {
          await setDoc(doc(db, 'admin_users', user.uid), {
            userId: adminUserId || (user.email ? user.email.split('@')[0] : 'Admin'),
            email: effectiveEmail,
            manualPassword: next,
            passwordLastChangedAt: new Date().toISOString(),
            passwordLastChangedBy: 'Self'
          }, { merge: true });
        }

        if (adminUserId) {
          await setDoc(doc(db, 'admin_users', adminUserId.toLowerCase()), {
            userId: adminUserId,
            email: effectiveEmail,
            manualPassword: next,
            passwordLastChangedAt: new Date().toISOString(),
            passwordLastChangedBy: 'Self'
          }, { merge: true });
        }

        // Update all documents matching email or userId
        if (effectiveEmail) {
          const usersRef = collection(db, 'admin_users');
          const snap = await getDocs(usersRef);
          for (const d of snap.docs) {
            const data = d.data();
            if (
              (data.email && data.email.toLowerCase() === effectiveEmail.toLowerCase()) ||
              (data.userId && data.userId.toLowerCase() === adminUserId.toLowerCase())
            ) {
              await updateDoc(doc(db, 'admin_users', d.id), {
                manualPassword: next,
                passwordLastChangedAt: new Date().toISOString(),
                passwordLastChangedBy: 'Self'
              });
            }
          }
        }
      } catch (fsErr) {
        console.warn("Firestore sync during password change:", fsErr);
      }

      setOwnPassSuccess('Selamat! Password akun Anda berhasil diperbarui. Silakan gunakan password baru ini saat Anda login berikutnya.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setShowCurrentPass(false);
      setShowNewPass(false);
      setShowConfirmPass(false);
    } catch (err: any) {
      console.error("Ganti password error:", err);
      setOwnPassError(err?.message || 'Terjadi kesalahan saat mengganti password. Silakan coba kembali.');
    } finally {
      setIsChangingOwnPass(false);
    }
  };

  // Company Registration Secret Code (Anti-Intruder Protection for Gmail accounts)
  const [registrationSecretCode, setRegistrationSecretCode] = useState(() => {
    return localStorage.getItem('setting_company_registration_code') || 'MMP-ADMIN-2026';
  });
  const [isSavingSecurityCode, setIsSavingSecurityCode] = useState(false);
  const [copyInviteSuccess, setCopyInviteSuccess] = useState(false);

  useEffect(() => {
    const fetchCompanySecurity = async () => {
      try {
        const secDoc = await getDoc(doc(db, 'app_settings', 'company_security'));
        if (secDoc.exists() && secDoc.data()?.registrationSecretCode) {
          setRegistrationSecretCode(secDoc.data()?.registrationSecretCode.trim());
        }
      } catch (err) {
        // ignore
      }
    };
    fetchCompanySecurity();
  }, []);

  const handleSaveSecurityCode = async () => {
    if (!registrationSecretCode.trim()) {
      alert("Kode registrasi tidak boleh kosong.");
      return;
    }
    setIsSavingSecurityCode(true);
    try {
      await setDoc(doc(db, 'app_settings', 'company_security'), {
        registrationSecretCode: registrationSecretCode.trim(),
        updatedAt: new Date().toISOString(),
        updatedBy: 'humas@mmpackaging.co.id (Super Admin)'
      }, { merge: true });
      localStorage.setItem('setting_company_registration_code', registrationSecretCode.trim());
      alert('Kode Otorisasi Registrasi Perusahaan berhasil disimpan.');
    } catch (err: any) {
      console.warn("Falling back to localStorage:", err);
      localStorage.setItem('setting_company_registration_code', registrationSecretCode.trim());
      alert('Kode Otorisasi Registrasi berhasil disimpan secara lokal.');
    } finally {
      setIsSavingSecurityCode(false);
    }
  };

  const handleCopyInviteMessage = () => {
    const currentOrigin = window.location.origin;
    const msg = `*UNDANGAN RESMI AKSES ADMIN - PORTAL RECRUITMENT MMP*\n\nHalo Rekan HCGA / Tim Admin,\n\nAnda diundang untuk mengakses Dashboard Portal Recruitment PT Mitra Multi Packaging.\n\n*Petunjuk Pendaftaran:*\n1. Buka tautan: ${currentOrigin}/login\n2. Klik *"Daftar di sini"*\n3. Masukkan User ID dan Email Anda (*Direkomendasikan menggunakan akun @gmail.com* agar link Reset Password selalu masuk tanpa terblokir firewall kantor)\n4. Masukkan *Kode Otorisasi Perusahaan*: *${registrationSecretCode.trim()}*\n5. Buat Password Anda.\n\n_PENTING: Demi keamanan data rahasia pelamar, jangan bagikan kode otorisasi ini kepada pihak di luar perusahaan._`;

    navigator.clipboard.writeText(msg);
    setCopyInviteSuccess(true);
    setTimeout(() => setCopyInviteSuccess(false), 3000);
  };

  const fetchAdminUsers = async () => {
    setIsLoadingAdminUsers(true);
    try {
      const usersRef = collection(db, 'admin_users');
      const snapshot = await getDocs(usersRef);
      const usersData: any[] = snapshot.docs.map(docSnap => ({
        docId: docSnap.id,
        ...docSnap.data()
      }));

      // Ensure humas@mmpackaging.co.id is included in the list
      const hasHumas = usersData.some(u => (u.email || '').toLowerCase() === 'humas@mmpackaging.co.id' || (u.userId || '').toLowerCase() === 'humas');
      if (!hasHumas) {
        usersData.unshift({
          docId: 'humas_superadmin',
          userId: 'humas',
          email: 'humas@mmpackaging.co.id',
          role: 'Super Admin',
          createdAt: new Date().toISOString()
        });
      }

      setAdminUsersList(usersData);
    } catch (err) {
      console.error("Error fetching admin users:", err);
    } finally {
      setIsLoadingAdminUsers(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'settings') {
      fetchAdminUsers();
    }
  }, [activeTab]);

  const handleGenerateRandomPass = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$';
    let res = 'Mmp#';
    for (let i = 0; i < 6; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setManualResetPasswordInput(res);
  };

  const handleExecuteManualPasswordReset = async () => {
    if (!selectedUserForReset || !manualResetPasswordInput.trim()) {
      alert('Masukkan password baru yang akan diterapkan.');
      return;
    }
    setIsSavingManualReset(true);
    try {
      const targetDocId = selectedUserForReset.docId || selectedUserForReset.uid || (selectedUserForReset.userId || 'admin').toLowerCase();
      const targetRef = doc(db, 'admin_users', targetDocId);

      await setDoc(targetRef, {
        userId: selectedUserForReset.userId || selectedUserForReset.email || 'admin',
        email: selectedUserForReset.email || '',
        manualPassword: manualResetPasswordInput.trim(),
        passwordLastResetBy: 'humas@mmpackaging.co.id (Super Admin)',
        passwordLastResetAt: new Date().toISOString()
      }, { merge: true });

      setResetSuccessData({
        userId: selectedUserForReset.userId || selectedUserForReset.email || 'admin',
        email: selectedUserForReset.email || 'humas@mmpackaging.co.id',
        pass: manualResetPasswordInput.trim()
      });

      setManualResetPasswordInput('');
      setSelectedUserForReset(null);
      fetchAdminUsers();
    } catch (err: any) {
      console.error("Error manual reset:", err);
      alert("Gagal mereset password: " + (err.message || 'Kesalahan sistem'));
    } finally {
      setIsSavingManualReset(false);
    }
  };

  const handleAddNewAdminDirect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminUserId.trim() || !newAdminEmail.trim() || !newAdminPassword.trim()) {
      alert("Lengkapi User ID, Email, dan Password.");
      return;
    }
    try {
      const cleanId = newAdminUserId.trim();
      const cleanEmail = newAdminEmail.toLowerCase().trim();
      const newDocRef = doc(db, 'admin_users', cleanId.toLowerCase());
      await setDoc(newDocRef, {
        userId: cleanId,
        email: cleanEmail,
        manualPassword: newAdminPassword.trim(),
        createdAt: new Date().toISOString(),
        createdBy: 'humas@mmpackaging.co.id (Super Admin)'
      }, { merge: true });

      alert(`Akun Admin "${cleanId}" (${cleanEmail}) berhasil didaftarkan oleh Super Admin.`);
      setIsAddAdminModalOpen(false);
      setNewAdminUserId('');
      setNewAdminEmail('');
      setNewAdminPassword('');
      fetchAdminUsers();
    } catch (err: any) {
      console.error("Error add new admin direct:", err);
      alert("Gagal menambahkan admin baru: " + (err.message || 'Kesalahan sistem'));
    }
  };

  const handleDeleteAdminDoc = async (userItem: any) => {
    if (!confirm(`Apakah Anda yakin ingin menghapus akses admin untuk user "${userItem.userId || userItem.email}"?`)) return;
    try {
      if (userItem.docId) {
        await deleteDoc(doc(db, 'admin_users', userItem.docId));
      }
      alert('Akun admin berhasil dihapus.');
      fetchAdminUsers();
    } catch (err: any) {
      console.error("Error delete admin user:", err);
      alert("Gagal menghapus admin user.");
    }
  };

  
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const [selectedApplicant, setSelectedApplicant] = useState<any>(null);
  
  const [applicants, setApplicants] = useState<any[]>([]);
  const [sortConfig, setSortConfig] = useState<{key: string, direction: 'asc' | 'desc'} | null>(null);

  const statusCounts = useMemo(() => {
    let sedangDiproses = 0;
    let undanganInterview = 0;
    let diterima = 0;
    let ditolak = 0;
    let kirimWa = 0;
    let today = 0;

    const now = new Date();
    const monthsIndo = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    const todayIndo = `${String(now.getDate()).padStart(2, '0')} ${monthsIndo[now.getMonth()]} ${now.getFullYear()}`;

    applicants.forEach(app => {
      const rawTimestamp = app.rawData?.["Timestamp (Waktu Submit)"];
      const ts = getTimestampMs(rawTimestamp);
      if (ts) {
        const d = new Date(ts);
        if (d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate()) {
          today++;
        }
      } else if (app.tanggalMasuk && app.tanggalMasuk.toLowerCase().includes(todayIndo.toLowerCase())) {
        today++;
      }

      const s = (app.status || '').trim().toLowerCase();
      if (s === 'sedang diproses') sedangDiproses++;
      else if (s === 'undangan interview') undanganInterview++;
      else if (s === 'diterima') diterima++;
      else if (s === 'ditolak') ditolak++;
      else if (!s || s === 'kirim wa' || s === '-' || s.includes('kirim wa') || s.includes('baru')) kirimWa++;
    });

    return {
      total: applicants.length,
      today,
      sedangDiproses,
      undanganInterview,
      diterima,
      ditolak,
      kirimWa
    };
  }, [applicants]);

  const handleSort = (key: string) => {
     let direction: 'asc' | 'desc' = 'asc';
     if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
        direction = 'desc';
     }
     setSortConfig({ key, direction });
  };


const skillList = useMemo(() => {
     const skills = new Set<string>(HARDSKILLS_OPTIONS);
     applicants.forEach(app => {
        const skillText = app.rawData?.['Teknikal / Hardskill'];
        if (typeof skillText === 'string' && skillText !== '-') {
            skillText.split(',').forEach((s: string) => {
                const trimmed = s.trim();
                if (trimmed) skills.add(trimmed);
            });
        }
     });
     return Array.from(skills).sort();
  }, [applicants]);

const activeJurusanList = useMemo(() => {
     const jurusan = new Set<string>();
     applicants.forEach(app => {
        const eduText = app.rawData?.['Riwayat Pendidikan Formal'];
        if (typeof eduText === 'string') {
            const rows = eduText.split('\n');
            rows.forEach((row: string) => {
               const cols = row.split(' | ');
               if (cols.length >= 4 && cols[3] !== 'Jurusan') {
                   const jur = cols[3].trim();
                   if (jur && jur !== '-') jurusan.add(jur);
               }
            });
        }
     });
     return Array.from(jurusan).sort();
  }, [applicants]);

const activeEduLevels = useMemo(() => {
     const levels = new Set<string>();
     applicants.forEach(app => {
        const eduText = app.rawData?.['Riwayat Pendidikan Formal'];
        if (typeof eduText === 'string') {
            const rows = eduText.split('\n');
            // Assuming header is first row if it starts with 'Tingkat'
            rows.forEach((row: string) => {
               const cols = row.split(' | ');
               if (cols.length >= 4 && cols[0] !== 'Tingkat') {
                   const level = cols[0].trim();
                   if (level && level !== '-') levels.add(level);
               }
            });
        }
     });
     return Array.from(levels).sort();
  }, [applicants]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchApplicants = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'pelamar'));
        const data = querySnapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
        
        const mappedData = data.map((rawItem: any, index: number) => {
           const item = normalizeApplicantRawData(rawItem);
           let pendidikan = item["Tingkat Pendidikan Terakhir"] && item["Tingkat Pendidikan Terakhir"] !== "-" 
                            ? item["Tingkat Pendidikan Terakhir"] 
                            : "";
                            
           // Calculate Age if DOB exists
           let ageStr = "";
           if (item["Tanggal Lahir"] && item["Tanggal Lahir"] !== "-") {
              const birthDate = parseDOB(item["Tanggal Lahir"]);
              const diffMs = Date.now() - birthDate.getTime();
              const ageDate = new Date(diffMs); 
              const years = Math.abs(ageDate.getUTCFullYear() - 1970);
              ageStr = `${years} Thn`;
           }
           
           let usiaGender = item["Gender"] && item["Gender"] !== "-" ? item["Gender"] : "";
           if (ageStr && usiaGender) usiaGender = `${ageStr}, ${usiaGender}`;
           else if (ageStr) usiaGender = ageStr;
           
           return {
              id: index + 1,
              no: index + 1,
              tanggalMasuk: formatTanggalIndo(item["Timestamp (Waktu Submit)"]?.split(',')[0] || "-"),
              kode: "MMP-" + (100000 + index).toString(),
              nama: item["Nama Lengkap"] || "-",
              telpHP: item["No. Hp/Telp"] || "-",
              posisi: item["Posisi / Pekerjaan Dilamar"] || "-",
              status: item["Status"] || "Kirim WA",
              note: item["Notes"] || "",
              pendidikan: pendidikan || "-",
              usiaGender: usiaGender || "-",
              tinggiBerat: `${item["Tinggi Badan (cm)"] || "-"}/${item["Berat Badan (kg)"] || "-"}`,
              rawData: item
           };
        });
        
        // Sort descending by submit date (latest first / newest at top)
        mappedData.sort((a, b) => {
           const timeA = getTimestampMs(a.rawData["Timestamp (Waktu Submit)"]);
           const timeB = getTimestampMs(b.rawData["Timestamp (Waktu Submit)"]);
           return timeB - timeA;
        });
        
        // Re-assign sequential ids and numbers in that sorted order (1, 2, 3...)
        mappedData.forEach((item, index) => {
           item.id = index + 1;
           item.no = index + 1;
        });
        
        setApplicants(mappedData);

      } catch (error) {
        console.error("Error fetching applicants:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchApplicants();
  }, []);

  const filteredApplicants = useMemo(() => {
    const filtered = applicants.filter(app => {
      const searchLower = searchTerm.toLowerCase();
      const searchTokens = searchLower.split(' ').filter((t: string) => t.trim() !== '');
      const dashboardInfo = [
        app.nama,
        app.kode,
        app.posisi,
        app.pendidikan,
        app.status,
        app.telpHP,
        app.usiaGender,
        app.tinggiBerat,
        app.tanggalMasuk
      ].join(' ').toLowerCase();
      const matchSearch = searchTerm === '' || searchTokens.every((token: string) => dashboardInfo.includes(token));
      const matchPosisi = posisiFilter === '' || app.posisi.toLowerCase().includes(posisiFilter.toLowerCase());
      
      let matchEdu = true;
      if (appliedEduFilters.length > 0) {
         const eduText = app.rawData && app.rawData['Riwayat Pendidikan Formal'];
         if (typeof eduText === 'string') {
             const rows = eduText.split('\n');

             
             const checkTingkatMatch = (rowTingkat: string, filterTingkat: string) => {
                if (!filterTingkat || filterTingkat === 'Semua') return true;
                const r = rowTingkat.toUpperCase().trim();
                const f = filterTingkat.toUpperCase().trim();
                
                if (r === f) return true;
                
                if (f === 'S2/S3') {
                   return r === 'S2' || r === 'S3' || r.includes('S2') || r.includes('S3');
                }
                if (f === 'D1/D2/D3') {
                   return ['D1', 'D2', 'D3'].some(d => r === d || r.includes(d));
                }
                if (f === 'SLTA/SMU/SMK' || f === 'SLTA/SMU') {
                   return ['SLTA', 'SMU', 'SMK', 'SMA', 'SLA'].some(s => r === s || r.includes(s));
                }
                if (f === 'SLTP') {
                   return ['SLTP', 'SMP'].some(s => r === s || r.includes(s));
                }
                if (f === 'SD') {
                   return ['SD', 'SD/SEDARAJAT'].some(s => r === s || r.includes(s));
                }
                
                return r.includes(f) || f.includes(r);
             };

             matchEdu = appliedEduFilters.some(filter => {
                const filterTingkat = filter.tingkat || 'Semua';
                const filterJurusan = filter.jurusan || '';
                
                // 1. Try to match against the formal education history rows
                const hasHistoryMatch = rows.some((row: string) => {
                   const cols = row.split(' | ');
                   if (cols.length >= 4) {
                       let rowTingkat = cols[0].trim();
                       let rowJurusan = cols[3].trim();
                       
                       const tingkatMatch = checkTingkatMatch(rowTingkat, filterTingkat);
                       const jurusanMatch = !filterJurusan || 
                                            rowJurusan.toLowerCase().includes(filterJurusan.toLowerCase()) || 
                                            filterJurusan.toLowerCase().includes(rowJurusan.toLowerCase());
                                            
                       return tingkatMatch && jurusanMatch;
                   }
                   return false;
                });
                
                if (hasHistoryMatch) return true;
                
                // 2. Fallback to Tingkat Pendidikan Terakhir (app.pendidikan) if history is empty or doesn't match
                if (filterTingkat === 'Semua') return true;
                
                const fallbackTingkatMatch = checkTingkatMatch(app.pendidikan, filterTingkat);
                const fallbackJurusanMatch = !filterJurusan;
                
                return fallbackTingkatMatch && fallbackJurusanMatch;
             });
         } else {
             matchEdu = false;
         }
      }
      let matchSkills = true;
      if (appliedSelectedSkills.length > 0) {
         const skillText = app.rawData && app.rawData['Teknikal / Hardskill'];
         if (skillText) {
             matchSkills = appliedSelectedSkills.every(s => skillText.toLowerCase().includes(s.toLowerCase()));
         } else {
             matchSkills = false;
         }
      }

      let matchStatus = true;
      if (statusFilter !== '') {
         const s = (app.status || '').trim().toLowerCase();
         if (statusFilter === 'Kirim WA') {
             matchStatus = !app.status || s === 'kirim wa' || s === '-' || s.includes('kirim wa') || s.includes('baru');
         } else {
             matchStatus = s === statusFilter.toLowerCase();
         }
      }
      
      return matchSearch && matchPosisi && matchStatus && matchEdu && matchSkills;
    });

    if (sortConfig !== null) {
      filtered.sort((a, b) => {
         let aVal = a[sortConfig.key];
         let bVal = b[sortConfig.key];
         
         if (sortConfig.key === 'no') {
            aVal = Number(a.no) || 0;
            bVal = Number(b.no) || 0;
         } else if (sortConfig.key === 'tanggalMasuk') {
            aVal = new Date(a.rawData["Timestamp (Waktu Submit)"] || 0).getTime();
            bVal = new Date(b.rawData["Timestamp (Waktu Submit)"] || 0).getTime();
         } else {
            if (typeof aVal === 'string') aVal = aVal.toLowerCase();
            if (typeof bVal === 'string') bVal = bVal.toLowerCase();
         }

         if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
         if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
         return 0;
      });
    }
    return filtered;
  }, [applicants, searchTerm, posisiFilter, statusFilter, appliedEduFilters, appliedSelectedSkills, sortConfig]);

  const handleFilter = () => {
    // Membuka modal advanced filter
    setIsFilterModalOpen(true);
    setPosisiFilter(posisiFilterDropdown);
  };

  const handleHapusFilter = () => {
    setPosisiFilterDropdown('');
    setPosisiFilter('');
    setStatusFilter('');
    setSearchTerm('');
    setAppliedEduFilters([]);
    setEduFilters([]);
    setAppliedSelectedSkills([]);
    setSelectedSkills([]);
  };

  const handleActionClick = (app: any, actionName: string) => {
    if (actionName === 'Lihat cv pelamar') {
        const cvData = app.rawData?.['CV (URL)'] || app.rawData?.['cv_pelamar'] || app.rawData?.['CV (Base64)'];
        if (cvData && (cvData.startsWith('http') || cvData.includes('drive.google.com'))) {
            let url = cvData;
            if (!url.startsWith('http')) {
               url = `https://${url}`;
            }
            window.open(url, "_blank");
        } else if (cvData && cvData.startsWith('data:')) {
            const pdfWindow = window.open("");
            if(pdfWindow) {
               pdfWindow.document.write("<iframe width='100%' height='100%' src='" + cvData + "'></iframe><style>body{margin:0;overflow:hidden;}</style>");
            }
        } else {
            setViewFileModal({
               isOpen: true,
               title: `CV - ${app.nama}`,
               content: `CV Tidak tersedia atau bukan format PDF.`
            });
        }
    }
  };

  const deleteFileFromGAS = async (fileUrl: string) => {
    if (!fileUrl || typeof fileUrl !== 'string' || !fileUrl.includes('drive.google.com')) return;
    try {
       const gasUrl = "https://script.google.com/macros/s/AKfycbx-Zma41RcWXGBWiYNFtQZvE45XSKIIPGrmH925-SKU_ivlEXAJGXDxCdPkGyjWXW-h/exec";
       await fetch(gasUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify({
             action: 'delete',
             fileUrl: fileUrl
          })
       });
    } catch (err) {
       console.error("Gagal menghapus file dari GAS Drive:", err);
    }
  };

  const executeDeleteApp = async (app: any) => {
    setConfirmDeleteModal({isOpen: false, app: null});
    try {
      if (!app.rawData?.docId) {
         alert("Data tidak dapat dihapus karena tidak memiliki ID Dokumen.");
         return;
      }
      
      // Kumpulkan file URL Google Drive pelamar
      const fileUrlsToDelete = new Set<string>();
      const raw = app.rawData || {};
      [
        raw['Foto Pelamar (URL)'],
        raw['foto_pelamar'],
        raw['CV (URL)'],
        raw['cv_pelamar'],
        raw['Tanda Tangan (URL)'],
        raw['tanda_tangan'],
        raw['Tanda Tangan']
      ].forEach(url => {
        if (typeof url === 'string' && url.includes('drive.google.com')) {
          fileUrlsToDelete.add(url);
        }
      });

      // Kirim permintaan hapus file ke Google Apps Script
      fileUrlsToDelete.forEach(url => {
        deleteFileFromGAS(url);
      });

      await deleteDoc(doc(db, 'pelamar', app.rawData.docId));
      
      const remaining = applicants.filter(a => a.id !== app.id);
      const resequenced = remaining.map((item, index) => ({
         ...item,
         id: index + 1,
         no: index + 1
      }));
      
      setApplicants(resequenced);
      alert("Data pelamar berhasil dihapus dari database dan permintaan hapus file Google Drive telah dikirim.");
    } catch (err) {
      alert("Terjadi kesalahan jaringan saat menghapus data.");
    }
  };

  const handleDeleteApplicant = async (app: any) => {
    setConfirmDeleteModal({isOpen: true, app: app});
  };

  const toggleDropdown = (id: number) => {
    if (openDropdownId === id) setOpenDropdownId(null);
    else setOpenDropdownId(id);
  };

  const scrollToTable = () => {
    document.getElementById('table-peserta')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans flex text-gray-800 relative overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      
      <aside className={`bg-[#2b333e] h-screen flex flex-col py-4 transition-all duration-300 fixed md:relative z-50 overflow-y-auto overflow-x-hidden ${isSidebarOpen ? 'w-64 translate-x-0' : 'w-64 -translate-x-full md:translate-x-0 md:w-20 md:items-center'}`}>
        <button 
           onClick={() => setIsSidebarOpen(!isSidebarOpen)}
           className="absolute -right-3 top-6 bg-white border border-gray-200 rounded-full p-1 text-gray-500 hover:text-gray-800 shadow-md z-10 hidden md:block"
        >
           {isSidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
      
        <div className={`flex items-center mb-4 shadow-xl shrink-0 ${isSidebarOpen ? 'px-6 gap-3' : 'justify-center w-12 h-12 rounded-full mx-auto'}`}>
           <div className={`bg-white text-[#2b333e] flex flex-col items-center justify-center text-[10px] leading-none text-center shadow-inner ${isSidebarOpen ? 'w-10 h-10 rounded-lg shrink-0' : 'w-full h-full rounded-full'}`}>
             <LogoMMP variant="dots" className="w-full h-full object-contain p-1" />
           </div>
           {isSidebarOpen && <span className="text-white font-bold text-lg whitespace-nowrap overflow-hidden">Dashboard Panel</span>}
        </div>
        
        <div className={`flex items-center mb-6 overflow-hidden shrink-0 ${isSidebarOpen ? 'px-6 gap-3' : 'justify-center'}`}>
           <div className={`bg-gray-400 flex items-center justify-center text-white shrink-0 ${isSidebarOpen ? 'w-10 h-10 rounded-full' : 'w-10 h-10 rounded-full mx-auto'}`}>
              <User className="w-6 h-6" />
           </div>
           {isSidebarOpen && (
              <div className="flex flex-col overflow-hidden">
                 <span className="text-gray-300 text-sm font-medium truncate">{adminUserId}</span>
              </div>
           )}
        </div>
        
        <nav className="flex flex-col gap-2 w-full px-2 flex-grow mt-2">
           <div onClick={() => { setActiveTab('dashboard'); if(window.innerWidth < 768) setIsSidebarOpen(false); }} className={`w-full flex items-center rounded-lg cursor-pointer relative ${isSidebarOpen ? 'px-4 py-3' : 'aspect-square justify-center'} ${activeTab === 'dashboard' ? 'bg-[#6366f1] text-white shadow-lg mb-2' : 'text-gray-400 hover:text-white hover:bg-white/5 bg-transparent'}`}>
              {activeTab === 'dashboard' && <div className="absolute left-[-8px] top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r"></div>}
              <UserPlus className="w-6 h-6 shrink-0" />
              {isSidebarOpen && <span className="ml-3 font-medium whitespace-nowrap">Dashboard</span>}
           </div>
           <div onClick={() => { setActiveTab('settings'); if(window.innerWidth < 768) setIsSidebarOpen(false); }} className={`w-full flex items-center rounded-lg cursor-pointer relative ${isSidebarOpen ? 'px-4 py-3' : 'aspect-square justify-center'} ${activeTab === 'settings' ? 'bg-[#6366f1] text-white shadow-lg mb-2' : 'text-gray-400 hover:text-white hover:bg-white/5 bg-transparent'}`}>
              {activeTab === 'settings' && <div className="absolute left-[-8px] top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r"></div>}
              <Settings className="w-6 h-6 shrink-0" />
              {isSidebarOpen && <span className="ml-3 font-medium whitespace-nowrap">Pengaturan Sistem</span>}
           </div>
           <div onClick={() => { setActiveTab('documents'); if(window.innerWidth < 768) setIsSidebarOpen(false); }} className={`w-full flex items-center rounded-lg cursor-pointer relative ${isSidebarOpen ? 'px-4 py-3' : 'aspect-square justify-center'} ${activeTab === 'documents' ? 'bg-[#6366f1] text-white shadow-lg mb-2' : 'text-gray-400 hover:text-white hover:bg-white/5 bg-transparent'}`}>
              {activeTab === 'documents' && <div className="absolute left-[-8px] top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r"></div>}
              <FileText className="w-6 h-6 shrink-0" />
              {isSidebarOpen && <span className="ml-3 font-medium whitespace-nowrap">Dokumen & Template</span>}
           </div>
        </nav>

        <div className="flex flex-col gap-2 w-full px-2 mt-auto pt-4 border-t border-slate-700 shrink-0">
           <Link to="/form" target="_blank" title="Lihat Mode Pelamar" className={`w-full flex items-center text-blue-400 hover:text-white hover:bg-blue-600/50 rounded-lg cursor-pointer transition-colors ${isSidebarOpen ? 'px-4 py-3 gap-3' : 'aspect-square justify-center'}`}>
              <ExternalLink className="w-5 h-5 shrink-0" />
              {isSidebarOpen && <span className="font-medium whitespace-nowrap">View Form Pelamar</span>}
           </Link>
           <div 
              title="Copy Link Form"
              onClick={() => {
                 navigator.clipboard.writeText(window.location.origin + '/form');
                 alert('Link Form berhasil disalin!\nBagikan link ini kepada pelamar: ' + window.location.origin + '/form');
              }}
              className={`w-full flex items-center text-emerald-400 hover:text-white hover:bg-emerald-600/50 rounded-lg cursor-pointer transition-colors ${isSidebarOpen ? 'px-4 py-3 gap-3' : 'aspect-square justify-center'}`}
           >
              <Copy className="w-5 h-5 shrink-0" />
              {isSidebarOpen && <span className="font-medium whitespace-nowrap">Copy Form Link</span>}
           </div>
        </div>
      </aside>


      {/* Main Content */}
      <main className="flex-1 min-w-0 flex flex-col h-screen overflow-hidden">
         {/* Header */}
         <header className="bg-white px-4 md:px-6 py-4 flex justify-between items-center shadow-sm border-b shrink-0 gap-2">
            <div className="flex items-center gap-3 overflow-hidden">
               <button 
                 onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                 className="md:hidden text-gray-500 hover:text-gray-800 shrink-0"
               >
                 <Menu className="w-6 h-6" />
               </button>
               <h1 className="text-lg md:text-2xl font-light text-gray-700 truncate">
                  {activeTab === 'dashboard' && 'Welcome To Dashboard Panel'}
                  {activeTab === 'settings' && 'Pengaturan Sistem'}
                  {activeTab === 'documents' && 'Dokumen & Template'}
                  
               </h1>
            </div>
            <button onClick={() => {
               auth.signOut().then(() => navigate('/login'));
            }} className="bg-[#dc3545] hover:bg-[#c82333] text-white px-3 py-1.5 md:px-4 rounded font-medium text-sm transition-colors cursor-pointer shrink-0">
               logout
            </button>
         </header>

         <div className="p-4 md:p-6 overflow-y-auto flex-1">
            {activeTab === 'dashboard' && (
            <>
            {/* Stats Cards Section */}
            <div className="space-y-4 mb-6">
               {/* Primary Cards: Total & Hari Ini */}
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div 
                     onClick={() => { setStatusFilter(''); scrollToTable(); }}
                     className={`bg-[#28a745] text-white rounded-lg shadow-sm overflow-hidden relative flex flex-col justify-between h-28 hover:brightness-105 transition-all cursor-pointer ${statusFilter === '' ? 'ring-2 ring-offset-2 ring-emerald-500' : ''}`}
                  >
                     <div className="p-4 z-10">
                        <div className="flex items-center gap-2">
                           <h2 className="text-3xl font-bold mb-1">{statusCounts.total}</h2>
                           {statusFilter === '' && <span className="bg-white/20 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Aktif</span>}
                        </div>
                        <p className="text-xs font-semibold text-white/90">Total Pelamar Terdaftar</p>
                     </div>
                     <Users className="w-20 h-20 absolute -right-2 top-0 text-black/10" />
                     <div className="bg-black/15 hover:bg-black/25 text-center py-1.5 text-xs flex justify-center items-center gap-1 transition-colors font-medium">
                        {statusFilter === '' ? 'Menampilkan Semua Data' : 'Tampilkan Semua Data'} <ArrowRight className="w-3 h-3" />
                     </div>
                  </div>
                  
                  <div 
                     onClick={scrollToTable}
                     className="bg-[#6610f2] text-white rounded-lg shadow-sm overflow-hidden relative flex flex-col justify-between h-28 hover:brightness-105 transition-all cursor-pointer"
                  >
                     <div className="p-4 z-10">
                        <h2 className="text-3xl font-bold mb-1">{statusCounts.today}</h2>
                        <p className="text-xs font-semibold text-white/90">Pelamar Masuk Hari Ini</p>
                     </div>
                     <UserPlus className="w-20 h-20 absolute -right-2 top-0 text-black/10" />
                     <div className="bg-black/15 hover:bg-black/25 text-center py-1.5 text-xs flex justify-center items-center gap-1 transition-colors font-medium">
                        Lihat Data Hari Ini <ArrowRight className="w-3 h-3" />
                     </div>
                  </div>
               </div>

               {/* Breakdown Status Cards */}
               <div>
                  <div className="flex items-center justify-between mb-2">
                     <span className="text-xs font-bold text-gray-600 uppercase tracking-wider flex items-center gap-1.5">
                        <Filter className="w-3.5 h-3.5 text-gray-500" /> Status Pelamar (Klik untuk filter data)
                     </span>
                     {statusFilter && (
                        <button 
                           onClick={() => setStatusFilter('')}
                           className="text-xs text-blue-600 hover:text-blue-800 font-semibold underline flex items-center gap-1"
                        >
                           Hapus Filter Status ({statusFilter})
                        </button>
                     )}
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                     {/* Kirim WA / Belum Diproses */}
                     <div 
                        onClick={() => {
                           setStatusFilter(statusFilter === 'Kirim WA' ? '' : 'Kirim WA');
                           scrollToTable();
                        }}
                        className={`bg-slate-700 text-white rounded-lg p-3.5 shadow-sm relative overflow-hidden cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between min-h-[95px] ${statusFilter === 'Kirim WA' ? 'ring-2 ring-offset-2 ring-slate-800 shadow-md brightness-110' : 'opacity-90 hover:opacity-100'}`}
                     >
                        <div className="flex justify-between items-start z-10">
                           <div>
                              <span className="text-2xl font-bold leading-tight block">{statusCounts.kirimWa}</span>
                              <span className="text-xs font-medium text-slate-200 block mt-0.5">Kirim WA / Baru</span>
                           </div>
                           <Send className="w-5 h-5 text-slate-300/60 shrink-0" />
                        </div>
                        <div className="text-[10px] text-slate-300 mt-2 z-10 flex items-center justify-between">
                           <span>{statusCounts.total > 0 ? `${Math.round((statusCounts.kirimWa / statusCounts.total) * 100)}% total` : '0%'}</span>
                           <span className="font-semibold text-white underline">{statusFilter === 'Kirim WA' ? 'Sedang dipilih' : 'Klik filter →'}</span>
                        </div>
                     </div>

                     {/* Sedang Diproses */}
                     <div 
                        onClick={() => {
                           setStatusFilter(statusFilter === 'Sedang Diproses' ? '' : 'Sedang Diproses');
                           scrollToTable();
                        }}
                        className={`bg-amber-500 text-white rounded-lg p-3.5 shadow-sm relative overflow-hidden cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between min-h-[95px] ${statusFilter === 'Sedang Diproses' ? 'ring-2 ring-offset-2 ring-amber-600 shadow-md brightness-110' : 'opacity-90 hover:opacity-100'}`}
                     >
                        <div className="flex justify-between items-start z-10">
                           <div>
                              <span className="text-2xl font-bold leading-tight block">{statusCounts.sedangDiproses}</span>
                              <span className="text-xs font-medium text-amber-100 block mt-0.5">Sedang Diproses</span>
                           </div>
                           <RefreshCw className="w-5 h-5 text-amber-200/60 shrink-0" />
                        </div>
                        <div className="text-[10px] text-amber-100 mt-2 z-10 flex items-center justify-between">
                           <span>{statusCounts.total > 0 ? `${Math.round((statusCounts.sedangDiproses / statusCounts.total) * 100)}% total` : '0%'}</span>
                           <span className="font-semibold text-white underline">{statusFilter === 'Sedang Diproses' ? 'Sedang dipilih' : 'Klik filter →'}</span>
                        </div>
                     </div>

                     {/* Undangan Interview */}
                     <div 
                        onClick={() => {
                           setStatusFilter(statusFilter === 'Undangan Interview' ? '' : 'Undangan Interview');
                           scrollToTable();
                        }}
                        className={`bg-blue-600 text-white rounded-lg p-3.5 shadow-sm relative overflow-hidden cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between min-h-[95px] ${statusFilter === 'Undangan Interview' ? 'ring-2 ring-offset-2 ring-blue-700 shadow-md brightness-110' : 'opacity-90 hover:opacity-100'}`}
                     >
                        <div className="flex justify-between items-start z-10">
                           <div>
                              <span className="text-2xl font-bold leading-tight block">{statusCounts.undanganInterview}</span>
                              <span className="text-xs font-medium text-blue-100 block mt-0.5">Undangan Interview</span>
                           </div>
                           <Calendar className="w-5 h-5 text-blue-200/60 shrink-0" />
                        </div>
                        <div className="text-[10px] text-blue-100 mt-2 z-10 flex items-center justify-between">
                           <span>{statusCounts.total > 0 ? `${Math.round((statusCounts.undanganInterview / statusCounts.total) * 100)}% total` : '0%'}</span>
                           <span className="font-semibold text-white underline">{statusFilter === 'Undangan Interview' ? 'Sedang dipilih' : 'Klik filter →'}</span>
                        </div>
                     </div>

                     {/* Diterima */}
                     <div 
                        onClick={() => {
                           setStatusFilter(statusFilter === 'Diterima' ? '' : 'Diterima');
                           scrollToTable();
                        }}
                        className={`bg-emerald-600 text-white rounded-lg p-3.5 shadow-sm relative overflow-hidden cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between min-h-[95px] ${statusFilter === 'Diterima' ? 'ring-2 ring-offset-2 ring-emerald-700 shadow-md brightness-110' : 'opacity-90 hover:opacity-100'}`}
                     >
                        <div className="flex justify-between items-start z-10">
                           <div>
                              <span className="text-2xl font-bold leading-tight block">{statusCounts.diterima}</span>
                              <span className="text-xs font-medium text-emerald-100 block mt-0.5">Diterima</span>
                           </div>
                           <CheckCircle2 className="w-5 h-5 text-emerald-200/60 shrink-0" />
                        </div>
                        <div className="text-[10px] text-emerald-100 mt-2 z-10 flex items-center justify-between">
                           <span>{statusCounts.total > 0 ? `${Math.round((statusCounts.diterima / statusCounts.total) * 100)}% total` : '0%'}</span>
                           <span className="font-semibold text-white underline">{statusFilter === 'Diterima' ? 'Sedang dipilih' : 'Klik filter →'}</span>
                        </div>
                     </div>

                     {/* Ditolak */}
                     <div 
                        onClick={() => {
                           setStatusFilter(statusFilter === 'Ditolak' ? '' : 'Ditolak');
                           scrollToTable();
                        }}
                        className={`bg-rose-600 text-white rounded-lg p-3.5 shadow-sm relative overflow-hidden cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between min-h-[95px] ${statusFilter === 'Ditolak' ? 'ring-2 ring-offset-2 ring-rose-700 shadow-md brightness-110' : 'opacity-90 hover:opacity-100'}`}
                     >
                        <div className="flex justify-between items-start z-10">
                           <div>
                              <span className="text-2xl font-bold leading-tight block">{statusCounts.ditolak}</span>
                              <span className="text-xs font-medium text-rose-100 block mt-0.5">Ditolak</span>
                           </div>
                           <XCircle className="w-5 h-5 text-rose-200/60 shrink-0" />
                        </div>
                        <div className="text-[10px] text-rose-100 mt-2 z-10 flex items-center justify-between">
                           <span>{statusCounts.total > 0 ? `${Math.round((statusCounts.ditolak / statusCounts.total) * 100)}% total` : '0%'}</span>
                           <span className="font-semibold text-white underline">{statusFilter === 'Ditolak' ? 'Sedang dipilih' : 'Klik filter →'}</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            {/* Table Section */}
            <div id="table-peserta" className="bg-white border border-gray-200 rounded shadow-sm relative scroll-m-6">
               <div className="px-4 py-3 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center bg-[#f8f9fa] rounded-t gap-4 md:gap-0">
                  <div className="flex flex-wrap items-center gap-2 text-gray-600 font-medium text-sm w-full md:w-auto">
                     <FileText className="w-4 h-4 text-gray-500" /> 
                     <span>List semua Peserta ({filteredApplicants.length})</span>
                     {statusFilter && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200">
                           Status: {statusFilter}
                           <button onClick={() => setStatusFilter('')} className="hover:text-indigo-950 ml-0.5">
                              <X className="w-3 h-3" />
                           </button>
                        </span>
                     )}
                  </div>
                  <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-start md:justify-end">
                     <button 
                        onClick={() => {
                           setIsLoading(true);
                           const fetchApplicants = async () => {
                             try {
                               const querySnapshot = await getDocs(collection(db, 'pelamar'));
                               const data = querySnapshot.docs.map(doc => ({ ...doc.data(), docId: doc.id }));
                               const mappedData = data.map((rawItem: any, index: number) => {
                                  const item = normalizeApplicantRawData(rawItem);
                                  let pendidikan = item["Tingkat Pendidikan Terakhir"] && item["Tingkat Pendidikan Terakhir"] !== "-" 
                                                   ? item["Tingkat Pendidikan Terakhir"] : "";
                                  let ageStr = "";
                                  if (item["Tanggal Lahir"] && item["Tanggal Lahir"] !== "-") {
                                     const birthDate = parseDOB(item["Tanggal Lahir"]);
                                     const ageDate = new Date(Date.now() - birthDate.getTime()); 
                                     const years = Math.abs(ageDate.getUTCFullYear() - 1970);
                                     ageStr = `${years} Thn`;
                                  }
                                  let usiaGender = item["Gender"] && item["Gender"] !== "-" ? item["Gender"] : "";
                                  if (ageStr && usiaGender) usiaGender = `${ageStr}, ${usiaGender}`;
                                  else if (ageStr) usiaGender = ageStr;
                                  return {
                                     id: index + 1,
                                     no: index + 1,
                                     tanggalMasuk: formatTanggalIndo(item["Timestamp (Waktu Submit)"]?.split(',')[0] || "-"),
                                     kode: "MMP-" + (100000 + index).toString(),
                                     nama: item["Nama Lengkap"] || "-",
                                     telpHP: item["No. Hp/Telp"] || "-",
                                     posisi: item["Posisi / Pekerjaan Dilamar"] || "-",
                                     status: item["Status"] || "Kirim WA",
              note: item["Notes"] || "",
                                     pendidikan: pendidikan || "-",
                                     usiaGender: usiaGender || "-",
                                     tinggiBerat: `${item["Tinggi Badan (cm)"] || "-"}/${item["Berat Badan (kg)"] || "-"}`,
                                     rawData: item
                                  };
                               });
                               
                                // Sort descending by submit date (latest first / newest at top)
                                mappedData.sort((a, b) => {
                                   const timeA = getTimestampMs(a.rawData["Timestamp (Waktu Submit)"]);
                                   const timeB = getTimestampMs(b.rawData["Timestamp (Waktu Submit)"]);
                                   return timeB - timeA;
                                });
                                
                                // Re-assign sequential ids and numbers in that sorted order (1, 2, 3...)
                                mappedData.forEach((item, index) => {
                                   item.id = index + 1;
                                   item.no = index + 1;
                                });
                                
                                setApplicants(mappedData);

                             } catch (error) {
                               console.error("Error fetching applicants:", error);
                             } finally {
                               setIsLoading(false);
                             }
                           };
                           fetchApplicants();
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs transition-colors shadow-sm flex items-center justify-center gap-1.5 flex-1 md:flex-none min-w-[120px]"
                     >
                        <RefreshCw className="w-3.5 h-3.5 shrink-0" /> Refresh Data
                     </button>
                     <button 
                        onClick={() => setIsExportModalOpen(true)}
                        className="bg-[#28a745] hover:bg-[#218838] text-white px-3 py-1.5 rounded text-xs transition-colors shadow-sm flex items-center justify-center gap-1.5 flex-1 md:flex-none md:mr-2 min-w-[120px]"
                     >
                        <Download className="w-3.5 h-3.5 shrink-0" /> Export Data
                     </button>
                     <select 
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="border border-gray-300 rounded px-2 py-1.5 text-xs outline-none bg-white text-gray-700 w-full md:w-40 focus:border-blue-500 font-medium"
                     >
                        <option value="">Semua Status</option>
                        <option value="Kirim WA">Kirim WA / Baru</option>
                        <option value="Sedang Diproses">Sedang Diproses</option>
                        <option value="Undangan Interview">Undangan Interview</option>
                        <option value="Diterima">Diterima</option>
                        <option value="Ditolak">Ditolak</option>
                     </select>
                     <select 
                        value={posisiFilterDropdown}
                        onChange={(e) => {
                           setPosisiFilterDropdown(e.target.value);
                           setPosisiFilter(e.target.value);
                        }}
                        className="border border-gray-300 rounded px-2 py-1.5 text-xs outline-none bg-white text-gray-700 w-full md:w-48 focus:border-blue-500"
                     >
                        <option value="">Semua Posisi</option>
                        {JOB_OPTIONS.map(job => <option key={job} value={job}>{job}</option>)}
                     </select>
                     <div className="flex gap-2 w-full md:w-auto">
                        <button 
                           onClick={handleFilter}
                           className="bg-[#343a40] hover:bg-[#23272b] text-white px-3 py-1.5 rounded text-xs transition-colors shadow-sm flex-1 md:flex-none"
                        >
                           Filter
                        </button>
                        <button 
                           className="bg-[#6c757d] hover:bg-[#5a6268] text-white px-3 py-1.5 rounded text-xs transition-colors shadow-sm whitespace-nowrap flex-1 md:flex-none"
                           onClick={handleHapusFilter}
                        >
                           Hapus Filter
                        </button>
                     </div>
                  </div>
               </div>

               <div className="p-4">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4 text-sm text-gray-600">
                     <div className="flex items-center gap-1.5 w-full md:w-auto justify-between md:justify-start">
                        <div className="flex items-center gap-1.5">
                           Show 
                           <select className="border border-gray-300 rounded px-2 py-1 outline-none bg-white text-sm">
                              <option>10</option>
                              <option>25</option>
                              <option>50</option>
                           </select> 
                           entries
                        </div>
                     </div>
                     <div className="flex items-center gap-2 text-sm text-gray-600 w-full md:w-auto">
                        <span className="shrink-0">Search:</span>
                        <input 
                           type="text" 
                           className="border border-gray-300 rounded px-2 py-1 text-sm outline-none focus:border-blue-500 transition-colors w-full"
                           value={searchTerm}
                           onChange={(e) => setSearchTerm(e.target.value)}
                           placeholder="Cari nama, posisi, pendidikan..."
                        />
                     </div>
                  </div>

                  <div className="overflow-x-auto w-full border border-gray-200 rounded">
                     <table className="w-full text-xs text-left border-collapse">
                        <thead className="bg-[#f8f9fa] border-b-2 border-gray-200">
                           <tr>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('no')}>
                                 <div className="flex justify-between items-center">No <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'no' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'no' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('tanggalMasuk')}>
                                 <div className="flex justify-between items-center">Tgl Masuk <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'tanggalMasuk' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'tanggalMasuk' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('nama')}>
                                 <div className="flex justify-between items-center">Nama Lengkap <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'nama' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'nama' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('pendidikan')}>
                                 <div className="flex justify-between items-center">Pendidikan <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'pendidikan' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'pendidikan' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('usiaGender')}>
                                 <div className="flex justify-between items-center">Usia & Fisik <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'usiaGender' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'usiaGender' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('telpHP')}>
                                 <div className="flex justify-between items-center">Kontak <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'telpHP' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'telpHP' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 border-r border-gray-200 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('posisi')}>
                                 <div className="flex justify-between items-center">Posisi Dilamar <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'posisi' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'posisi' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600 cursor-pointer border-r border-gray-200 hover:bg-gray-100" onClick={() => handleSort('status')}>
                                 <div className="flex justify-between items-center">Status <span className="flex flex-col ml-1 items-center"><ChevronUp className={`w-3 h-3 -mb-1 ${sortConfig?.key === 'status' && sortConfig.direction === 'asc' ? 'text-blue-600' : 'text-gray-300'}`} /><ChevronDown className={`w-3 h-3 ${sortConfig?.key === 'status' && sortConfig.direction === 'desc' ? 'text-blue-600' : 'text-gray-300'}`} /></span></div>
                              </th>
                              <th className="px-3 py-3 font-semibold text-gray-600">
                                 <div className="flex justify-between items-center">Aksi</div>
                              </th>
                           </tr>
                        </thead>
                        <tbody>
                           {isLoading ? (
                               <tr>
                                  <td colSpan={9} className="px-4 py-8 text-center bg-white text-gray-500">
                                     <div className="flex flex-col items-center justify-center gap-2">
                                        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
                                        <span>Memuat data pelamar...</span>
                                     </div>
                                  </td>
                               </tr>
                           ) : filteredApplicants.length === 0 ? (
                               <tr>
                                  <td colSpan={9} className="px-4 py-8 text-center bg-white text-gray-500">
                                     Data tidak ditemukan.
                                  </td>
                               </tr>
                           ) : filteredApplicants.map((app, index) => {
                              const isGrayBg = index % 2 === 0;
                              const trClass = isGrayBg ? 'bg-[#6c757d] text-white' : 'bg-white text-gray-700 hover:bg-gray-50';
                              const tdBorder = isGrayBg ? 'border-[#7e878f]' : 'border-gray-200';

                              return (
                                 <tr key={app.id} className={`${trClass} border-b ${tdBorder}`}>
                                    <td className={`px-3 py-3 align-middle border-r ${tdBorder}`}>{app.no}</td>
                                    <td className={`px-3 py-3 align-middle whitespace-nowrap border-r ${tdBorder}`}>{app.tanggalMasuk}</td>
                                    <td className={`px-3 py-3 align-middle border-r ${tdBorder}`}>{app.nama}</td>
                                    <td className={`px-3 py-3 align-middle whitespace-nowrap border-r ${tdBorder}`}>
                                       {app.pendidikan}
                                    </td>
                                    <td className={`px-3 py-3 align-middle whitespace-nowrap border-r ${tdBorder}`}>
                                       <div>{app.usiaGender}</div>
                                       <div>TB/BB: {app.tinggiBerat}</div>
                                    </td>
                                    <td className={`px-3 py-3 align-middle whitespace-nowrap border-r ${tdBorder}`}>
                                       <div>HP/Telp: {app.telpHP}</div>
                                    </td>
                                    <td className={`px-3 py-3 align-middle border-r ${tdBorder}`}>{app.posisi}</td>
                                    <td className={`px-3 py-3 align-middle whitespace-nowrap border-r ${tdBorder} relative ${openDropdownId === app.id ? "z-50" : "z-0"}`}>
                                       {app.status === 'Kirim WA' ? (
                                          <div className="flex items-stretch h-7">
                                             <a href={`https://wa.me/${formatWhatsAppNumber(app.telpHP)}`} target="_blank" rel="noreferrer" className="bg-[#dc3545] hover:bg-[#c82333] text-white px-3 h-full rounded-l text-[11px] font-medium transition-colors border border-[#dc3545] border-r-0 flex items-center justify-center">
                                                Kirim WA
                                             </a>
                                             <button 
                                                type="button"
                                                onClick={(e) => {
                                                   e.preventDefault();
                                                   e.stopPropagation();
                                                   toggleDropdown(app.id);
                                                }}
                                                className="bg-white hover:bg-gray-50 text-gray-700 px-1.5 h-full rounded-r border border-gray-300 flex items-center justify-center shrink-0"
                                             >
                                                <ChevronDown className="w-3 h-3" />
                                             </button>
                                          </div>
                                       ) : (
                                          <div className="flex items-stretch h-7 min-w-[120px]">
                                             <button onClick={() => { setOpenStatusModalId(app.id); setUpdateStatusVal(app.status !== 'Kirim WA' ? app.status : ''); setUpdateStatusNote(app.note || ''); }} className={`px-3 h-full rounded-l text-[11px] font-medium border border-gray-300 border-r-0 truncate max-w-[150px] ${app.status && app.status !== '-' ? (app.status === 'Sedang Diproses' ? 'bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200' : app.status === 'Undangan Interview' ? 'bg-blue-100 text-blue-800 border-blue-300 hover:bg-blue-200' : app.status === 'Diterima' ? 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200' : app.status === 'Ditolak' ? 'bg-rose-100 text-rose-800 border-rose-300 hover:bg-rose-200' : 'bg-gray-100 text-gray-800 border-gray-200 hover:bg-gray-200') : 'bg-white hover:bg-gray-50 text-gray-700'}`}>
                                                {app.status && app.status !== '-' ? app.status : 'Update Status'}
                                             </button>
                                             <button 
                                                type="button"
                                                onClick={(e) => {
                                                   e.preventDefault();
                                                   e.stopPropagation();
                                                   toggleDropdown(app.id);
                                                }}
                                                className="bg-white hover:bg-gray-50 text-gray-700 px-1.5 h-full rounded-r border border-gray-300 shrink-0 flex items-center justify-center"
                                             >
                                                <ChevronDown className="w-3 h-3" />
                                             </button>
                                          </div>
                                       )}

                                       {/* Dropdown Menu */}
                                       {openDropdownId === app.id && (
                                          <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded shadow-lg border border-gray-200 z-50 text-xs flex flex-col py-1">
                                             
                                             <button onClick={() => { handleActionClick(app, 'Lihat cv pelamar'); toggleDropdown(app.id); }} className="w-full text-left px-4 py-2 hover:bg-gray-100 text-gray-700">Lihat cv pelamar</button>
                                             <button onClick={() => { setOpenStatusModalId(app.id); setUpdateStatusVal(app.status !== 'Kirim WA' ? app.status : ''); setUpdateStatusNote(app.note || ''); toggleDropdown(app.id); }} className="w-full text-left px-4 py-2 hover:bg-gray-100 text-gray-700">Update Data Status</button>
                                          </div>
                                       )}
                                    </td>
                                    <td className="px-3 py-3 align-middle text-center flex flex-col items-center justify-center gap-1.5 min-w-[80px]">
                                       <button onClick={() => setSelectedApplicant(app)} className={`${isGrayBg ? 'text-white hover:text-gray-200' : 'text-blue-600 hover:text-blue-800'} underline text-[11px] font-medium`}>
                                          Detail
                                       </button>
                                       <button onClick={() => handleDeleteApplicant(app)} className="text-red-500 hover:text-red-700 text-[11px] font-medium underline">
                                          Hapus
                                       </button>
                                    </td>
                                 </tr>
                              );
                           })}
                        </tbody>
                     </table>
                  </div>

                  <div className="mt-4 flex justify-between items-center text-sm text-gray-600">
                     <div>
                        Showing 1 to {filteredApplicants.length} of {filteredApplicants.length} entries
                     </div>
                     <div className="flex gap-1">
                        <button className="px-3 py-1.5 text-blue-600 cursor-not-allowed opacity-50">&lt; Previous</button>
                        <button className="px-3 py-1.5 text-blue-600 pointer-events-none bg-blue-50 border border-blue-200">1</button>
                        <button className="px-3 py-1.5 text-blue-600 cursor-not-allowed opacity-50">Next &gt;</button>
                     </div>
                  </div>
               </div>
            </div>
            </>
            )}

            {activeTab === 'settings' && (
                <div className="space-y-6 max-w-5xl">
                  {/* Card Ganti Password Akun Saya (Dapat diakses oleh seluruh admin, baik Admin biasa maupun Super Admin) */}
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                     <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-5 border-b pb-4">
                        <div className="flex items-center gap-3">
                           <div className="w-10 h-10 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
                              <KeyRound className="w-5 h-5" />
                           </div>
                           <div>
                              <div className="flex items-center gap-2">
                                 <h2 className="text-lg font-bold text-gray-800">Ganti Password Akun Saya</h2>
                                 <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${isSuperAdmin ? 'bg-indigo-100 text-indigo-700' : 'bg-blue-100 text-blue-700'}`}>
                                    {isSuperAdmin ? 'Super Admin' : 'Admin HR'}
                                 </span>
                              </div>
                              <p className="text-xs text-gray-500 mt-0.5">
                                 Perbarui kata sandi akun Anda secara mandiri tanpa perlu meminta reset ke Super Admin.
                              </p>
                           </div>
                        </div>

                        {/* Profil Ringkas Akun yang Sedang Aktif */}
                        <div className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs text-gray-600 shrink-0">
                           <div>User ID: <strong className="text-gray-900">{adminUserId}</strong></div>
                           <div>Email: <span className="text-gray-800 font-mono">{adminUserEmail || auth.currentUser?.email || '-'}</span></div>
                        </div>
                     </div>

                     {/* Alerts */}
                     {ownPassSuccess && (
                        <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start justify-between gap-3 text-emerald-900 text-sm">
                           <div className="flex items-start gap-3">
                              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                              <div>
                                 <p className="font-semibold text-emerald-900">Password Berhasil Diperbarui!</p>
                                 <p className="text-xs text-emerald-700 mt-0.5">{ownPassSuccess}</p>
                              </div>
                           </div>
                           <button onClick={() => setOwnPassSuccess('')} className="text-emerald-700 hover:text-emerald-900">
                              <X className="w-4 h-4" />
                           </button>
                        </div>
                     )}

                     {ownPassError && (
                        <div className="mb-5 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start justify-between gap-3 text-red-900 text-sm">
                           <div className="flex items-start gap-3">
                              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                              <div>
                                 <p className="font-semibold text-red-900">Gagal Mengganti Password</p>
                                 <p className="text-xs text-red-700 mt-0.5">{ownPassError}</p>
                              </div>
                           </div>
                           <button onClick={() => setOwnPassError('')} className="text-red-700 hover:text-red-900">
                              <X className="w-4 h-4" />
                           </button>
                        </div>
                     )}

                     <form onSubmit={handleUpdateOwnPassword} className="space-y-4 max-w-xl">
                        {/* Password Saat Ini */}
                        <div>
                           <label className="block text-xs font-semibold text-gray-700 mb-1">
                              Password Saat Ini <span className="text-red-500">*</span>
                           </label>
                           <div className="relative">
                              <input
                                 type={showCurrentPass ? "text" : "password"}
                                 value={currentPassword}
                                 onChange={(e) => setCurrentPassword(e.target.value)}
                                 placeholder="Masukkan kata sandi yang Anda gunakan saat ini"
                                 className="w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white"
                                 required
                              />
                              <button
                                 type="button"
                                 onClick={() => setShowCurrentPass(!showCurrentPass)}
                                 className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                              >
                                 {showCurrentPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                              </button>
                           </div>
                        </div>

                        {/* Grid Password Baru & Konfirmasi */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                           <div>
                              <label className="block text-xs font-semibold text-gray-700 mb-1">
                                 Password Baru <span className="text-red-500">*</span>
                              </label>
                              <div className="relative">
                                 <input
                                    type={showNewPass ? "text" : "password"}
                                    value={newPassword}
                                    onChange={(e) => setNewPassword(e.target.value)}
                                    placeholder="Minimal 6 karakter"
                                    className="w-full border border-gray-300 rounded-lg px-3 py-2 pr-10 text-sm outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 bg-white"
                                    required
                                 />
                                 <button
                                    type="button"
                                    onClick={() => setShowNewPass(!showNewPass)}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                 >
                                    {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                 </button>
                              </div>
                              <p className="text-[11px] text-gray-500 mt-1">Gunakan minimal 6 karakter</p>
                           </div>

                           <div>
                              <label className="block text-xs font-semibold text-gray-700 mb-1">
                                 Konfirmasi Password Baru <span className="text-red-500">*</span>
                              </label>
                              <div className="relative">
                                 <input
                                    type={showConfirmPass ? "text" : "password"}
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    placeholder="Ulangi password baru"
                                    className={`w-full border rounded-lg px-3 py-2 pr-10 text-sm outline-none bg-white ${
                                       confirmPassword && confirmPassword !== newPassword 
                                          ? 'border-red-300 focus:border-red-500 focus:ring-red-500' 
                                          : 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500'
                                    }`}
                                    required
                                 />
                                 <button
                                    type="button"
                                    onClick={() => setShowConfirmPass(!showConfirmPass)}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                 >
                                    {showConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                 </button>
                              </div>
                              {confirmPassword && (
                                 <p className={`text-[11px] mt-1 ${confirmPassword === newPassword ? 'text-emerald-600' : 'text-red-500'}`}>
                                    {confirmPassword === newPassword ? '✓ Password cocok' : '✗ Password belum sama'}
                                 </p>
                              )}
                           </div>
                        </div>

                        {/* Tombol Simpan */}
                        <div className="pt-2 flex items-center gap-3">
                           <button
                              type="submit"
                              disabled={isChangingOwnPass}
                              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg font-semibold text-xs transition-colors shadow-sm flex items-center gap-2 disabled:opacity-60 cursor-pointer"
                           >
                              {isChangingOwnPass ? (
                                 <>
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    Menyimpan Password...
                                 </>
                              ) : (
                                 <>
                                    <Lock className="w-4 h-4" />
                                    Simpan Password Baru
                                 </>
                              )}
                           </button>

                           {(currentPassword || newPassword || confirmPassword) && !isChangingOwnPass && (
                              <button
                                 type="button"
                                 onClick={() => {
                                    setCurrentPassword('');
                                    setNewPassword('');
                                    setConfirmPassword('');
                                    setOwnPassError('');
                                    setOwnPassSuccess('');
                                 }}
                                 className="px-4 py-2.5 border border-gray-300 hover:bg-gray-50 text-gray-600 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                              >
                                 Batal
                              </button>
                           )}
                        </div>
                     </form>
                  </div>

                  {/* Super Admin Reset Password Panel */}
                  {isSuperAdmin && (
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-indigo-100 bg-gradient-to-br from-white to-indigo-50/30">
                     <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 border-b border-indigo-100 pb-4">
                        <div>
                           <div className="flex items-center gap-2">
                             <span className="bg-indigo-600 text-white text-xs font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">Super Admin</span>
                             <h2 className="text-lg font-bold text-gray-800">Manajemen User & Reset Password Manual</h2>
                           </div>
                           <p className="text-sm text-gray-600 mt-1">
                              Fitur langsung Super Admin (<strong className="text-indigo-700">humas@mmpackaging.co.id</strong>) untuk mereset password akun admin secara instan tanpa melalui email korporasi / spam filter.
                           </p>
                        </div>
                        <div className="flex gap-2">
                           <button onClick={fetchAdminUsers} className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 hover:bg-gray-50 text-gray-700 text-sm font-medium rounded-lg transition-colors">
                              <RefreshCw className="h-4 w-4" /> Refresh
                           </button>
                           <button onClick={() => setIsAddAdminModalOpen(true)} className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 text-sm font-medium rounded-lg transition-colors shadow-sm">
                              <UserPlus className="h-4 w-4" /> Tambah Admin Baru
                           </button>
                        </div>
                     </div>

                     {resetSuccessData && (
                        <div className="mb-6 p-4 bg-emerald-50 border border-emerald-200 rounded-xl relative">
                           <button onClick={() => setResetSuccessData(null)} className="absolute top-3 right-3 text-emerald-700 hover:text-emerald-900">
                             <X className="h-5 w-5" />
                           </button>
                           <div className="flex items-start gap-3">
                              <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                                <UserCheck className="h-5 w-5" />
                              </div>
                              <div className="space-y-1">
                                 <h4 className="font-bold text-emerald-900 text-sm">Password Berhasil Di-reset Manual oleh Super Admin!</h4>
                                 <p className="text-xs text-emerald-800">
                                    Gunakan kredensial berikut untuk diberikan langsung kepada karyawan / user:
                                 </p>
                                 <div className="mt-2 p-3 bg-white border border-emerald-200 rounded-lg font-mono text-xs text-gray-800 space-y-1">
                                    <div><strong>User ID / Email:</strong> {resetSuccessData.userId} ({resetSuccessData.email})</div>
                                    <div><strong>Password Baru:</strong> <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold">{resetSuccessData.pass}</span></div>
                                 </div>
                                 <button
                                   onClick={() => {
                                      const text = `Halo ${resetSuccessData.userId},\n\nPassword akun Admin MMP HR Anda telah di-reset secara manual oleh Super Admin (humas@mmpackaging.co.id).\n\nUser ID / Email: ${resetSuccessData.email || resetSuccessData.userId}\nPassword Baru: ${resetSuccessData.pass}\n\nSilakan gunakan kredensial di atas untuk login ke Dashboard MMP Packaging.`;
                                      navigator.clipboard.writeText(text);
                                      alert('Kredensial berhasil disalin ke clipboard! Siap dikirim ke WhatsApp / Email karyawan.');
                                   }}
                                   className="mt-2 inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors"
                                 >
                                    <Copy className="h-3.5 w-3.5" /> Salin Pesan Kredensial Karyawan
                                 </button>
                              </div>
                           </div>
                        </div>
                     )}

                     
                      {/* Card: Sistem Registrasi Akun Gmail & Proteksi Anti-Penyusup */}
                      <div className="mb-6 bg-white border border-indigo-200 rounded-xl p-5 shadow-sm space-y-4">
                        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-gray-100 pb-3">
                          <div className="flex items-center gap-2.5">
                            <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
                              <Shield className="h-5 w-5" />
                            </div>
                            <div>
                              <h3 className="font-bold text-gray-800 text-sm">Proteksi Pendaftaran Admin (@gmail.com) & Anti-Penyusup</h3>
                              <p className="text-xs text-gray-500">
                                Memungkinkan staf mendaftar via Gmail (reset password dijamin 100% lancar), namun orang luar tetap terkunci.
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={handleCopyInviteMessage}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors whitespace-nowrap self-start sm:self-center"
                          >
                            <Copy className="h-3.5 w-3.5" />
                            <span>{copyInviteSuccess ? 'Format Undangan Disalin!' : 'Salin Undangan WhatsApp Staf'}</span>
                          </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                          <div className="md:col-span-2 bg-indigo-50/50 rounded-lg p-3.5 border border-indigo-100 text-gray-700 space-y-2">
                            <div className="font-semibold text-indigo-900 flex items-center gap-1.5">
                              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                              Mengapa Akun Gmail Sangat Direkomendasikan & Tetap Aman:
                            </div>
                            <ul className="list-disc pl-4 space-y-1.5 text-gray-600 leading-relaxed">
                              <li>
                                <b>Bebas Hambatan Firewall Kantor:</b> Server email korporasi sering memblokir email otomatis Firebase. Server Google Gmail menerima link reset password seketika di Inbox.
                              </li>
                              <li>
                                <b>Anti-Penyusup dengan Kode Rahasia:</b> Pendaftar umum di halaman Login wajib menyertakan <b>Kode Otorisasi Perusahaan</b> di samping. Tanpa kode ini, pendaftaran publik ditolak sistem.
                              </li>
                              <li>
                                <b>Pendaftaran Langsung Super Admin:</b> Anda juga dapat mendaftarkan email staf langsung lewat tombol <i>"+ Tambah Admin Baru"</i> di atas.
                              </li>
                            </ul>
                          </div>

                          <div className="bg-gray-50 rounded-lg p-3.5 border border-gray-200 flex flex-col justify-between">
                            <div>
                              <label className="block font-bold text-gray-700 text-xs mb-1">
                                Kode Otorisasi Perusahaan Aktif:
                              </label>
                              <p className="text-[11px] text-gray-500 mb-2 leading-tight">
                                Bagikan kode rahasia ini hanya kepada rekan tim resmi MMP yang diizinkan mendaftar.
                              </p>
                              <div className="flex gap-2">
                                <input
                                  type="text"
                                  value={registrationSecretCode}
                                  onChange={(e) => setRegistrationSecretCode(e.target.value)}
                                  className="flex-1 font-mono font-bold text-indigo-700 bg-white border border-gray-300 rounded px-2.5 py-1.5 text-xs focus:border-indigo-500 outline-none uppercase"
                                />
                                <button
                                  onClick={handleSaveSecurityCode}
                                  disabled={isSavingSecurityCode}
                                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold transition"
                                >
                                  {isSavingSecurityCode ? '...' : 'Simpan'}
                                </button>
                              </div>
                            </div>
                            <div className="mt-2 text-[10px] text-gray-400">
                              Default: MMP-ADMIN-2026
                            </div>
                          </div>
                        </div>
                      </div>

                      {isLoadingAdminUsers ? (
                        <div className="flex justify-center items-center py-8 text-gray-500 gap-2">
                           <Loader2 className="h-5 w-5 animate-spin text-indigo-600" />
                           <span className="text-sm">Memuat daftar akun admin...</span>
                        </div>
                     ) : (
                        <div className="overflow-x-auto rounded-lg border border-gray-200">
                           <table className="w-full text-left text-sm">
                              <thead className="bg-gray-50 text-gray-700 font-semibold border-b border-gray-200">
                                 <tr>
                                    <th className="p-3">User ID</th>
                                    <th className="p-3">Email Akun</th>
                                    <th className="p-3">Status Password</th>
                                    <th className="p-3 text-right">Aksi Super Admin</th>
                                 </tr>
                              </thead>
                              <tbody className="divide-y divide-gray-200">
                                 {adminUsersList.length === 0 ? (
                                    <tr>
                                       <td colSpan={4} className="p-4 text-center text-gray-500">
                                          Belum ada akun admin terdaftar.
                                       </td>
                                    </tr>
                                 ) : (
                                    adminUsersList.map((userItem, idx) => {
                                       const isHumas = (userItem.email || '').toLowerCase() === 'humas@mmpackaging.co.id' || userItem.userId === 'humas';
                                       return (
                                          <tr key={idx} className="hover:bg-gray-50/80 transition-colors">
                                             <td className="p-3 font-medium text-gray-900 flex items-center gap-2">
                                                <User className="h-4 w-4 text-gray-400" />
                                                <span>{userItem.userId || 'Admin'}</span>
                                                {isHumas && (
                                                   <span className="bg-indigo-100 text-indigo-800 text-[10px] font-bold px-2 py-0.5 rounded-full">Super Admin</span>
                                                )}
                                             </td>
                                             <td className="p-3 text-gray-600 font-mono text-xs">
                                                {userItem.email || '-'}
                                             </td>
                                             <td className="p-3 text-xs">
                                                {userItem.manualPassword ? (
                                                   <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-medium">
                                                      <UserCheck className="h-3 w-3" /> Manual Reset
                                                   </span>
                                                ) : (
                                                   <span className="inline-flex items-center gap-1 text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full font-medium">
                                                      Standard Firebase
                                                   </span>
                                                )}
                                                {userItem.passwordLastResetAt && (
                                                   <div className="text-[10px] text-gray-400 mt-0.5">
                                                      Terakhir: {new Date(userItem.passwordLastResetAt).toLocaleDateString('id-ID')}
                                                   </div>
                                                )}
                                             </td>
                                             <td className="p-3 text-right space-x-2">
                                                <button
                                                   onClick={() => {
                                                      setSelectedUserForReset(userItem);
                                                      handleGenerateRandomPass();
                                                   }}
                                                   className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors inline-flex items-center gap-1"
                                                >
                                                   <Lock className="h-3.5 w-3.5" /> Reset Password Manual
                                                </button>
                                                {!isHumas && (
                                                   <button
                                                      onClick={() => handleDeleteAdminDoc(userItem)}
                                                      className="text-red-600 hover:text-red-800 hover:bg-red-50 p-1.5 rounded-lg text-xs transition-colors inline-flex items-center"
                                                      title="Hapus Akun Admin"
                                                   >
                                                      <X className="h-4 w-4" />
                                                   </button>
                                                )}
                                             </td>
                                          </tr>
                                       );
                                    })
                                 )}
                              </tbody>
                           </table>
                        </div>
                     )}
                  </div>
                  )}

                  {/* Pengaturan Perusahaan Biasa */}
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                     <h2 className="text-lg font-bold mb-4 border-b pb-2 text-gray-800">Pengaturan Umum Aplikasi</h2>
                     <p className="text-sm text-gray-600 mb-6">Kelola preferensi nama perusahaan, email utama HR, dan penomoran kandidat.</p>
                     <div className="space-y-4 max-w-lg">
                         <div>
                             <label className="block text-sm font-medium mb-1 text-gray-700">Nama Perusahaan</label>
                             <input type="text" value={companyName} onChange={e => setCompanyName(e.target.value)} className="w-full border border-gray-300 p-2 rounded text-sm focus:border-blue-500 outline-none" />
                         </div>
                         <div>
                             <label className="block text-sm font-medium mb-1 text-gray-700">Email Utama HR</label>
                             <input type="email" value={hrEmail} onChange={e => setHrEmail(e.target.value)} className="w-full border border-gray-300 p-2 rounded text-sm focus:border-blue-500 outline-none" />
                         </div>
                         <div>
                             <label className="block text-sm font-medium mb-1 text-gray-700">Format Nomor Kandidat</label>
                             <input type="text" value={candidateFormat} onChange={e => setCandidateFormat(e.target.value)} className="w-full border border-gray-300 p-2 rounded text-sm focus:border-blue-500 outline-none" />
                         </div>
                         <div className="pt-2">
                            <button onClick={() => {
                               localStorage.setItem('setting_company_name', companyName);
                               localStorage.setItem('setting_hr_email', hrEmail);
                               localStorage.setItem('setting_candidate_format', candidateFormat);
                               alert('Pengaturan Berhasil Disimpan');
                            }} className="bg-[#6610f2] hover:bg-[#520dc2] text-white px-4 py-2 rounded font-medium text-sm transition-colors">Simpan Pengaturan</button>
                         </div>
                     </div>
                  </div>
                </div>
             )}
            
            {activeTab === 'documents' && (
                 <div className="bg-white p-6 rounded shadow-sm border border-gray-200 max-w-4xl">
                    <h2 className="text-lg font-bold mb-4 border-b pb-2 text-gray-800">Dokumen & Template Pesan</h2>
                    <p className="text-sm text-gray-600 mb-6">Atur template pesan WhatsApp yang dikirimkan ke kandidat (Diterima, Ditolak, atau Undangan Interview).</p>
                    <div className="space-y-6">
                        <div className="border border-gray-200 p-4 rounded bg-gray-50/50 hover:border-blue-200 transition-colors">
                            <h3 className="font-semibold text-gray-700 mb-2">Template Undangan Interview</h3>
                            <textarea className="w-full p-3 border border-gray-300 rounded font-sans text-sm h-32 focus:border-blue-500 outline-none" value={templateInterview} onChange={e => setTemplateInterview(e.target.value)} />
                            <div className="flex justify-end mt-2">
                               <button onClick={() => {
                                  localStorage.setItem('setting_template_interview', templateInterview);
                                  alert('Template Undangan Berhasil Disimpan');
                               }} className="bg-[#28a745] hover:bg-[#218838] text-white px-4 py-1.5 text-sm font-medium rounded transition-colors">Simpan Template</button>
                            </div>
                        </div>
                        <div className="border border-gray-200 p-4 rounded bg-gray-50/50 hover:border-blue-200 transition-colors">
                            <h3 className="font-semibold text-gray-700 mb-2">Template Penolakan</h3>
                            <textarea className="w-full p-3 border border-gray-300 rounded font-sans text-sm h-32 focus:border-blue-500 outline-none" value={templateReject} onChange={e => setTemplateReject(e.target.value)} />
                            <div className="flex justify-end mt-2">
                               <button onClick={() => {
                                  localStorage.setItem('setting_template_reject', templateReject);
                                  alert('Template Penolakan Berhasil Disimpan');
                               }} className="bg-[#28a745] hover:bg-[#218838] text-white px-4 py-1.5 text-sm font-medium rounded transition-colors">Simpan Template</button>
                            </div>
                        </div>
                        <div className="border border-gray-200 p-4 rounded bg-gray-50/50 hover:border-blue-200 transition-colors">
                            <h3 className="font-semibold text-gray-700 mb-2">Template Diterima</h3>
                            <textarea className="w-full p-3 border border-gray-300 rounded font-sans text-sm h-32 focus:border-blue-500 outline-none" value={templateDiterima} onChange={e => setTemplateDiterima(e.target.value)} />
                            <div className="flex justify-end mt-2">
                               <button onClick={() => {
                                  localStorage.setItem('setting_template_diterima', templateDiterima);
                                  alert('Template Diterima Berhasil Disimpan');
                               }} className="bg-[#28a745] hover:bg-[#218838] text-white px-4 py-1.5 text-sm font-medium rounded transition-colors">Simpan Template</button>
                            </div>
                        </div>
                    </div>
                 </div>
            )}
         </div>
      </main>

      {/* Export Modal */}
      {isExportModalOpen && (
         <div className="fixed inset-0 bg-black/50 z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-sm overflow-hidden text-sm">
               <div className="bg-green-600 text-white px-4 py-3 flex justify-between items-center shrink-0">
                  <h3 className="font-bold flex items-center gap-2"><Download className="w-4 h-4" /> Export Data Excel</h3>
                  <button onClick={() => setIsExportModalOpen(false)} className="text-white/80 hover:text-white">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               <div className="p-5">
                  <p className="text-gray-600 mb-4">Anda akan mengekspor {filteredApplicants.length} data pelamar ke format file <strong>Excel (.xlsx)</strong>.</p>
                  <div className="flex justify-end gap-2">
                     <button onClick={() => setIsExportModalOpen(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded font-medium">Batal</button>
                     <button onClick={() => {
                        if (filteredApplicants.length === 0) {
                           alert('Tidak ada data pelamar untuk diekspor.');
                           return;
                        }

                        // Collect all unique keys from rawData
                        const allKeysSet = new Set<string>();
                        filteredApplicants.forEach(app => {
                           if (app.rawData) {
                              Object.keys(app.rawData).forEach(k => {
                                 if (k !== 'struktur_method' && k !== 'struktur_organisasi_teks') {
                                    allKeysSet.add(k);
                                 }
                              });
                           }
                        });

                        const keys = Array.from(allKeysSet).sort((a, b) => getOrderIndex(a) - getOrderIndex(b));

                        const exportRows = filteredApplicants.map(app => {
                           const rowObj: Record<string, any> = {};
                           keys.forEach(k => {
                              let val = app.rawData ? app.rawData[k] : '';
                              if (val === undefined || val === null) val = '';
                              if (k === 'Tanggal Lahir' && val) val = formatTanggalLahirIndo(String(val));
                              if (k === 'Timestamp (Waktu Submit)' && val) val = formatDateTimeIndo(String(val));
                              rowObj[k] = val;
                           });
                           return rowObj;
                        });

                        const worksheet = XLSX.utils.json_to_sheet(exportRows);
                        const workbook = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Pelamar');

                        const dateStr = new Date().toISOString().split('T')[0];
                        XLSX.writeFile(workbook, `Data_Pelamar_${dateStr}.xlsx`);
                        setIsExportModalOpen(false); 
                     }} className="px-4 py-2 bg-[#28a745] text-white rounded hover:bg-[#218838] flex items-center gap-2 font-medium">
                        <Download className="w-4 h-4" /> Download .XLSX
                     </button>
                  </div>
               </div>
            </div>
         </div>
      )}

      {/* Advanced Filter Modal */}
      {isFilterModalOpen && (
         <div className="fixed inset-0 bg-black/50 z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl overflow-hidden flex flex-col text-sm max-h-[90vh]">
               <div className="bg-blue-600 text-white px-4 py-3 flex justify-between items-center shrink-0">
                  <h3 className="font-bold flex items-center gap-2"><Filter className="w-4 h-4" /> Filter Tingkat Lanjut</h3>
                  <button onClick={() => setIsFilterModalOpen(false)} className="text-white/80 hover:text-white">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               
               <div className="p-5 overflow-y-auto flex-1">
                  {/* Posisi */}
                  <div className="mb-6">
                     <label className="font-bold text-gray-700 block mb-2">Posisi / Pekerjaan</label>
                     <select value={posisiFilterDropdown} onChange={e => setPosisiFilterDropdown(e.target.value)} className="border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500 w-full">
                        <option value="">Semua Posisi</option>
                        {JOB_OPTIONS.map(job => <option key={job} value={job}>{job}</option>)}
                     </select>
                  </div>

                  {/* Pendidikan */}
                  <div className="pt-4 border-t border-gray-100">
                     <div className="flex justify-between items-center mb-3">
                        <h4 className="font-bold text-gray-700">Pendidikan & Jurusan</h4>
                     </div>
                     <div className="space-y-3">
                         {eduFilters.map((ef, idx) => (
                             <div key={idx} className="flex gap-3 bg-gray-50 border border-gray-200 p-3 rounded items-end">
                                 <div className="flex flex-col w-1/3">
                                     <label className="text-xs text-gray-500 mb-1">Tingkat Pendidikan</label>
                                     <select value={ef.tingkat} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, tingkat: e.target.value, jurusan: ""} : f))} className="border-gray-300 rounded px-2 py-1.5 outline-none bg-white border">
                                         <option value="Semua">Semua Tingkat</option>
                                         <option value="SD">SD</option>
                                         <option value="SLTP">SLTP</option>
                                         <option value="SLTA/SMU/SMK">SLTA/SMU/SMK</option>
                                         <option value="D1/D2/D3">D1/D2/D3</option>
                                         <option value="S1">S1</option>
                                         <option value="S2/S3">S2/S3</option>
                                         {activeEduLevels.filter(lvl => !['SD', 'SLTP', 'SLTA/SMU/SMK', 'D1/D2/D3', 'S1', 'S2/S3'].includes(lvl)).map(lvl => <option key={lvl} value={lvl}>{lvl}</option>)}
                                     </select>
                                 </div>
                                 <div className="flex flex-col flex-1">
                                     <label className="text-xs text-gray-500 mb-1">Pilih / Ketik Jurusan</label>
                                     {ef.tingkat === 'SLTA/SMU/SMK' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_SMU.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : (ef.tingkat === 'S1' || ef.tingkat === 'D1/D2/D3') ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_S1.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : ef.tingkat === 'S2/S3' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_S2.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : ef.tingkat === 'Semua' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {activeJurusanList.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : (
                                        <input type="text" value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} placeholder="Ketik jurusan..." className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border" />
                                     )}
                                 </div>
                                 {idx > 0 && <button onClick={() => setEduFilters(eduFilters.filter((_, i) => i !== idx))} className="text-red-500 hover:bg-red-50 p-1.5 rounded border border-red-200 h-8 flex items-center justify-center shrink-0"><X className="w-4 h-4" /></button>}
                             </div>
                         ))}
                         
                         <button onClick={() => setEduFilters([...eduFilters, { tingkat: 'Semua', jurusan: '' }])} className="flex items-center gap-1 text-blue-600 hover:text-blue-700 mt-2 text-sm font-medium">
                             <Plus className="w-4 h-4" /> Tambah Filter Pendidikan
                         </button>
                     </div>
                  </div>

                  {/* Skills */}
                  <div className="mt-6 pt-4 border-t border-gray-100">
                     <h4 className="font-bold text-gray-700 mb-3">Skills (Harus memiliki)</h4>
                     <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                        {skillList.map(skill => (
                           <label key={skill} className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" checked={selectedSkills.includes(skill)} onChange={(e) => {
                                  if(e.target.checked) setSelectedSkills([...selectedSkills, skill]);
                                  else setSelectedSkills(selectedSkills.filter(s => s !== skill));
                              }} className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" /> 
                              <span className="text-sm text-gray-600">{skill}</span>
                           </label>
                        ))}
                     </div>
                  </div>
               </div>
               
               <div className="p-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-2 shrink-0">
                  <button onClick={() => setIsFilterModalOpen(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded">Batal</button>
                  <button onClick={() => {
                     setAppliedEduFilters([...eduFilters]);
                     setAppliedSelectedSkills([...selectedSkills]);
                     setPosisiFilter(posisiFilterDropdown);
                     setIsFilterModalOpen(false);
                  }} className="px-4 py-2 bg-blue-600 text-white rounded font-medium hover:bg-blue-700">Terapkan Filter</button>
               </div>
            </div>
         </div>
      )}

      {/* Update Status Modal */}
      {openStatusModalId !== null && (
         <div className="fixed inset-0 bg-black/50 z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden text-sm">
               <div className="bg-indigo-600 text-white px-4 py-3 flex justify-between items-center">
                  <h3 className="font-bold">Update Status Kandidat</h3>
                  <button onClick={() => {
                     setUpdateStatusVal('');
                     setUpdateStatusNote('');
                     setGeneratedMessage('');
                     setOpenStatusModalId(null);
                  }} className="text-white/80 hover:text-white">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                  <div>
                     <label className="block text-gray-700 font-medium mb-1">Status Baru</label>
                        <select value={updateStatusVal} onChange={(e) => {
                           const val = e.target.value;
                           setUpdateStatusVal(val);
                           const app = applicants.find(a => a.id === openStatusModalId);
                           if (app) {
                               let tmpl = '';
                               if (val === 'Undangan Interview') tmpl = templateInterview;
                               if (val === 'Ditolak') tmpl = templateReject;
                               if (val === 'Diterima') tmpl = templateDiterima;
                               
                               if (tmpl) {
                                   let msg = tmpl.replace(/[\(\[\{]?(?:nama )?kandidat[\)\]\}]?/gi, app.nama || "");
                                   msg = msg.replace(/[\(\[\{]?(?:nama )?posisi[^\)\]\}]*[\)\]\}]?/gi, app.posisi || "");
                                   setGeneratedMessage(msg);
                               } else {
                                   setGeneratedMessage('');
                               }
                           }
                       }} className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-indigo-500">
                        <option value="">-- pilih status --</option>
                        <option value="Kirim WA">Kirim WA / Belum Diproses</option>
                        <option value="Sedang Diproses">Sedang Diproses</option>
                        <option value="Undangan Interview">Undangan Interview</option>
                        <option value="Diterima">Diterima</option>
                        <option value="Ditolak">Ditolak</option>
                     </select>
                  </div>
                  <div>
                     <label className="block text-gray-700 font-medium mb-1">Catatan Tambahan (Internal)</label>
                     <textarea value={updateStatusNote} onChange={e => setUpdateStatusNote(e.target.value)} className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-indigo-500 min-h-[80px]" placeholder="Catatan internal HCGA..."></textarea>
                  </div>
                  
                  {['Undangan Interview', 'Diterima', 'Ditolak'].includes(updateStatusVal) && (
                     <div className="bg-gray-50 border border-gray-200 p-4 rounded mt-4">
                        <label className="flex items-center gap-2 font-medium text-gray-700 mb-2 cursor-pointer">
                           <input type="checkbox" checked={sendWhatsapp} onChange={e => setSendWhatsapp(e.target.checked)} className="rounded border-gray-300" />
                           Kirim Notifikasi via WhatsApp
                        </label>
                        {sendWhatsapp && (
                           <>
                              <p className="text-xs text-gray-500 mb-2">Edit pesan di bawah jika perlu sebelum membuka WhatsApp Web.</p>
                              <textarea 
                                 value={generatedMessage} 
                                 onChange={e => setGeneratedMessage(e.target.value)}
                                 className="w-full border border-blue-200 rounded px-3 py-2 outline-none focus:border-blue-500 bg-white min-h-[120px] text-sm"
                              ></textarea>
                           </>
                        )}
                     </div>
                  )}
               </div>
               <div className="px-5 py-3 border-t bg-gray-50 flex justify-end gap-2 shrink-0">
                  <button onClick={() => setOpenStatusModalId(null)} className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-medium transition">Batal</button>
                  <button onClick={() => {
                      if (!updateStatusVal) return alert('Pilih status baru terlebih dahulu');
                      
                      
                      
                      
                      setApplicants(applicants.map(app => {
                         if (app.id === openStatusModalId) {
                             return {...app, status: updateStatusVal, note: updateStatusNote};
                         }
                         return app;
                      }));
                      
                      const app = applicants.find(a => a.id === openStatusModalId);
                      if (app?.rawData?.docId) {
                          updateDoc(doc(db, 'pelamar', app.rawData.docId), {
                              Status: updateStatusVal,
                              Notes: updateStatusNote || ""
                          }).catch(err => console.error("Failed to sync status", err));
                      }
                      
                      setOpenStatusModalId(null);
                      
                      if (sendWhatsapp && generatedMessage && app?.telpHP) {
                          const encoded = encodeURIComponent(generatedMessage);
                          window.open(`https://wa.me/${formatWhatsAppNumber(app.telpHP)}?text=${encoded}`, '_blank');
                      }
                  }} className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition font-medium">
                     {sendWhatsapp ? 'Update Status & Kirim WA' : 'Update Status'}
                  </button>
               </div>
            </div>
         </div>
      )}

      {/* View File Modal */}
      {viewFileModal?.isOpen && (
         <div className="fixed inset-0 bg-black/50 z-[110] flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden text-sm">
               <div className="bg-indigo-600 text-white px-4 py-3 flex justify-between items-center">
                  <h3 className="font-bold">{viewFileModal.title}</h3>
                  <button onClick={() => setViewFileModal(null)} className="text-white/80 hover:text-white">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               <div className="p-5">
                  <div className="bg-gray-50 rounded p-4 border border-gray-200 min-h-[100px] flex items-center justify-center text-center text-gray-600">
                     {viewFileModal.content}
                  </div>
               </div>
               <div className="px-5 py-3 border-t bg-gray-50 flex justify-end">
                  <button onClick={() => setViewFileModal(null)} className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded font-medium transition">Tutup</button>
               </div>
            </div>
         </div>
      )}

      {/* Confirm Delete Modal */}
      {confirmDeleteModal.isOpen && confirmDeleteModal.app && (
         <div className="fixed inset-0 bg-black/50 z-[130] flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-sm overflow-hidden text-sm">
               <div className="bg-red-600 text-white px-4 py-3 flex justify-between items-center">
                  <h3 className="font-bold">Konfirmasi Hapus</h3>
                  <button onClick={() => setConfirmDeleteModal({isOpen: false, app: null})} className="text-white/80 hover:text-white">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               <div className="p-5">
                  <p className="text-gray-700 mb-4 text-sm">
                     Apakah Anda yakin ingin menghapus lamaran dari <strong>{confirmDeleteModal.app.nama}</strong> secara permanen? Data akan benar-benar dihapus.
                  </p>
                  <div className="flex justify-end gap-2">
                     <button 
                        onClick={() => setConfirmDeleteModal({isOpen: false, app: null})} 
                        className="px-4 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded font-medium transition-colors"
                     >
                        Batal
                     </button>
                     <button 
                        onClick={() => executeDeleteApp(confirmDeleteModal.app)} 
                        className="px-4 py-2 text-white bg-red-600 hover:bg-red-700 rounded font-medium transition-colors"
                     >
                        Ya, Hapus
                     </button>
                  </div>
               </div>
            </div>
         </div>
      )}

      {/* Detail Modal */}
      {selectedApplicant && (() => {
         const rawData = selectedApplicant.rawData || {};
         let rawFoto = rawData['Foto Pelamar (URL)'] || rawData['foto_pelamar'] || rawData['Foto Pelamar'] || rawData['Foto KTP (URL)'] || rawData['Foto KTP (Base64)'] || rawData['Foto'] || rawData['foto'];
         if (!rawFoto) {
           const fotoKey = Object.keys(rawData).find(k => k.toLowerCase().includes('foto pelamar') || k.toLowerCase().includes('foto_pelamar'));
           if (fotoKey) rawFoto = rawData[fotoKey];
         }

         let rawTtd = rawData['Tanda Tangan (URL)'] || rawData['Tanda Tangan (Base64)'] || rawData['Tanda Tangan'] || rawData['ttd'] || rawData['tanda_tangan'] || rawData['Tanda Tangan Pelamar'] || rawData['signature'];
         if (!rawTtd) {
           const ttdKey = Object.keys(rawData).find(k => k.toLowerCase().includes('tanda tangan') || k.toLowerCase().includes('ttd') || k.toLowerCase().includes('signature'));
           if (ttdKey) rawTtd = rawData[ttdKey];
         }

         const applicantFotoUrl = formatImageUrl(rawFoto);
         const applicantTtdUrl = formatImageUrl(rawTtd);

         return (
          <div id="print-modal-container" className="fixed inset-0 bg-black/50 z-[120] flex items-center justify-center p-4">
             <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl overflow-hidden text-sm flex flex-col max-h-[90vh]">
                <div className="bg-blue-600 text-white px-5 py-4 flex justify-between items-center shrink-0">
                   <h3 className="font-bold text-lg">Detail Pelamar</h3>
                   <button onClick={() => setSelectedApplicant(null)} className="text-white/80 hover:text-white transition-colors">
                      <X className="w-6 h-6" />
                   </button>
                </div>
                <div id="print-modal-content" className="p-6 overflow-y-auto bg-gray-50 flex-1 space-y-6">
                   {/* Summary Section Header with Applicant Photo */}
                   <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm flex items-center gap-4">
                      {applicantFotoUrl ? (
                         <img 
                            src={applicantFotoUrl} 
                            alt={selectedApplicant.nama} 
                            referrerPolicy="no-referrer" 
                            className="w-20 h-24 object-cover rounded-lg border border-gray-300 shadow-md shrink-0 bg-gray-100" 
                         />
                      ) : (
                         <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 shrink-0">
                            <User className="w-8 h-8" />
                         </div>
                      )}
                      <div className="flex-1">
                         <h4 className="text-xl font-bold text-gray-800">{selectedApplicant.nama}</h4>
                         <p className="text-gray-500 font-medium mb-2">{selectedApplicant.posisi}</p>
                         <div className="flex flex-wrap gap-2 text-xs font-medium">
                            <span className="bg-gray-100 border text-gray-700 px-2 py-1 rounded">No Reg: {selectedApplicant.kode}</span>
                            <span className="bg-gray-100 border text-gray-700 px-2 py-1 rounded">Tgl Submit: {selectedApplicant.tanggalMasuk}</span>
                         </div>
                      </div>
                   </div>

                   {/* Detail All Data */}
                   <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm space-y-4">
                      <h5 className="font-bold text-gray-800 border-b pb-2 mb-3">Seluruh Data Pelamar</h5>
                      <div className="flex flex-col gap-3">
                         {(() => {
                            let renderedFoto = false;
                            let renderedTtd = false;
                            let renderedCv = false;

                            const sortedEntries = Object.entries(rawData)
                               .sort((a,b) => getOrderIndex(a[0]) - getOrderIndex(b[0]))
                               .filter(([key]) => key !== 'struktur_method' && key !== 'struktur_organisasi_teks');

                            return sortedEntries.map(([key, value]) => {
                               if (!value || value === '-' || value === '-\n-') return null;

                               const lowerKey = key.toLowerCase();

                               // Photo key detection & deduplication (already shown at top header card, skip here)
                               const isFotoKey = ['foto pelamar (url)', 'foto ktp (url)', 'foto_pelamar', 'foto ktp (base64)', 'foto pelamar', 'foto'].includes(lowerKey) || lowerKey.includes('foto pelamar') || lowerKey.includes('foto_pelamar');
                               
                               if (isFotoKey) {
                                  return null;
                               }

                               // Signature key detection & deduplication
                               const isTtdKey = ['tanda tangan (url)', 'tanda tangan (base64)', 'tanda tangan', 'ttd', 'tanda_tangan', 'tanda tangan pelamar', 'signature'].includes(lowerKey) || lowerKey.includes('tanda tangan') || lowerKey.includes('signature') || lowerKey.includes('ttd');

                               if (isTtdKey) {
                                  if (renderedTtd) return null;
                                  renderedTtd = true;
                                  const imgUrl = formatImageUrl(value) || applicantTtdUrl;
                                  return (
                                     <div key={key} className="flex flex-col border-b border-gray-100 pb-2">
                                        <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">Tanda Tangan</span>
                                        {imgUrl ? (
                                          <img src={imgUrl} alt="Tanda Tangan" referrerPolicy="no-referrer" className="max-h-28 max-w-xs rounded border p-1 bg-white object-contain shadow-sm mt-1" />
                                        ) : (
                                          <span className="text-gray-400 text-xs italic">Tanda tangan tidak tersedia</span>
                                        )}
                                     </div>
                                  );
                               }

                               // CV key detection & deduplication
                               const isCvKey = ['cv (url)', 'cv_pelamar', 'cv (base64)', 'cv'].includes(lowerKey) || lowerKey.includes('cv pelamar') || lowerKey.includes('cv_pelamar');

                               if (isCvKey) {
                                  if (renderedCv) return null;
                                  renderedCv = true;
                                  const isLink = String(value).startsWith('http') || String(value).startsWith('data:');
                                  return (
                                      <div key={key} className="flex flex-col border-b border-gray-100 pb-2">
                                        <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">CV Pelamar</span>
                                        {isLink ? (
                                          <a href={String(value)} download={String(value).startsWith('data:') ? 'CV_Pelamar.pdf' : undefined} target="_blank" rel="noreferrer" className="px-3 py-1.5 bg-blue-100 text-blue-700 hover:bg-blue-200 mt-1 rounded text-sm font-medium border border-blue-200 self-start inline-flex items-center gap-1.5 transition-colors">Unduh Dokumen CV</a>
                                        ) : (
                                          <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium border border-green-200 self-start mt-1">Dilampirkan (Format Lama)</span>
                                        )}
                                     </div>
                                  );
                               }

                               let displayValue = value;
                               if (key === 'Tanggal Lahir') displayValue = formatTanggalLahirIndo(String(value));
                               if (key === 'Timestamp (Waktu Submit)') {
                                  displayValue = formatDateTimeIndo(String(value));
                               }

                               return (
                                  <div key={key} className="flex flex-col border-b border-gray-100 pb-2">
                                     <span className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-1">{key}</span>
                                     <FormatAsReactTable text={String(displayValue)} />
                                  </div>
                               );
                            });
                         })()}
                      </div>
                   </div>
                </div>
                <div className="px-6 py-4 border-t bg-white flex justify-end gap-3 shrink-0 print:hidden">
                   <button onClick={() => {
                      printHTML(generatePelamarPrintHTML(selectedApplicant));
                   }} className="px-5 py-2.5 bg-blue-100 text-blue-700 font-medium hover:bg-blue-200 rounded-lg transition-colors border border-blue-200 flex items-center gap-2">
                      <FileText className="w-4 h-4" /> Print
                   </button>
                   <button onClick={() => setSelectedApplicant(null)} className="px-5 py-2.5 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition-colors border border-gray-200">Tutup</button>
                   <a href={`https://wa.me/${formatWhatsAppNumber(selectedApplicant.telpHP)}`} target="_blank" rel="noreferrer" className="px-5 py-2.5 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 transition-colors">
                      Hubungi via WhatsApp
                   </a>
                </div>
             </div>
          </div>
         );
      })()}

      {/* Super Admin Reset Password Manual Modal */}
      {selectedUserForReset && (
         <div className="fixed inset-0 bg-black/50 z-[150] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden text-sm">
               <div className="bg-indigo-600 text-white px-5 py-4 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                     <Lock className="w-5 h-5 text-indigo-200" />
                     <h3 className="font-bold text-base">Reset Password Manual (Super Admin)</h3>
                  </div>
                  <button onClick={() => setSelectedUserForReset(null)} className="text-white/80 hover:text-white p-1 rounded-lg">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               <div className="p-6 space-y-4">
                  <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-3 text-xs text-indigo-900 space-y-1">
                     <div><strong>Target User ID:</strong> {selectedUserForReset.userId || selectedUserForReset.email || 'Admin'}</div>
                     <div><strong>Target Email:</strong> {selectedUserForReset.email || '-'}</div>
                     <div><strong>Super Admin Executor:</strong> humas@mmpackaging.co.id</div>
                  </div>

                  <div>
                     <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Password Baru Karyawan / Admin
                     </label>
                     <div className="flex gap-2">
                        <input
                           type="text"
                           value={manualResetPasswordInput}
                           onChange={(e) => setManualResetPasswordInput(e.target.value)}
                           placeholder="Masukkan password baru..."
                           className="flex-1 border border-gray-300 rounded-lg p-2.5 text-sm font-mono focus:border-indigo-500 outline-none"
                        />
                        <button
                           type="button"
                           onClick={handleGenerateRandomPass}
                           className="px-3 py-2 bg-gray-100 hover:bg-gray-200 border border-gray-300 rounded-lg text-xs font-medium text-gray-700 transition"
                        >
                           Acak
                        </button>
                     </div>
                     <p className="text-[11px] text-gray-500 mt-1">
                        User dapat langsung menggunakan password baru ini untuk login di aplikasi tanpa memerlukan konfirmasi email.
                     </p>
                  </div>
               </div>
               <div className="px-6 py-4 border-t bg-gray-50 flex justify-end gap-2">
                  <button
                     type="button"
                     onClick={() => setSelectedUserForReset(null)}
                     className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-100 transition"
                  >
                     Batal
                  </button>
                  <button
                     type="button"
                     disabled={isSavingManualReset || !manualResetPasswordInput.trim()}
                     onClick={handleExecuteManualPasswordReset}
                     className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg font-semibold transition flex items-center gap-1.5"
                  >
                     {isSavingManualReset ? (
                        <>
                           <Loader2 className="w-4 h-4 animate-spin" />
                           <span>Menyimpan...</span>
                        </>
                     ) : (
                        <>
                           <Shield className="w-4 h-4" />
                           <span>Terapkan Password Baru</span>
                        </>
                     )}
                  </button>
               </div>
            </div>
         </div>
      )}

      {/* Super Admin Modal Tambah Admin Baru */}
      {isAddAdminModalOpen && (
         <div className="fixed inset-0 bg-black/50 z-[150] flex items-center justify-center p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden text-sm">
               <div className="bg-indigo-600 text-white px-5 py-4 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                     <UserPlus className="w-5 h-5 text-indigo-200" />
                     <h3 className="font-bold text-base">Tambah Akun Admin Baru</h3>
                  </div>
                  <button onClick={() => setIsAddAdminModalOpen(false)} className="text-white/80 hover:text-white p-1 rounded-lg">
                     <X className="w-5 h-5" />
                  </button>
               </div>
               <form onSubmit={handleAddNewAdminDirect}>
                  <div className="p-6 space-y-4">
                     <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                           User ID Admin (Singkat / NIK)
                        </label>
                        <input
                           type="text"
                           required
                           value={newAdminUserId}
                           onChange={(e) => setNewAdminUserId(e.target.value)}
                           placeholder="Contoh: hr_admin / bagas / 10293"
                           className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:border-indigo-500 outline-none"
                        />
                     </div>
                     <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                           Email Akun Admin (@gmail.com disarankan atau @mmpackaging.co.id)
                        </label>
                        <input
                           type="email"
                           required
                           value={newAdminEmail}
                           onChange={(e) => setNewAdminEmail(e.target.value)}
                           placeholder="Contoh: nama@gmail.com (disarankan) atau nama@mmpackaging.co.id"
                           className="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:border-indigo-500 outline-none"
                        />
                     </div>
                     <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">
                           Password Awal
                        </label>
                        <input
                           type="text"
                           required
                           value={newAdminPassword}
                           onChange={(e) => setNewAdminPassword(e.target.value)}
                           placeholder="Masukkan password awal..."
                           className="w-full border border-gray-300 rounded-lg p-2.5 text-sm font-mono focus:border-indigo-500 outline-none"
                        />
                     </div>
                  </div>
                  <div className="px-6 py-4 border-t bg-gray-50 flex justify-end gap-2">
                     <button
                        type="button"
                        onClick={() => setIsAddAdminModalOpen(false)}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-100 transition"
                     >
                        Batal
                     </button>
                     <button
                        type="submit"
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition flex items-center gap-1.5"
                     >
                        <UserPlus className="w-4 h-4" />
                        <span>Daftarkan Admin</span>
                     </button>
                  </div>
               </form>
            </div>
         </div>
      )}
    </div>
  );
}