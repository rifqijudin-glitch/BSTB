import { LogoMMP } from '../components/LogoMMP';
import React, { useState } from 'react';
import { FormStep1 } from '../components/FormStep1';
import { FormStep2 } from '../components/FormStep2';
import { FormStep3 } from '../components/FormStep3';
import { FormStep4 } from '../components/FormStep4';
import { FormStep5 } from '../components/FormStep5';
import { FormStep6 } from '../components/FormStep6';
import { ChevronRight, ChevronLeft, Check, CheckCircle2, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { db, storage } from '../lib/firebase';
import { collection, addDoc } from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';

export function FormPage() {
  React.useEffect(() => {
    document.title = "Form Data Pelamar - PT. Mitra Multi Packaging";
  }, []);
  const formRef = React.useRef<HTMLDivElement>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [showThankYou, setShowThankYou] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedPayload, setSubmittedPayload] = useState<Record<string, any> | null>(null);
  const [formData, setFormData] = useState({
    pekerjaan_dilamar: '',
    nama_lengkap: '',
    pendidikan_terakhir: '',
    no_hp: '',
    gender: ''
  });

  const totalSteps = 6;

  const steps = [
    { id: 1, title: 'Data Diri' },
    { id: 2, title: 'Pendidikan & Keahlian' },
    { id: 3, title: 'Riwayat Pekerjaan' },
    { id: 4, title: 'Tugas & Struktur' },
    { id: 5, title: 'Kuesioner' },
    { id: 6, title: 'Upload Dokumen' },
  ];

  const handleNext = () => {
    let isValid = true;
    let firstInvalid: HTMLElement | null = null;
    
    const formElement = formRef.current;
    if (formElement) {
       const stepContainer = formElement.querySelector(`div.block`);
       if (stepContainer) {
          const inputs = stepContainer.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>('input:not([type="hidden"]), select, textarea');
          
          const radioGroups = new Set<string>();
          
          inputs.forEach((input) => {
             // Set everything as required to enforce all fields
             let isFieldRequired = true;
             if (input.name === 'house_other') {
                const houseRadio = stepContainer.querySelector('input[name="house"]:checked') as HTMLInputElement;
                if (houseRadio?.value !== 'Lain-lain') isFieldRequired = false;
             } else if (input.name === 'vehicle_other') {
                const vehicleRadio = stepContainer.querySelector('input[name="vehicle"]:checked') as HTMLInputElement;
                if (vehicleRadio?.value !== 'Lain-lain') isFieldRequired = false;
             } else if (input.name?.startsWith('sim_')) {
                isFieldRequired = false;
             } else if (input.name === 'no_hp_luar_kota' || input.name === 'alamat_luar_kota') {
                isFieldRequired = false;
             } else if (input.name?.startsWith('q_expl_')) {
                isFieldRequired = false;
             } else if (input.name === 'struktur_organisasi_teks') {
                const methodRadio = stepContainer.querySelector('input[name="struktur_method"]:checked') as HTMLInputElement;
                if (methodRadio?.value !== 'tulis') isFieldRequired = false;
             } else if (input.name === 'hardskill_lainnya') {
                isFieldRequired = false;
             } else if (input.name === 'jurusan_sd_smp') {
                isFieldRequired = false;
             }
             if (input.hasAttribute('disabled')) isFieldRequired = false;
             if (input.type !== 'checkbox' && input.type !== 'file') {
                 input.required = isFieldRequired;
             }
             
             // Check custom validity for length
             if (input.name === 'ktp' || input.name === 'npwp') {
                if (input.value.length > 0 && input.value.length < 16) {
                   input.setCustomValidity('Harus 16 digit');
                } else {
                   input.setCustomValidity('');
                }
             } else if (input.name === 'no_hp' || input.name === 'no_hp_luar_kota' || input.name.startsWith('telp')) {
                if (input.value.length > 0 && input.value.length < 10) {
                   input.setCustomValidity('Nomor HP tidak valid (minimal 10 digit)');
                } else {
                   input.setCustomValidity('');
                }
             } else if (input.name?.startsWith('sim_')) {
                if (input.value.length > 0 && input.value.length < 10) {
                   input.setCustomValidity('No SIM minimal 10 digit');
                } else {
                   input.setCustomValidity('');
                }
             }

             if (!input.checkValidity()) {
                 isValid = false;
                 if (!firstInvalid) firstInvalid = input;
             }
             
             if (input.type === 'radio') {
                 if (input.name) radioGroups.add(input.name);
             }
          });

          radioGroups.forEach(name => {
              const radios = stepContainer.querySelectorAll<HTMLInputElement>(`input[type="radio"][name="${name}"]`);
              if (radios.length > 0) {
                  const isChecked = Array.from(radios).some((r: HTMLInputElement) => r.checked);
                  if (!isChecked) {
                      isValid = false;
                      if (!firstInvalid) firstInvalid = radios[0];
                      radios[0].required = true;
                  }
              }
          });
       }
    }

    if (!isValid) {
      if (firstInvalid) {
         firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
         firstInvalid.focus();
         if ('reportValidity' in firstInvalid) {
            (firstInvalid as HTMLInputElement).reportValidity();
         }
      }
      return;
    }

    if (currentStep < totalSteps) {
      setCurrentStep(curr => curr + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(curr => curr - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleFormChange = (e: any) => {
    const target = e.target as HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;
    if (target.name) {
      setFormData(prev => ({ ...prev, [target.name]: target.value }));
    }
  };

  const handleSubmit = async () => {
    let isValid = true;
    let firstInvalid: HTMLElement | null = null;
    const formElement = formRef.current;
    if (formElement) {
       const stepContainer = formElement.querySelector(`div.block`);
       if (stepContainer) {
          const inputs = stepContainer.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>('input:not([type="hidden"]), select, textarea');
          
          const radioGroups = new Set<string>();
          
          inputs.forEach((input) => {
             // Set everything as required to enforce all fields
             let isFieldRequired = true;
             if (input.name === 'house_other') {
                const houseRadio = stepContainer.querySelector('input[name="house"]:checked') as HTMLInputElement;
                if (houseRadio?.value !== 'Lain-lain') isFieldRequired = false;
             } else if (input.name === 'vehicle_other') {
                const vehicleRadio = stepContainer.querySelector('input[name="vehicle"]:checked') as HTMLInputElement;
                if (vehicleRadio?.value !== 'Lain-lain') isFieldRequired = false;
             } else if (input.name?.startsWith('sim_')) {
                isFieldRequired = false;
             } else if (input.name === 'no_hp_luar_kota' || input.name === 'alamat_luar_kota') {
                isFieldRequired = false;
             } else if (input.name?.startsWith('q_expl_')) {
                isFieldRequired = false;
             } else if (input.name === 'struktur_organisasi_teks') {
                const methodRadio = stepContainer.querySelector('input[name="struktur_method"]:checked') as HTMLInputElement;
                if (methodRadio?.value !== 'tulis') isFieldRequired = false;
             } else if (input.name === 'hardskill_lainnya') {
                isFieldRequired = false;
             } else if (input.name === 'jurusan_sd_smp') {
                isFieldRequired = false;
             }
             if (input.hasAttribute('disabled')) isFieldRequired = false;
             if (input.type !== 'checkbox' && input.type !== 'file') {
                 input.required = isFieldRequired;
             }
             
             // Check custom validity for length
             if (input.name === 'ktp' || input.name === 'npwp') {
                if (input.value.length > 0 && input.value.length < 16) {
                   input.setCustomValidity('Harus 16 digit');
                } else {
                   input.setCustomValidity('');
                }
             } else if (input.name === 'no_hp' || input.name === 'no_hp_luar_kota' || input.name.startsWith('telp')) {
                if (input.value.length > 0 && input.value.length < 10) {
                   input.setCustomValidity('Nomor HP tidak valid (minimal 10 digit)');
                } else {
                   input.setCustomValidity('');
                }
             } else if (input.name?.startsWith('sim_')) {
                if (input.value.length > 0 && input.value.length < 10) {
                   input.setCustomValidity('No SIM minimal 10 digit');
                } else {
                   input.setCustomValidity('');
                }
             }

             if (!input.checkValidity()) {
                 isValid = false;
                 if (!firstInvalid) firstInvalid = input;
             }
             
             if (input.type === 'radio') {
                 if (input.name) radioGroups.add(input.name);
             }
          });

          radioGroups.forEach(name => {
              const radios = stepContainer.querySelectorAll<HTMLInputElement>(`input[type="radio"][name="${name}"]`);
              if (radios.length > 0) {
                  const isChecked = Array.from(radios).some((r: HTMLInputElement) => r.checked);
                  if (!isChecked) {
                      isValid = false;
                      if (!firstInvalid) firstInvalid = radios[0];
                      radios[0].required = true;
                  }
              }
          });
       }
    }
    if (!isValid) {
      if (firstInvalid) {
         firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
         firstInvalid.focus();
         if ('reportValidity' in firstInvalid) {
            (firstInvalid as HTMLInputElement).reportValidity();
         }
      }
      return;
    }

    setIsSubmitting(true);
    try {
        
        // Grab all inputs
        const inputs = formRef.current?.querySelectorAll('input, textarea, select');
        const rawData: Record<string, string> = {};
        
        inputs?.forEach((element) => {
           const el = element as any;
           if (!el.name) {
              // Try to generate a meaningful key for inputs without name (like SIM A, B, C)
              if (el.placeholder === 'A' || el.placeholder === 'B' || el.placeholder === 'C') {
                  const val = el.value.trim();
                  if (val) rawData[`SIM_${el.placeholder}`] = val;
              } else {
                  return;
              }
           } else {
              if (el.type === 'radio' && !(el as HTMLInputElement).checked) {
                 return;
              }
              if (el.type === 'checkbox' && !(el as HTMLInputElement).checked) {
                 return;
              }
              // For multiple values with same name (or tables without precise names), 
              // we append if same name exists. But radio buttons overwrite.
              if (el.type !== 'radio' && rawData[el.name]) {
                  rawData[el.name] += `, ${el.value}`;
              } else {
                  rawData[el.name] = el.value || "-";
              }
           }
        });
        
        // Custom field collections based on classes/index 
        // Example: SIM A, B, C handling manually
        
        const serializeTable = (className: string) => {
           const table = formRef.current?.querySelector(`.${className}`);
           if (!table) return "-";
           
           let headers: string[] = [];
           if (className === 'table-keluarga') {
              headers = ['Hubungan Keluarga', 'Nama', 'L/P', 'Usia', 'Pendidikan Terakhir', 'Jabatan Terakhir', 'Perusahaan Terakhir', 'Keterangan'];
           } else if (className === 'table-pendidikan') {
              headers = ['Tingkat', 'Nama Sekolah', 'Tempat/Kota', 'Jurusan', 'Dari Tahun', 'Sampai Tahun', 'Lulus / Tidak'];
           } else if (className === 'table-kursus') {
              headers = ['Bidang Jenis', 'Penyelenggara', 'Tempat/Kota', 'Lama Kursus', 'Tahun', 'Dibiayai Oleh'];
           } else if (className === 'table-bahasa') {
              headers = ['Jenis Bahasa', 'Mendengar', 'Membaca', 'Berbicara', 'Menulis'];
           } else if (className === 'table-kegiatan') {
              headers = ['Organisasi', 'Jenis Kegiatan', 'Jabatan', 'Tahun'];
           } else if (className === 'table-referensi') {
              headers = ['Nama', 'Alamat', 'No. Telepon', 'Pekerjaan', 'Hubungan'];
           } else if (className === 'table-kontak') {
              headers = ['Nama', 'Alamat', 'Telepon', 'Hubungan'];
           } else if (className === 'table-membaca') {
              headers = ['Jenis Bacaan', 'Media', 'Pokok / Judul Yang Dibaca', 'Frekuensi Membaca'];
           } else {
              headers = Array.from(table.querySelectorAll('thead th')).map(th => th.textContent?.trim() || "").filter(th => th && th !== "");
           }
           
           const rows = Array.from(table.querySelectorAll('tbody tr')) as HTMLElement[];
           
           const rowsData = rows.map((tr: HTMLElement) => {
               const cols = Array.from(tr.querySelectorAll('td'));
               let hasAnyInputFilled = false;
               const rowValues = cols.map((td) => {
                  const tdInputs = Array.from(td.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
                  if (tdInputs.length > 0) {
                     const activeInputs = tdInputs.filter(i => (i.type === 'radio' || i.type === 'checkbox') ? i.checked : true);
                     const vals = activeInputs.map(i => i.value.trim()).filter(v => v !== '');
                     if (vals.length > 0) {
                         hasAnyInputFilled = true;
                         return vals.join(', ');
                     }
                     return ""; // Either unchecked radio or empty text
                  }
                  return td.textContent?.trim() || "";
               });
               
               const rowHasInputs = tr.querySelectorAll('input, select, textarea').length > 0;
               if (rowHasInputs && !hasAnyInputFilled) {
                   return "";
               }
               
               return rowValues.join(' | ');
            }).filter(rowStr => rowStr.trim() !== "");
           
           if (rowsData.length === 0) return "-";
           
           if (headers.length > 0) {
                return headers.join(' | ') + '\n' + rowsData.join('\n');


           }
           return rowsData.join('\n');
        };
        
        const serializeCustomList = (className: string) => {
           const container = formRef.current?.querySelector(`.${className}`);
           if(!container) return "-";
           
           let headers: string[] = [];
           if (className === 'list-pekerjaan') {
              headers = ['Dari', 'Sampai', 'Perusahaan/Telp', 'Jabatan', 'Jenis Usaha', 'Jumlah Karyawan', 'Atasan', 'Direktur', 'Status Pekerjaan', 'Alasan Berhenti'];
           }

           const items = Array.from(container.children) as HTMLElement[];
           const rowsData = items.map((item: HTMLElement) => {
              if (item.tagName === 'BUTTON') return null; // skip add buttons
              const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];

              if (className === 'list-pekerjaan' && inputs.length >= 10) {
                 let dari = (inputs[0].value.trim() || inputs[1].value.trim()) ? `${inputs[0].value.trim()}/${inputs[1].value.trim()}` : '';
                  let status = inputs[10].checked ? 'Masih Bekerja' : (inputs[11]?.checked ? 'Berhenti' : '');
                  let sampai = status === 'Masih Bekerja' ? '-' : ((inputs[2].value.trim() || inputs[3].value.trim()) ? `${inputs[2].value.trim()}/${inputs[3].value.trim()}` : '');
                  let perusahaan = inputs[4].value.trim();
                  let jabatan = inputs[5].value.trim();
                  let jenisUsaha = inputs[6].value.trim();
                  let jmlKar = inputs[7].value.trim();
                  let atasan = inputs[8].value.trim();
                  let direktur = inputs[9].value.trim();
                  let alasan = inputs[12] ? inputs[12].value.trim() : '-';
                 
                 return [dari, sampai, perusahaan, jabatan, jenisUsaha, jmlKar, atasan, direktur, status, alasan].join(' | ');
              }

              return inputs.filter(i => (i.type === 'radio' || i.type === 'checkbox') ? i.checked : true)
                           .map(i => {
                              if (i.type === 'radio') {
                                 return i.value === 'masih_bekerja' ? 'Masih Bekerja' : 'Sudah Berhenti';
                              }
                              return i.value.trim();
                           })
                           .filter(v => v).join(' | ');
           }).filter(str => str);
           
           if (rowsData.length === 0) return "-";
           
           if (headers.length > 0) {
              return headers.join(' | ') + '\n' + rowsData.join('\n');
           }
           
           return rowsData.join('\n\n') || "-";
        };

         const serializePendidikan = () => {
            const container = formRef.current?.querySelector('.list-pendidikan');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Tingkat', 'Nama Sekolah', 'Tempat/Kota', 'Jurusan', 'Dari Tahun', 'Sampai Tahun', 'Lulus / Tidak'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const tingkatSpan = item.querySelector('span.font-bold');
               const tingkat = tingkatSpan?.textContent?.trim() || "";
               
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 6) return null;
               
               const namaSekolah = inputs[0].value.trim();
               const tempatKota = inputs[1].value.trim();
               const jurusan = inputs[2].value.trim();
               const dariTahun = inputs[3].value.trim();
               const sampaiTahun = inputs[4].value.trim();
               const lulusTidak = inputs[5].value.trim();
               
               if (!namaSekolah && !tempatKota && (!jurusan || jurusan === '-')) return null;
               
               return [
                  tingkat || "-",
                  namaSekolah || "-",
                  tempatKota || "-",
                  jurusan || "-",
                  dariTahun || "-",
                  sampaiTahun || "-",
                  lulusTidak || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
             return headers.join(' | ') + '\n' + rowsData.join('\n');


         };

         const serializeKeluarga = () => {
            const container = formRef.current?.querySelector('.list-keluarga');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Hubungan Keluarga', 'Nama', 'L/P', 'Usia', 'Pendidikan Terakhir', 'Jabatan Terakhir', 'Perusahaan Terakhir'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 7) return null;
               
               const hubungan = inputs[0].value.trim();
               const nama = inputs[1].value.trim();
               const lp = inputs[2].value.trim();
               const usia = inputs[3].value.trim();
               const pendidikan = inputs[4].value.trim();
               const jabatan = inputs[5].value.trim();
               const perusahaan = inputs[6].value.trim();
               
               if (!nama && !hubungan) return null;
               
               return [
                  hubungan || "-",
                  nama || "-",
                  lp || "-",
                  usia || "-",
                  pendidikan || "-",
                  jabatan || "-",
                  perusahaan || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeKursus = () => {
            const container = formRef.current?.querySelector('.list-kursus');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Bidang Jenis', 'Penyelenggara', 'Tempat/Kota', 'Lama Kursus', 'Tahun', 'Dibiayai Oleh'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 6) return null;
               
               const bidang = inputs[0].value.trim();
               const penyelenggara = inputs[1].value.trim();
               const tempat = inputs[2].value.trim();
               const lama = inputs[3].value.trim();
               const tahun = inputs[4].value.trim();
               const dibiayai = inputs[5].value.trim();
               
               if (!bidang && !penyelenggara) return null;
               
               return [
                  bidang || "-",
                  penyelenggara || "-",
                  tempat || "-",
                  lama || "-",
                  tahun || "-",
                  dibiayai || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeBahasa = () => {
            const container = formRef.current?.querySelector('.list-bahasa');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Jenis Bahasa', 'Mendengar', 'Membaca', 'Berbicara', 'Menulis'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 5) return null;
               
               const jenis = inputs[0].value.trim();
               const mendengar = inputs[1].value.trim();
               const membaca = inputs[2].value.trim();
               const berbicara = inputs[3].value.trim();
               const menulis = inputs[4].value.trim();
               
               if (!jenis) return null;
               
               return [
                  jenis || "-",
                  mendengar || "-",
                  membaca || "-",
                  berbicara || "-",
                  menulis || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeKegiatan = () => {
            const container = formRef.current?.querySelector('.list-kegiatan');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Organisasi', 'Jenis Kegiatan', 'Jabatan', 'Tahun'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 4) return null;
               
               const organisasi = inputs[0].value.trim();
               const jenis = inputs[1].value.trim();
               const jabatan = inputs[2].value.trim();
               const tahun = inputs[3].value.trim();
               
               if (!organisasi && !jenis) return null;
               
               return [
                  organisasi || "-",
                  jenis || "-",
                  jabatan || "-",
                  tahun || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeMembaca = () => {
            const container = formRef.current?.querySelector('.list-membaca');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Jenis Bacaan', 'Media', 'Pokok / Judul Yang Dibaca', 'Frekuensi Membaca'];
            
            const rowsData = items.map((item: HTMLElement, index: number) => {
               const jenisBacaan = index === 0 ? "Buku" : "Majalah";
               const mediaSelect = item.querySelector('select') as HTMLSelectElement;
               const judulInput = item.querySelector('input[type="text"]') as HTMLInputElement;
               const checkedRadio = item.querySelector('input[type="radio"]:checked') as HTMLInputElement;
               
               const media = mediaSelect?.value.trim() || "";
               const judul = judulInput?.value.trim() || "";
               const frekuensi = checkedRadio?.value.trim() || "";
               
               if (!media && !judul && !frekuensi) return null;
               
               return [
                  jenisBacaan,
                  media || "-",
                  judul || "-",
                  frekuensi || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeReferensi = () => {
            const container = formRef.current?.querySelector('.list-referensi');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Nama', 'Alamat', 'No. Telepon', 'Pekerjaan', 'Hubungan'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 5) return null;
               
               const nama = inputs[0].value.trim();
               const alamat = inputs[1].value.trim();
               const telepon = inputs[2].value.trim();
               const pekerjaan = inputs[3].value.trim();
               const hubungan = inputs[4].value.trim();
               
               if (!nama && !alamat) return null;
               
               return [
                  nama || "-",
                  alamat || "-",
                  telepon || "-",
                  pekerjaan || "-",
                  hubungan || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeKontak = () => {
            const container = formRef.current?.querySelector('.list-kontak');
            if (!container) return "-";
            
            const items = Array.from(container.children) as HTMLElement[];
            const headers = ['Nama', 'Alamat', 'Telepon', 'Hubungan'];
            
            const rowsData = items.map((item: HTMLElement) => {
               const inputs = Array.from(item.querySelectorAll('input, select, textarea')) as HTMLInputElement[];
               if (inputs.length < 4) return null;
               
               const nama = inputs[0].value.trim();
               const alamat = inputs[1].value.trim();
               const telepon = inputs[2].value.trim();
               const hubungan = inputs[3].value.trim();
               
               if (!nama && !alamat) return null;
               
               return [
                  nama || "-",
                  alamat || "-",
                  telepon || "-",
                  hubungan || "-"
               ].join(' | ');
            }).filter(Boolean);
            
            if (rowsData.length === 0) return "-";
            return headers.join(' | ') + '\n' + rowsData.join('\n');
         };

         const serializeKuesionerTable = () => {
           let rows = [];
           const questionsList = [
              "Apakah anda bersedia menjalani masa percobaan 3 bulan ?",
              "Apakah anda bersedia memberikan waktu selambat-lambatnya 2 bulan bagi perusahaan jika anda mengundurkan diri ?",
              "Apakah anda terikat kontrak dengan perusahaan tempat anda bekerja saat ini ?",
              "Apakah anda bersedia dimutasikan ?",
              "Apakah anda memiliki pekerjaan sampingan?",
              "Apakah anda mempunyai teman/sanak saudara di perusahaan ini?",
              "Apakah anda pernah menderita sakit kronis/kecelakaan ?",
              "Apakah anda sedang hamil ?",
              "Apakah anda bersedia tidak hamil dalam 1 tahun?",
              "Bersedia ditempatkan diluar kota ?"
           ];
           for (let i = 0; i < 10; i++) {
              if (rawData[`q_${i}`]) {
                 rows.push(`${questionsList[i]} | ${rawData[`q_${i}`]} | ${rawData[`q_expl_${i}`] || '-'}`);
              }
           }
           if (rows.length === 0) return "-";
           return "Pertanyaan | Ya/Tidak | Penjelasan Tambahan\n" + rows.join('\n');
        };

        const uploadToGAS = async (base64Str: string, fileName: string, mimeType: string) => {
            if (!base64Str || base64Str === '-') return '-';
            
            let cleanBase64 = base64Str;
            if (base64Str.includes('base64,')) {
               cleanBase64 = base64Str.split('base64,')[1];
            } else if (base64Str.startsWith('data:')) {
               const commaIndex = base64Str.indexOf(',');
               if (commaIndex !== -1) {
                   cleanBase64 = base64Str.substring(commaIndex + 1);
               }
            }

            try {
               const gasUrl = "https://script.google.com/macros/s/AKfycbx-Zma41RcWXGBWiYNFtQZvE45XSKIIPGrmH925-SKU_ivlEXAJGXDxCdPkGyjWXW-h/exec";
               const res = await fetch(gasUrl, {
                   method: 'POST',
                   headers: {
                      'Content-Type': 'text/plain;charset=utf-8'
                   },
                   body: JSON.stringify({
                       fileName: fileName,
                       fileData: cleanBase64,
                       mimeType: mimeType
                   })
               });
               const data = await res.json();
               return data.fileUrl || data.url || '-';
            } catch (err) {
               console.error('Error uploading file to GAS', err);
               // Jika fetch gagal (misal karena CORS atau file kegedean), kembalikan raw data saja untuk fallback
               return base64Str;
            }
        };

        const rawFotoData = (document.getElementById('base64_foto_data') as HTMLInputElement)?.value;
        if (!rawFotoData) {
            alert("Pas Foto Pelamar belum diunggah. Mohon unggah Pas Foto Pelamar (3x4 / Bebas Rapi) terlebih dahulu pada menu Upload Dokumen.");
            setIsSubmitting(false);
            return;
        }

        const rawCvData = (document.getElementById('base64_cv_data') as HTMLInputElement)?.value;
        if (!rawCvData) {
            alert("CV belum diunggah atau masih dalam proses pembacaan sistem. Mohon unggah ulang CV Anda dan pastikan ukuran/formatnya sesuai, kemudian klik Submit.");
            setIsSubmitting(false);
            return;
        }

        let signatureBase64 = sessionStorage.getItem('pelamar_signature') || '';
        if (!signatureBase64 || signatureBase64.length < 50) {
            const sigInputs = document.querySelectorAll<HTMLInputElement>('#base64_signature_data');
            sigInputs.forEach(inp => {
                if (inp.value && inp.value.length > 50) {
                    signatureBase64 = inp.value;
                }
            });
        }
        if (!signatureBase64 || signatureBase64 === '-' || signatureBase64.length < 50) {
            alert("Tanda tangan belum diisi. Mohon buat tanda tangan Anda terlebih dahulu pada area Tanda Tangan di menu Kuesioner.");
            setIsSubmitting(false);
            return;
        }

        const fotoFileName = (document.getElementById('foto_file_name') as HTMLInputElement)?.value || `Foto_${rawData["nama_lengkap"] || 'Pelamar'}.jpg`;
        const fotoMimeType = (document.getElementById('foto_mime_type') as HTMLInputElement)?.value || 'image/jpeg';

        const cvFileName = (document.getElementById('cv_file_name') as HTMLInputElement)?.value || `CV_${rawData["nama_lengkap"] || 'Pelamar'}.pdf`;
        const cvMimeType = (document.getElementById('cv_mime_type') as HTMLInputElement)?.value || 'application/pdf';
        
        const timestamp = new Date().toLocaleString();
        
        const fotoUrl = await uploadToGAS(rawFotoData, fotoFileName, fotoMimeType);
        const cvUrl = await uploadToGAS(rawCvData, cvFileName, cvMimeType);
        const ttdUrl = await uploadToGAS(signatureBase64, `tanda_tangan.png`, 'image/png');

        const payload = {
          "Timestamp (Waktu Submit)": timestamp,
          "Foto Pelamar (URL)": fotoUrl,
          "foto_pelamar": fotoUrl,
          "Posisi / Pekerjaan Dilamar": rawData["pekerjaan_dilamar"] || "-",
          "Nama Lengkap": rawData["nama_lengkap"] || "-",
          "Alamat Sesuai KTP": rawData["alamat_dalam_kota"] || "-",
          "No. Hp/Telp": rawData["no_hp"] || "-",
          "Alamat Domisili": rawData["alamat_luar_kota"] || "-",
          "No. Hp/Telp Domisil": rawData["no_hp_luar_kota"] || "-",
          "Gender": rawData["gender"] || "-",
          "Tinggi Badan (cm)": rawData["tinggi_badan"] || "-",
          "Berat Badan (kg)": rawData["berat_badan"] || "-",
          "Agama": rawData["agama"] || "-",
          "Kebangsaan": rawData["kebangsaan"] || "-",
          "Tempat Lahir": rawData["tempat_lahir"] || "-",
          "Tanggal Lahir": rawData["tanggal_lahir"] || "-",
          "Status Perkawinan": rawData["marital"] || "-",
          "No KTP": rawData["ktp"] || "-",
          "No NPWP": rawData["npwp"] || "-",
          "No SIM A": rawData["sim_a"] || "-",
          "No SIM B": rawData["sim_b"] || "-",
          "No SIM C": rawData["sim_c"] || "-",
          "Status Tempat Tinggal (Pribadi/Sewa/dll)": rawData["house"] === 'Lain-lain' ? `Lain-lain: ${rawData["house_other"]}` : (rawData["house"] || "-"),
          "Kendaraan (Jenis/Merk/Tahun)": rawData["kendaraan_jenis"] || "-",
          "Status Kepemilikan Kendaraan (Pribadi/Orang Tua/dll)": rawData["vehicle"] === 'Lain-lain' ? `Lain-lain: ${rawData["vehicle_other"]}` : (rawData["vehicle"] || "-"),
          "Data Susunan Keluarga": serializeKeluarga(),
          "Tingkat Pendidikan Terakhir": rawData["pendidikan_terakhir"] || "-",
          "Riwayat Pendidikan Formal": serializePendidikan(),
          "Riwayat Kursus / Pelatihan": serializeKursus(),
          "Kemampuan Bahasa Asing": serializeBahasa(),
          "Teknikal / Hardskill": [rawData["hardskill"], rawData["hardskill_lainnya"]].filter(Boolean).join(", ") || "-",
          "Kegiatan Sosial / Olahraga / Hobi": serializeKegiatan(),
          "Hobi dan Minat": rawData["hobby"] || "-",
          "Frekuensi Membaca Buku / Majalah": serializeMembaca(),
          "Riwayat Pekerjaan Sebelumnya": serializeCustomList('list-pekerjaan'),
          "Uraian Tugas & Tanggung Jawab Sebelumnya": rawData["uraian_tugas"] || "-",
          "Gambaran Struktur Organisasi Sebelumnya": rawData["struktur_method"] === 'tulis' ? (rawData["struktur_organisasi_teks"] || "-") : "File terlampir (Visual / Dikosongkan)",
          "Referensi (Kepada siapa kami dapat menanyakan mengenai diri anda lebih lengkap)": serializeReferensi(),
          "Kontak Darurat": serializeKontak(),
          "Kuesioner - Bersedia masa percobaan 3 bulan": rawData["q_0"] ? (rawData["q_0"] + (rawData["q_expl_0"] ? ` - ${rawData["q_expl_0"]}` : "")) : "-",
          "Kuesioner - Bersedia memberikan waktu 2 bulan bila mengundurkan diri": rawData["q_1"] ? (rawData["q_1"] + (rawData["q_expl_1"] ? ` - ${rawData["q_expl_1"]}` : "")) : "-",
          "Kuesioner - Terikat kontrak dengan perusahaan saat ini": rawData["q_2"] ? (rawData["q_2"] + (rawData["q_expl_2"] ? ` - ${rawData["q_expl_2"]}` : "")) : "-",
          "Kuesioner - Bersedia dimutasikan": rawData["q_3"] ? (rawData["q_3"] + (rawData["q_expl_3"] ? ` - ${rawData["q_expl_3"]}` : "")) : "-",
          "Kuesioner - Memiliki pekerjaan sampingan": rawData["q_4"] ? (rawData["q_4"] + (rawData["q_expl_4"] ? ` - ${rawData["q_expl_4"]}` : "")) : "-",
          "Kuesioner - Mempunyai teman/sanak saudara di perusahaan ini": rawData["q_5"] ? (rawData["q_5"] + (rawData["q_expl_5"] ? ` - ${rawData["q_expl_5"]}` : "")) : "-",
          "Kuesioner - Pernah menderita sakit kronis / kecelakaan": rawData["q_6"] ? (rawData["q_6"] + (rawData["q_expl_6"] ? ` - ${rawData["q_expl_6"]}` : "")) : "-",
          "Kuesioner - Sedang hamil": rawData["q_7"] ? (rawData["q_7"] + (rawData["q_expl_7"] ? ` - ${rawData["q_expl_7"]}` : "")) : "-",
          "Kuesioner - Bersedia tidak hamil dalam 1 tahun": rawData["q_8"] ? (rawData["q_8"] + (rawData["q_expl_8"] ? ` - ${rawData["q_expl_8"]}` : "")) : "-",
          "Kuesioner - Bersedia ditempatkan di luar kota": rawData["q_9"] ? (rawData["q_9"] + (rawData["q_expl_9"] ? ` - ${rawData["q_expl_9"]}` : "")) : "-",

          "Sumber Informasi Lowongan": rawData["info_lowongan"] || "-",
          "Mengapa Anda Ingin Bekerja di Perusahaan Ini": rawData["alasan_kerja"] || "-",
          "Jenis Pekerjaan Sesuai Cita-cita": rawData["cita_cita"] || "-",
          "Jenis Pekerjaan Tidak Disenangi & Alasan": rawData["job_tidak_suka"] || "-",
          "Kapan Mulai Siap Bekerja": rawData["siap_kerja"] || "-",
          "Tempat/Kota Tanda Tangan": rawData["kota_ttd"] || "-",
          "Tanggal Tanda Tangan": rawData["tanggal_ttd"] || "-",
          "Tanda Tangan (URL)": ttdUrl,
          "Tanda Tangan": ttdUrl,
          "tanda_tangan": ttdUrl,
          "CV (URL)": cvUrl
        };
        
        setSubmittedPayload(payload);
        
        await addDoc(collection(db, 'pelamar'), payload);
        sessionStorage.removeItem('pelamar_signature');
        setShowThankYou(true);
    } catch (error) {
        console.error("Error submitting document to Firestore", error);
        alert("Terjadi kesalahan saat menyimpan data. Mohon coba lagi.");
    } finally {
        setIsSubmitting(false);
    }
  };

  const formatReviewValue = (val: string) => {
     if (typeof val !== 'string') return <p className="font-medium text-sm text-gray-900 whitespace-pre-wrap">{val}</p>;
     if (val.includes('\\n') && val.includes('|')) {
        const rows = val.split('\\n').filter(r => r.trim());
        return (
           <div className="overflow-x-auto mt-2">
              <table className="min-w-full border-collapse border border-gray-200 text-sm bg-white">
                 <tbody>
                    {rows.map((row, rIdx) => (
                       <tr key={rIdx} className="border-b border-gray-200 last:border-0 hover:bg-gray-50/50">
                          {row.split('|').map((cell, cIdx) => (
                             <td key={cIdx} className="p-2 border-r border-gray-200 last:border-0">{cell.trim()}</td>
                          ))}
                       </tr>
                    ))}
                 </tbody>
              </table>
           </div>
        );
     }
     
     if (val.includes('Bulan:') && val.includes('Tahun:')) {
        const entries = val.split('\\n\\n').filter(r => r.trim());
        return (
           <div className="space-y-2 mt-2">
              {entries.map((entry, idx) => (
                 <div key={idx} className="bg-white p-3 border border-gray-200 rounded-lg text-sm">
                    {entry.split('\\n').map((line, lIdx) => (
                       <div key={lIdx}>{line.replace(/<[^>]*>?/gm, '')}</div>
                    ))}
                 </div>
              ))}
           </div>
        );
     }
     
     return <p className="font-medium text-sm text-gray-900 whitespace-pre-wrap">{val}</p>;
  };

  
  if (currentStep === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 py-12 px-4 sm:px-6 lg:px-8 font-sans flex items-center justify-center">
        <div className="max-w-2xl w-full bg-white/80 backdrop-blur-sm shadow-2xl rounded-3xl overflow-hidden border border-white/50 p-6 sm:p-12 text-center ring-1 ring-gray-900/5">
           <LogoMMP variant="full" className="block w-48 sm:w-64 h-auto mx-auto mb-6 sm:mb-8 cursor-pointer transform hover:scale-105 transition-transform object-contain" />
           <h1 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-gray-900 to-gray-700 tracking-tight mb-2">Selamat Datang</h1>
           <p className="text-lg sm:text-xl font-semibold text-blue-600 mb-6 sm:mb-8">Form Data Pelamar - PT. Mitra Multi Packaging</p>
           
           <div className="bg-blue-50 text-blue-800 rounded-xl p-6 text-left mb-8 text-sm leading-relaxed border border-blue-100">
               <p className="font-bold mb-3 text-base">Panduan Pengisian:</p>
               <ul className="list-decimal pl-5 space-y-2">
                   <li>Isilah semua data dengan sebenar-benarnya dan sesuai dengan dokumen resmi Anda.</li>
                   <li>Pastikan nomor HP/Telepon dan Email yang Anda masukkan aktif.</li>
                   <li>Beberapa bagian mungkin memerlukan Anda untuk mengunggah dokumen/berkas (opsional tergantung permintaan).</li>
                   <li>Klik tombol <strong>Lanjutkan</strong> atau <strong>Kembali</strong> untuk navigasi antar halaman.</li>
                   <li>Siapkan dokumen <em>Curriculum Vitae</em> (CV) terbaru Anda dalam format PDF untuk diunggah pada tahap akhir pengisian formulir.</li>
                   <li>Pastikan Anda mengecek kembali data sebelum mengklik tombol <strong>Kirim Form Lamaran</strong> di tahap akhir.</li>
               </ul>
           </div>
           
           <button type="button"
              onClick={() => setCurrentStep(1)}
              className="bg-blue-600 text-white font-medium px-8 py-3.5 rounded-xl hover:bg-blue-700 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 mx-auto"
           >
              Mulai Pengisian <ChevronRight className="w-5 h-5" />
           </button>
        </div>
      </div>
    );
  }


  if (showThankYou) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
         <div className="bg-white max-w-md w-full rounded-3xl shadow-2xl p-8 text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-blue-500 to-green-500"></div>
            
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
               <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Terima Kasih!</h2>
            <p className="text-gray-500 mb-8">Data lamaran Anda telah berhasil dikirim ke sistem kami.</p>

            <div className="bg-gray-50 rounded-2xl p-6 text-left mb-8 border border-gray-100">
               <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-4 border-b border-gray-200 pb-2">Ringkasan Data Pelamar</h3>
               
               <div className="space-y-4">
                  {submittedPayload ? (
                      <>
                         <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">Timestamp</p>
                            <p className="font-medium text-gray-900">{submittedPayload["Timestamp (Waktu Submit)"] || '-'}</p>
                         </div>
                         <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">Nama Lengkap</p>
                            <p className="font-medium text-gray-900">{submittedPayload["Nama Lengkap"] || '-'}</p>
                         </div>
                         <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">Pekerjaan Yang Dilamar</p>
                            <p className="font-medium text-gray-900">{submittedPayload["Posisi / Pekerjaan Dilamar"] || '-'}</p>
                         </div>
                         <div>
                            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">No HP / Telp</p>
                            <p className="font-medium text-gray-900">{submittedPayload["No. Hp/Telp"] || '-'}</p>
                         </div>
                      </>
                  ) : (
                     <>
                        <div>
                           <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">Nama Lengkap</p>
                           <p className="font-medium text-gray-900">{formData.nama_lengkap || '-'}</p>
                        </div>
                        <div>
                           <p className="text-xs text-gray-500 font-semibold uppercase tracking-wider">Pekerjaan Yang Dilamar</p>
                           <p className="font-medium text-gray-900">{formData.pekerjaan_dilamar || '-'}</p>
                        </div>
                     </>
                  )}
               </div>
            </div>

            <button type="button"
               onClick={() => {
                   window.close();
                   // Fallback in case window.close() is blocked
                   setTimeout(() => window.location.href = 'about:blank', 500);
               }}
               className="w-full bg-slate-800 text-white font-medium py-3 rounded-xl hover:bg-slate-900 transition-colors shadow-md shadow-slate-200"
            >
               Tutup
            </button>
            <div className="mt-8 text-xs font-semibold text-gray-400 flex items-center justify-center gap-1">
               &copy; Copyright - HCGA PT. Mitra Multi Packaging
            </div>
         </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
           <LogoMMP variant="full" className="block w-40 sm:w-56 h-auto mx-auto mb-6 transform hover:scale-105 transition-transform object-contain" />
           <h1 className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-gray-900 to-gray-700 tracking-tight">Form Data Pelamar</h1>
           <p className="mt-3 text-lg font-medium text-blue-600">PT. Mitra Multi Packaging</p>
        </div>

        {/* Stepper Header */}
        <div className="mb-12">
            <div className="flex items-center justify-between relative">
               <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-gray-200 z-0 rounded-full hidden sm:block"></div>
               <div 
                  className="absolute left-0 top-1/2 transform -translate-y-1/2 h-1 bg-blue-600 z-0 rounded-full hidden sm:block transition-all duration-500 ease-in-out" 
                  style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
               ></div>
               
               {steps.map((step) => (
                  <div key={step.id} className="relative z-10 flex flex-col items-center">
                     <div 
                        className={cn(
                           "w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold border-2 transition-all duration-300",
                           currentStep === step.id 
                              ? "bg-blue-600 border-blue-600 text-white shadow-md ring-4 ring-blue-100" 
                              : currentStep > step.id 
                                 ? "bg-blue-600 border-blue-600 text-white" 
                                 : "bg-white border-gray-300 text-gray-500"
                        )}
                     >
                        {currentStep > step.id ? <Check className="w-5 h-5" /> : <span>{step.id}</span>}
                     </div>
                     <span 
                        className={cn(
                           "mt-3 text-xs md:text-sm font-medium absolute top-10 whitespace-nowrap hidden sm:block",
                           currentStep >= step.id ? "text-blue-600" : "text-gray-500"
                        )}
                     >
                        {step.title}
                     </span>
                  </div>
               ))}
            </div>
        </div>

        {/* Form Card */}
        <div 
           ref={formRef}
           className="bg-white/80 backdrop-blur-sm shadow-2xl rounded-3xl overflow-hidden border border-white/50 mb-8 sm:mt-16 ring-1 ring-gray-900/5"
           onChange={handleFormChange}
        >
          <div className="p-6 sm:p-10">
            <div className={currentStep === 1 ? 'block' : 'hidden'}><FormStep1 /></div>
            <div className={currentStep === 2 ? 'block' : 'hidden'}><FormStep2 /></div>
            <div className={currentStep === 3 ? 'block' : 'hidden'}><FormStep3 /></div>
            <div className={currentStep === 4 ? 'block' : 'hidden'}><FormStep4 /></div>
            <div className={currentStep === 5 ? 'block' : 'hidden'}><FormStep5 /></div>
            <div className={currentStep === 6 ? 'block' : 'hidden'}><FormStep6 /></div>
          </div>
          
          {/* Navigation Footer */}
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
            <button type="button"
              onClick={handlePrev}
              disabled={currentStep === 1}
              className={cn(
                 "flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium transition-all",
                 currentStep === 1 
                    ? "text-gray-400 bg-gray-100 cursor-not-allowed" 
                    : "text-gray-700 bg-white border shadow-sm hover:bg-gray-50"
              )}
            >
              <ChevronLeft className="w-5 h-5" />
              <span>Kembali</span>
            </button>
            
            {currentStep < totalSteps ? (
               <button type="button"
                 onClick={handleNext}
                 className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all shadow-md hover:shadow-lg active:scale-95"
               >
                 <span>Selanjutnya</span>
                 <ChevronRight className="w-5 h-5" />
               </button>
            ) : (
               <button type="button"
                 onClick={handleSubmit}
                 disabled={isSubmitting}
                 className="flex items-center gap-2 px-6 py-2.5 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-all shadow-md hover:shadow-lg active:scale-95 disabled:opacity-50"
               >
                 <Check className="w-5 h-5 md:mr-1" />
                 <span className="hidden md:inline">{isSubmitting ? 'Mengirim...' : 'Submit Form'}</span>
                 <span className="md:hidden">{isSubmitting ? '...' : 'Submit'}</span>
               </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}