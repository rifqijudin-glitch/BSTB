import fs from 'fs';
import path from 'path';

const files = fs.readdirSync('src/components').filter(f => f.startsWith('FormStep'));
files.forEach(f => {
    const text = fs.readFileSync(path.join('src/components', f), 'utf-8');
    const matches = text.match(/name="([^"]+)"/g) || [];
    console.log(f + ':');
    const names = new Set(matches.map(m => m.split('"')[1]));
    console.log(Array.from(names).join(', '));
});
