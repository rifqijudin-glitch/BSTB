import fs from 'fs';

let text = fs.readFileSync('src/pages/FormPage.tsx', 'utf-8');

const oldPayloadStr = `"Macam Pekerjaan Sangat Disenangi & Alasan": rawData["job_sangat_suka"] || "-",
          "Macam Pekerjaan Disenangi & Alasan": rawData["job_suka"] || "-",
          "Macam Pekerjaan Kurang Disenangi & Alasan": rawData["job_kurang_suka"] || "-",
          "Macam Pekerjaan Tidak Disenangi & Alasan": rawData["job_tidak_suka"] || "-",
          "Referensi Kenalan Selain Keluarga": serializeTable('table-referensi'),
          "Kenalan / Saudara di Perusahaan Ini": rawData["q_expl_5"] || "-", // Wait, Q5 was about outside city. Let's just keep literal map
          "Jawaban Kuesioner 1 (Pernah Sakit Keras / Kecelakaan?)": serializeKuesionerTable(),
          "Jawaban Kuesioner 2 (Pernah Berurusan dengan Polisi / Hukum?)": "-",
          "Jawaban Kuesioner 3 (Masih Terikat Dinas / Kontrak di Tempat Lain?)": "-",
          "Jawaban Kuesioner 4 (Pernah Diberhentikan Perusahaan Lain?)": "-",
          "Jawaban Kuesioner 5 (Ada Pekerjaan Sampingan / Part-time?)": "-",
          "Jawaban Kuesioner 6 (Bersedia Ditempatkan Di Luar Kota?)": "-",
          "Jawaban Kuesioner 7 (Pernah Melamar ke Perusahaan ini Sebelumnya?)": "-",
          "Jawaban Kuesioner 8 (Pernah Mengikuti Psikotes Sebelumnya?)": "-",
          "Jawaban Kuesioner 9 (Bila Belum Menikah, Kapan Rencana Menikah?)": "-",
          "Jawaban Kuesioner 10 (Setuju Kami Menghubungi Perusahaan Sebelummya?)": "-",
          "Jawaban Kuesioner 11 (Pernyataan Kebenaran Data)": "-",
          "Gaji yang Diharapkan": rawData["gaji_harapan"] || "-",
          "Fasilitas Uang Makan & Transport yang Diharapkan": rawData["uang_makan_transport"] || "-",
          "Fasilitas Lainnya yang Diharapkan": rawData["fasilitas_lain"] || "-",
          "Kapan Mulai Siap Bekerja": rawData["siap_kerja"] || "-",
          "Sumber Informasi Lowongan": rawData["info_lowongan"] || "-",
          "Tempat/Kota Tanda Tangan": rawData["kota_ttd"] || "-",
          "Tanggal Tanda Tangan": rawData["tanggal_ttd"] || "-"`;

// In FormStep5, the fields are:
// - info_lowongan
// - cita_cita
// - job_tidak_suka
// - siap_kerja
// - kota_ttd
// - tanggal_ttd
// The Kuesioner is an array of size 10 (0-9). Let's put each question in its own column for better sheet structuring, OR just use serializeKuesionerTable under "Jawaban Kuesioner". I'll put it under "Data Kuesioner".
const newPayloadStr = `"Jenis Pekerjaan Sesuai Cita-cita": rawData["cita_cita"] || "-",
          "Macam Pekerjaan Tidak Disenangi & Alasan": rawData["job_tidak_suka"] || "-",
          "Referensi Kenalan Selain Keluarga": serializeTable('table-referensi'),
          "Data Kuesioner": serializeKuesionerTable(),
          "Kapan Mulai Siap Bekerja": rawData["siap_kerja"] || "-",
          "Sumber Informasi Lowongan": rawData["info_lowongan"] || "-",
          "Tempat/Kota Tanda Tangan": rawData["kota_ttd"] || "-",
          "Tanggal Tanda Tangan": rawData["tanggal_ttd"] || "-"`;

if (text.includes(oldPayloadStr)) {
    console.log("Replacing payload...");
    text = text.replace(oldPayloadStr, newPayloadStr);
    fs.writeFileSync('src/pages/FormPage.tsx', text);
} else {
    console.log("Payload string not found!");
}
