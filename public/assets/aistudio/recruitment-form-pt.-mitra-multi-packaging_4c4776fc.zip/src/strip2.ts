import fs from "fs";
let f = fs.readFileSync("src/pages/DashboardPage.tsx", "utf8");

const startIndustry = f.indexOf("{/* Industry */}");
const endIndustry = f.indexOf("{/* Work Experience */}");

if (startIndustry !== -1 && endIndustry !== -1) {
    f = f.slice(0, startIndustry) + f.slice(endIndustry);
}

const startWorkExp = f.indexOf("{/* Work Experience */}");
const endWorkExp = f.indexOf("{/* Education */}");
if (startWorkExp !== -1 && endWorkExp !== -1) {
    f = f.slice(0, startWorkExp) + f.slice(endWorkExp);
}

const startField = f.indexOf("{/* Field Study */}");
const endField = f.indexOf("{/* Skills */}");
if (startField !== -1 && endField !== -1) {
    f = f.slice(0, startField) + f.slice(endField);
}

const startSkills = f.indexOf("{/* Skills */}");
const endSkills = f.indexOf("</div>\n               \n               <div className=\"p-4 border-t");

if (startSkills !== -1 && endSkills !== -1) {
    const rawSkillsList = `                  {/* Skills */}
                  <div>
                     <div className="flex justify-between items-center mb-2">
                        <h4 className="font-bold text-gray-700">Skills</h4>
                        <ChevronDown className="w-4 h-4 text-gray-400" />
                     </div>
                     <div className="space-y-2">
                        {skillList.map(skill => (
                           <label key={skill} className="flex items-center gap-2"><input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" /> <span className="text-gray-600">{skill}</span></label>
                        ))}
                     </div>
                  </div>\n\n               `;
    f = f.slice(0, startSkills) + rawSkillsList + f.slice(endSkills);
}


fs.writeFileSync("src/pages/DashboardPage.tsx", f);
