import fs from "fs";
let f = fs.readFileSync("src/pages/DashboardPage.tsx", "utf8");

// Remove everything from {/* Jurusan */} to {/* Skill */}
const startIdx = f.indexOf("{/* Jurusan */}");
const endIdx = f.indexOf("{/* Skill */}");

if (startIdx !== -1 && endIdx !== -1) {
    f = f.slice(0, startIdx) + f.slice(endIdx);
}

// Remove jurusanList and industriList from the Advanced Filter modal (Wait, let's just do it manually)
fs.writeFileSync("src/pages/DashboardPage.tsx", f);
