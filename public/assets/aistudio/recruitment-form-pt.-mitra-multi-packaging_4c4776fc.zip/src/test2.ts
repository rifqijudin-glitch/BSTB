async function run() {
  const res = await fetch("https://sheetdb.io/api/v1/g6pseexgmqoyq");
  const data = await res.json();
  if (data && data.length > 0) {
    const keys = Object.keys(data[data.length - 1]);
    console.log("All missing kuesioner keys found: ", keys.filter(k => k.includes("Bersedia")));
  }
}
run();
