import fs from "fs";
let f = fs.readFileSync("src/pages/FormPage.tsx", "utf8");
f = f.replace(/\} else if \(input.name === 'hardskill_lainnya'\) \{\n                isFieldRequired = false;\n             \}/g, "} else if (input.name === 'hardskill_lainnya') {\n                isFieldRequired = false;\n             } else if (input.name === 'jurusan_sd_smp') {\n                isFieldRequired = false;\n             }");
fs.writeFileSync("src/pages/FormPage.tsx", f);
