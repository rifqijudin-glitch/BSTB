import React, { useState, useRef, useEffect } from 'react';
import { PlusCircle, Trash2, ChevronDown } from 'lucide-react';

export function FormStep2() {
  const [pendidikanTerakhir, setPendidikanTerakhir] = useState<string>('');
  const [isHardskillOpen, setIsHardskillOpen] = useState(false);
  const [selectedHardskills, setSelectedHardskills] = useState<string[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsHardskillOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleHardskill = (skill: string) => {
    if (selectedHardskills.includes(skill)) {
      setSelectedHardskills(selectedHardskills.filter(item => item !== skill));
    } else {
      setSelectedHardskills([...selectedHardskills, skill]);
    }
  };

  
  const [kursuses, setKursuses] = useState([
    { id: 1 }
  ]);

  const [bahasas, setBahasas] = useState([
    { id: 1 }
  ]);

  const [kegiatans, setKegiatans] = useState([
    { id: 1 }
  ]);

  const addKursus = () => setKursuses([...kursuses, { id: Date.now() }]);
  const removeKursus = (id: number) => setKursuses(kursuses.filter(k => k.id !== id));

  const addBahasa = () => setBahasas([...bahasas, { id: Date.now() }]);
  const removeBahasa = (id: number) => setBahasas(bahasas.filter(b => b.id !== id));

  const addKegiatan = () => setKegiatans([...kegiatans, { id: Date.now() }]);
  const removeKegiatan = (id: number) => setKegiatans(kegiatans.filter(k => k.id !== id));

  return (
    <div className="space-y-8">
      <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100">
        <label className="block text-sm font-medium text-gray-700 mb-1">Pendidikan Terakhir <span className="text-red-500">*</span></label>
        <select name="pendidikan_terakhir" value={pendidikanTerakhir} onChange={(e) => setPendidikanTerakhir(e.target.value)} className="w-full border-gray-300 bg-white rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border outline-none" required>
           <option value="">-- Pilih Pendidikan Terakhir --</option>
           <option value="SD/Sederajat">SD / Sederajat</option>
           <option value="SMP/SLTP">SMP / Sederajat</option>
           <option value="SMA/SMK/SLTA">SMA / SMK / Sederajat</option>
           <option value="D1/D2/D3">Diploma (D1/D2/D3)</option>
           <option value="S1">Sarjana (S1)</option>
           <option value="S2/S3">Pasca Sarjana (S2/S3)</option>
        </select>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Riwayat Pendidikan Formal / Informal</h2>
        <div className="space-y-4 list-pendidikan">
             {(() => {
                 let tingkatList = ['SD', 'SLTP', 'SLTA/SMU/SMK', 'AKDMI/UNIV'];
                 if (pendidikanTerakhir === 'SD/Sederajat') tingkatList = ['SD'];
                 else if (pendidikanTerakhir === 'SMP/SLTP') tingkatList = ['SD', 'SLTP'];
                 else if (pendidikanTerakhir === 'SMA/SMK/SLTA') tingkatList = ['SD', 'SLTP', 'SLTA/SMU/SMK'];
                 else if (pendidikanTerakhir === 'D1/D2/D3') tingkatList = ['SD', 'SLTP', 'SLTA/SMU/SMK', 'D1/D2/D3'];
                 else if (pendidikanTerakhir === 'S1') tingkatList = ['SD', 'SLTP', 'SLTA/SMU/SMK', 'S1'];
                 else if (pendidikanTerakhir === 'S2/S3') tingkatList = ['SD', 'SLTP', 'SLTA/SMU/SMK', 'S1', 'S2/S3'];
                 
                 return tingkatList.map((tingkat) => (
                    <div key={tingkat} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                        <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                           Tingkat: <span className="ml-2 font-bold">{tingkat}</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                           <div className="flex flex-col p-3">
                              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Nama Sekolah</label>
                              <input type="text" className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 border border-gray-200 rounded bg-white" />
                           </div>
                           <div className="flex flex-col p-3">
                              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Tempat/Kota</label>
                              <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 border border-gray-200 rounded bg-white" />
                           </div>
                        </div>
                        <div className="grid grid-cols-1 border-b border-gray-200 p-3">
                           <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Jurusan</label>
                           {tingkat === 'SLTA/SMU/SMK' ? (
                                <><input type="text" list="jurusan_smu_list" className="w-full px-2 py-1.5 outline-none bg-white border border-gray-200 rounded focus:bg-blue-50 text-sm" name="jurusan_smu" placeholder="-- Ketik/Pilih Jurusan --" />
                                <datalist id="jurusan_smu_list">
                                    <option value="MIPA">MIPA</option>
                                    <option value="IPS">IPS</option>
                                    <option value="Ekonomi">Ekonomi</option>
                                    <option value="Bahasa dan Budaya">Bahasa dan Budaya</option>
                                    <option value="Teknik Konstruksi dan Perumahan">Teknik Konstruksi dan Perumahan</option>
                                    <option value="Teknik Geomatika dan Geospasial">Teknik Geomatika dan Geospasial</option>
                                    <option value="Teknik Ketenagalistrikan">Teknik Ketenagalistrikan</option>
                                    <option value="Teknik Mesin">Teknik Mesin</option>
                                    <option value="Teknik Otomotif">Teknik Otomotif</option>
                                    <option value="Teknik Elektronika">Teknik Elektronika</option>
                                    <option value="Teknik Perkapalan">Teknik Perkapalan</option>
                                    <option value="Pengembangan Perangkat Lunak dan Gim (PPLG)">Pengembangan Perangkat Lunak dan Gim (PPLG)</option>
                                    <option value="Teknik Jaringan Komputer dan Telekomunikasi (TJKT)">Teknik Jaringan Komputer dan Telekomunikasi (TJKT)</option>
                                    <option value="Layanan Kesehatan">Layanan Kesehatan</option>
                                    <option value="Farmasi">Farmasi</option>
                                    <option value="Pekerjaan Sosial">Pekerjaan Sosial</option>
                                    <option value="Akuntansi dan Keuangan Lembaga (AKL)">Akuntansi dan Keuangan Lembaga (AKL)</option>
                                    <option value="Manajemen Perkantoran dan Layanan Bisnis (MPLB)">Manajemen Perkantoran dan Layanan Bisnis (MPLB)</option>
                                    <option value="Pemasaran">Pemasaran</option>
                                    <option value="Kuliner">Kuliner</option>
                                    <option value="Perhotelan">Perhotelan</option>
                                    <option value="Usaha Layanan Pariwisata">Usaha Layanan Pariwisata</option>
                                    <option value="Tata Kecantikan dan Rambut">Tata Kecantikan dan Rambut</option>
                                    <option value="Tata Busana">Tata Busana</option>
                                    <option value="Desain Komunikasi Visual (DKV)">Desain Komunikasi Visual (DKV)</option>
                                    <option value="Animasi">Animasi</option>
                                    <option value="Penyiaran dan Produksi Film">Penyiaran dan Produksi Film</option>
                                    <option value="Seni Pertunjukan">Seni Pertunjukan</option>
                                    <option value="Kriya Kreatif">Kriya Kreatif</option>
                                    <option value="Agribisnis Tanaman">Agribisnis Tanaman</option>
                                    <option value="Agribisnis Ternak">Agribisnis Ternak</option>
                                    <option value="Agriteknologi Pengolahan Hasil Pertanian (APHP)">Agriteknologi Pengolahan Hasil Pertanian (APHP)</option>
                                    <option value="Kehutanan">Kehutanan</option>
                                    <option value="Nautika Kapal Penangkap Ikan / Niaga">Nautika Kapal Penangkap Ikan / Niaga</option>
                                    <option value="Teknika Kapal Penangkap Ikan / Niaga">Teknika Kapal Penangkap Ikan / Niaga</option>
                                    <option value="Agribisnis Perikanan">Agribisnis Perikanan</option>
                                    <option value="Teknik Perminyakan">Teknik Perminyakan</option>
                                    <option value="Teknik Pertambangan">Teknik Pertambangan</option>
                                    <option value="Teknik Kimia Industri">Teknik Kimia Industri</option>
                                    <option value="Lainnya">Lainnya</option>
                                </datalist></>
                            ) : (tingkat === 'S1' || tingkat === 'D1/D2/D3') ? (
                                <><input type="text" list="jurusan_s1_list" className="w-full px-2 py-1.5 outline-none bg-white border border-gray-200 rounded focus:bg-blue-50 text-sm" name="jurusan_s1" placeholder="-- Ketik/Pilih Jurusan --" />
                                <datalist id="jurusan_s1_list">
                                    <option value="Pendidikan Dokter">Pendidikan Dokter</option>
                                    <option value="Pendidikan Dokter Gigi">Pendidikan Dokter Gigi</option>
                                    <option value="Kedokteran Hewan">Kedokteran Hewan</option>
                                    <option value="Ilmu Keperawatan">Ilmu Keperawatan</option>
                                    <option value="Kebidanan">Kebidanan</option>
                                    <option value="Farmasi">Farmasi</option>
                                    <option value="Kesehatan Masyarakat">Kesehatan Masyarakat</option>
                                    <option value="Gizi Kesehatan">Gizi Kesehatan</option>
                                    <option value="Fisioterapi">Fisioterapi</option>
                                    <option value="Okupasi Terapi">Okupasi Terapi</option>
                                    <option value="Sains Kedokteran Tropis">Sains Kedokteran Tropis</option>
                                    <option value="Keselamatan dan Kesehatan Kerja">Keselamatan dan Kesehatan Kerja</option>
                                    <option value="Teknik Sipil">Teknik Sipil</option>
                                    <option value="Teknik Arsitektur">Teknik Arsitektur</option>
                                    <option value="Teknik Mesin">Teknik Mesin</option>
                                    <option value="Teknik Elektro">Teknik Elektro</option>
                                    <option value="Teknik Kimia">Teknik Kimia</option>
                                    <option value="Teknik Industri">Teknik Industri</option>
                                    <option value="Teknik Lingkungan">Teknik Lingkungan</option>
                                    <option value="Teknik Perencanaan Wilayah dan Kota">Teknik Perencanaan Wilayah dan Kota</option>
                                    <option value="Teknik Metalurgi dan Material">Teknik Metalurgi dan Material</option>
                                    <option value="Teknik Dirgantara">Teknik Dirgantara</option>
                                    <option value="Teknik Kelautan">Teknik Kelautan</option>
                                    <option value="Teknik Nuklir">Teknik Nuklir</option>
                                    <option value="Teknik Biomedis">Teknik Biomedis</option>
                                    <option value="Teknik Informatika">Teknik Informatika</option>
                                    <option value="Sistem Informasi">Sistem Informasi</option>
                                    <option value="Ilmu Komputer">Ilmu Komputer</option>
                                    <option value="Sains Data">Sains Data</option>
                                    <option value="Keamanan Siber">Keamanan Siber</option>
                                    <option value="Rekayasa Perangkat Lunak">Rekayasa Perangkat Lunak</option>
                                    <option value="Matematika">Matematika</option>
                                    <option value="Fisika">Fisika</option>
                                    <option value="Kimia">Kimia</option>
                                    <option value="Biologi">Biologi</option>
                                    <option value="Astronomi">Astronomi</option>
                                    <option value="Geofisika">Geofisika</option>
                                    <option value="Meteorologi">Meteorologi</option>
                                    <option value="Statistika">Statistika</option>
                                    <option value="Aktuaria">Aktuaria</option>
                                    <option value="Agroteknologi">Agroteknologi</option>
                                    <option value="Agribisnis">Agribisnis</option>
                                    <option value="Ilmu Kelautan">Ilmu Kelautan</option>
                                    <option value="Oseanografi">Oseanografi</option>
                                    <option value="Teknologi Pangan">Teknologi Pangan</option>
                                    <option value="Manajemen Sumberdaya Perairan">Manajemen Sumberdaya Perairan</option>
                                    <option value="Kehutanan">Kehutanan</option>
                                    <option value="Hubungan Internasional">Hubungan Internasional</option>
                                    <option value="Ilmu Komunikasi">Ilmu Komunikasi</option>
                                    <option value="Jurnalistik">Jurnalistik</option>
                                    <option value="Penyiaran">Penyiaran</option>
                                    <option value="Hubungan Masyarakat">Hubungan Masyarakat</option>
                                    <option value="Ilmu Pemerintahan">Ilmu Pemerintahan</option>
                                    <option value="Ilmu Politik">Ilmu Politik</option>
                                    <option value="Sosiologi">Sosiologi</option>
                                    <option value="Antropologi Sosial">Antropologi Sosial</option>
                                    <option value="Ilmu Administrasi Publik">Ilmu Administrasi Publik</option>
                                    <option value="Ilmu Administrasi Bisnis">Ilmu Administrasi Bisnis</option>
                                    <option value="Kriminologi">Kriminologi</option>
                                    <option value="Psikologi">Psikologi</option>
                                    <option value="Akuntansi">Akuntansi</option>
                                    <option value="Manajemen">Manajemen</option>
                                    <option value="Manajemen Keuangan">Manajemen Keuangan</option>
                                    <option value="Manajemen Pemasaran">Manajemen Pemasaran</option>
                                    <option value="Manajemen Sumber Daya Manusia">Manajemen Sumber Daya Manusia</option>
                                    <option value="Ilmu Ekonomi">Ilmu Ekonomi</option>
                                    <option value="Ekonomi Pembangunan">Ekonomi Pembangunan</option>
                                    <option value="Ekonomi Syariah">Ekonomi Syariah</option>
                                    <option value="Perbankan Syariah">Perbankan Syariah</option>
                                    <option value="Ilmu Hukum">Ilmu Hukum</option>
                                    <option value="Hukum Perdata">Hukum Perdata</option>
                                    <option value="Hukum Pidana">Hukum Pidana</option>
                                    <option value="Hukum Internasional">Hukum Internasional</option>
                                    <option value="Hukum Tata Negara">Hukum Tata Negara</option>
                                    <option value="Sastra Inggris">Sastra Inggris</option>
                                    <option value="Sastra Indonesia">Sastra Indonesia</option>
                                    <option value="Sastra Jepang">Sastra Jepang</option>
                                    <option value="Sastra Arab">Sastra Arab</option>
                                    <option value="Sastra Korea">Sastra Korea</option>
                                    <option value="Sastra Mandarin">Sastra Mandarin</option>
                                    <option value="Linguistik">Linguistik</option>
                                    <option value="Ilmu Sejarah">Ilmu Sejarah</option>
                                    <option value="Arkeologi">Arkeologi</option>
                                    <option value="Ilmu Filsafat">Ilmu Filsafat</option>
                                    <option value="Desain Interior">Desain Interior</option>
                                    <option value="Desain Produk">Desain Produk</option>
                                    <option value="Seni Rupa Murni">Seni Rupa Murni</option>
                                    <option value="Fotografi">Fotografi</option>
                                    <option value="Etnomusikologi">Etnomusikologi</option>
                                    <option value="Penciptaan Musik">Penciptaan Musik</option>
                                    <option value="Seni Teater">Seni Teater</option>
                                    <option value="Pendidikan Guru Sekolah Dasar">Pendidikan Guru Sekolah Dasar</option>
                                    <option value="Pendidikan Guru Anak Usia Dini">Pendidikan Guru Anak Usia Dini</option>
                                    <option value="Pendidikan Luar Biasa">Pendidikan Luar Biasa</option>
                                    <option value="Bimbingan dan Konseling">Bimbingan dan Konseling</option>
                                    <option value="Pendidikan Bahasa Indonesia">Pendidikan Bahasa Indonesia</option>
                                    <option value="Pendidikan Bahasa Inggris">Pendidikan Bahasa Inggris</option>
                                    <option value="Pendidikan Matematika">Pendidikan Matematika</option>
                                    <option value="Pendidikan Fisika">Pendidikan Fisika</option>
                                    <option value="Pendidikan Kimia">Pendidikan Kimia</option>
                                    <option value="Pendidikan Biologi">Pendidikan Biologi</option>
                                    <option value="Pendidikan Sejarah">Pendidikan Sejarah</option>
                                    <option value="Pendidikan Geografi">Pendidikan Geografi</option>
                                    <option value="Pendidikan Ekonomi">Pendidikan Ekonomi</option>
                                    <option value="Lainnya">Lainnya</option>
                                </datalist></>
                            ) : tingkat === 'S2/S3' ? (
                                <><input type="text" list="jurusan_s2_list" name="jurusan_s2" className="w-full px-2 py-1.5 outline-none bg-white border border-gray-200 rounded focus:bg-blue-50 text-sm" placeholder="-- Ketik/Pilih Program Studi --" />
                                <datalist id="jurusan_s2_list">
                                    <option value="Magister Manajemen">Magister Manajemen</option>
                                    <option value="Magister Hukum">Magister Hukum</option>
                                    <option value="Magister Ilmu Komunikasi">Magister Ilmu Komunikasi</option>
                                    <option value="Magister Administrasi Publik">Magister Administrasi Publik</option>
                                    <option value="Magister Teknik Sipil">Magister Teknik Sipil</option>
                                    <option value="Magister Kenotariatan">Magister Kenotariatan</option>
                                    <option value="Magister Psikologi Profesi">Magister Psikologi Profesi</option>
                                    <option value="Doktor Ilmu Hukum">Doktor Ilmu Hukum</option>
                                    <option value="Doktor Ilmu Ekonomi">Doktor Ilmu Ekonomi</option>
                                    <option value="Doktor Ilmu Manajemen">Doktor Ilmu Manajemen</option>
                                    <option value="Doktor Ilmu Sosial">Doktor Ilmu Sosial</option>
                                    <option value="Lainnya">Lainnya</option>
                                </datalist></>
                            ) : (tingkat === 'S1' || tingkat === 'D1/D2/D3') ? (
                                <><input type="text" list="jurusan_pilihan_list" className="w-full px-2 py-1.5 outline-none bg-white border border-gray-200 rounded focus:bg-blue-50 text-sm" placeholder="-- Ketik/Pilih Jurusan --" />
                                <datalist id="jurusan_pilihan_list">
                                    <option value="Teknik Informatika / Ilmu Komputer">Teknik Informatika / Ilmu Komputer</option>
                                    <option value="Hukum">Hukum</option>
                                    <option value="Manajemen / Bisnis">Manajemen / Bisnis</option>
                                    <option value="Akuntansi">Akuntansi</option>
                                    <option value="Psikologi">Psikologi</option>
                                    <option value="Ilmu Komunikasi">Ilmu Komunikasi</option>
                                    <option value="Sastra / Bahasa">Sastra / Bahasa</option>
                                    <option value="Teknik Sipil">Teknik Sipil</option>
                                    <option value="Teknik Industri">Teknik Industri</option>
                                    <option value="Teknik Mesin">Teknik Mesin</option>
                                    <option value="Teknik Elektro">Teknik Elektro</option>
                                    <option value="Agribisnis / Pertanian">Agribisnis / Pertanian</option>
                                    <option value="Kedokteran">Kedokteran</option>
                                    <option value="Lainnya">Lainnya</option>
                                </datalist></>
                            ) : tingkat === 'SD' || tingkat === 'SLTP' ? (
                                <input type="text" name="jurusan_sd_smp" value="-" readOnly className="w-full px-2 py-1.5 outline-none bg-gray-100 text-gray-500 border border-gray-200 rounded text-sm cursor-not-allowed" />
                            ) : (
                                <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full px-2 py-1.5 outline-none focus:bg-blue-50 border border-gray-200 rounded bg-white text-sm" />
                            )}
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 border-gray-200 divide-x">
                           <div className="flex flex-col p-3">
                              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Tahun Dari</label>
                              <select className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 bg-white border border-gray-200 rounded cursor-pointer text-center">
                                  <option value=""></option>
                                  {Array.from({ length: 150 }, (_, i) => 2036 - i).map(year => <option key={year} value={year}>{year}</option>)}
                              </select>
                           </div>
                           <div className="flex flex-col p-3">
                              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Tahun Sampai</label>
                              <select className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 bg-white border border-gray-200 rounded cursor-pointer text-center">
                                  <option value=""></option>
                                  {Array.from({ length: 150 }, (_, i) => 2036 - i).map(year => <option key={year} value={year}>{year}</option>)}
                              </select>
                           </div>
                           <div className="flex flex-col p-3 col-span-2">
                              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Lulus / Tidak</label>
                              <select className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 bg-white border border-gray-200 rounded cursor-pointer">
                                 <option value=""></option>
                                 <option value="Lulus">Lulus</option>
                                 <option value="Tidak">Tidak Lulus</option>
                              </select>
                           </div>
                        </div>
                    </div>
                 ));
             })()}
         </div>
      </div>

      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900">Kursus / Training</h2>
        </div>
        <div className="space-y-4 list-kursus">
            {kursuses.map((k, index) => (
              <div key={k.id} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button type="button" onClick={() => removeKursus(k.id)} className="text-gray-400 hover:text-red-500 p-1 bg-white rounded shadow-sm">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                     Kursus / Training <span className="ml-1">{index + 1}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Bidang Jenis</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Penyelenggara</label>
                        <input type="text" className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Tempat/Kota</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Lama Kursus</label>
                        <input type="text" className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 border-gray-200 divide-y md:divide-y-0 md:divide-x">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Tahun</label>
                        <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer bg-transparent focus:bg-blue-50 border border-gray-200 rounded">
                           <option value=""></option>
                           {Array.from({ length: 150 }, (_, i) => 2036 - i).map(year => (
                              <option key={year} value={year}>{year}</option>
                           ))}
                        </select>
                     </div>
                     <div className="flex flex-col p-2 lg:col-span-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Dibiayai Oleh</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                  </div>
              </div>
            ))}
         </div>
        <button type="button"
           onClick={addKursus}
           className="mt-3 flex items-center justify-center w-full py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-blue-600 font-medium hover:bg-blue-50 hover:border-blue-300 transition-colors"
        >
           <PlusCircle className="w-5 h-5 mr-2" />
           Tambah Kursus
        </button>
      </div>

      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900">Pengetahuan Bahasa <span className="text-sm font-normal text-gray-500">(Baik Sekali, Baik, Cukup)</span></h2>
        </div>
        <div className="space-y-4 list-bahasa">
            {bahasas.map((b, index) => (
              <div key={b.id} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button type="button" onClick={() => removeBahasa(b.id)} className="text-gray-400 hover:text-red-500 p-1 bg-white rounded shadow-sm">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                     Bahasa <span className="ml-1">{index + 1}</span>
                  </div>
                  
                  <div className="p-2 border-b border-gray-200 bg-white">
                     <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jenis Bahasa</label>
                     <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent border-b focus:border-blue-500 transition-colors" />
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x border-gray-200">
                     {['Mendengar', 'Membaca', 'Berbicara', 'Menulis'].map((kemampuan) => (
                        <div key={kemampuan} className="flex flex-col p-2">
                           <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">{kemampuan}</label>
                           <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer bg-transparent border border-gray-200 rounded focus:bg-blue-50">
                               <option value=""></option>
                               <option value="Baik Sekali">Baik Sekali</option>
                               <option value="Baik">Baik</option>
                               <option value="Cukup">Cukup</option>
                           </select>
                        </div>
                     ))}
                  </div>
              </div>
            ))}
         </div>
        <button type="button"
           onClick={addBahasa}
           className="mt-3 flex items-center justify-center w-full py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-blue-600 font-medium hover:bg-blue-50 hover:border-blue-300 transition-colors"
        >
           <PlusCircle className="w-5 h-5 mr-2" />
           Tambah Bahasa
        </button>
      </div>

      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900 uppercase">Teknikal/Hardskill Yang Dimiliki</h2>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
           <div className="mb-4">
               <label className="block text-sm font-medium text-gray-700 mb-2">Pilih Hardskill (Bisa lebih dari satu)</label>
               <div className="relative" ref={dropdownRef}>
                   <div 
                      className="min-h-[42px] border border-gray-300 rounded-md p-3 flex justify-between items-center bg-white cursor-pointer hover:border-blue-500 transition-colors"
                      onClick={() => setIsHardskillOpen(!isHardskillOpen)}
                   >
                     <span className="text-sm text-gray-600 font-medium">
                       {selectedHardskills.length > 0 
                         ? `${selectedHardskills.length} Hardskill dipilih` 
                         : "Buka menu pilihan hardskill..."}
                     </span>
                     <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${isHardskillOpen ? 'rotate-180' : ''}`} />
                   </div>
                   <div className={`absolute z-50 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-xl max-h-72 overflow-y-auto ${isHardskillOpen ? 'block' : 'hidden'}`}>
                       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 p-3 bg-gray-50/50">
                           {[
                               "Operasional Mesin Printing", "Operasional Mesin Extru", "Operasional Mesin Dry",
                               "Operasional Mesin Slitting", "Operasional Mesin Bag Making", "Operasional Mesin rewind",
                               "Colour Matching", "Pest Control Management", "Pengelolaan Limbah", "Total Quality Maintanance (TQM)",
                               "Six Sigma", "5 R", "Keselamatan & Kesehatan Kerja (K3)", "International Standard Organization (ISO)",
                               "Manajemen Halal", "Quality Control", "Brevet", "Microsoft Excel", "Interview", "Editing Photo",
                               "MySql", "Sales Marketing", "B2B Sales", "B2C Sales", "Legal", "Legal Document", "Admin finance",
                               "Corporate finance", "Cost control", "Canva", "Video editing", "Adobe Photoshop", "Purchasing",
                               "Procurement", "Production Planning & Inventory Control", "Maintenance", "Warehouse Management",
                               "Accounting", "Training Management", "Industrial relation", "General Affair Management", "Audit Management"
                           ].map(skill => (
                               <label key={skill} className="flex items-start space-x-2 text-sm text-gray-700 cursor-pointer hover:bg-gray-100 p-2 rounded transition-colors border border-transparent hover:border-gray-200 bg-white shadow-sm">
                                  <input 
                                     type="checkbox" 
                                     name="hardskill" 
                                     value={skill} 
                                     checked={selectedHardskills.includes(skill)}
                                     onChange={() => toggleHardskill(skill)}
                                     className="mt-0.5 w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" 
                                  />
                                  <span className="leading-tight">{skill}</span>
                               </label>
                           ))}
                       </div>
                   </div>
               </div>
           </div>
           
           <div className="w-full space-y-3">
               <label className="block text-sm font-medium text-gray-700">Hardskill Lainnya (Opsional)</label>
               <input type="text" name="hardskill_lainnya" className="w-full border-b border-gray-300 outline-none p-2 text-sm bg-transparent" placeholder="Ketik hardskill lainnya..." />
               <input type="text" name="hardskill_lainnya" className="w-full border-b border-gray-300 outline-none p-2 text-sm bg-transparent" placeholder="Ketik hardskill lainnya..." />
           </div>
        </div>
      </div>

      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900">Kegiatan Sosial</h2>
        </div>
        <div className="space-y-4 list-kegiatan">
            {kegiatans.map((k, index) => (
              <div key={k.id} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button type="button" onClick={() => removeKegiatan(k.id)} className="text-gray-400 hover:text-red-500 p-1 bg-white rounded shadow-sm">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                     Kegiatan <span className="ml-1">{index + 1}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Organisasi</label>
                        <input type="text" className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jenis Kegiatan</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jabatan</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Tahun</label>
                        <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer bg-transparent border border-gray-200 rounded focus:bg-blue-50">
                            <option value=""></option>
                           {Array.from({ length: 150 }, (_, i) => 2036 - i).map(year => (
                              <option key={year} value={year}>{year}</option>
                           ))}
                        </select>
                     </div>
                  </div>
              </div>
            ))}
         </div>
        <button type="button"
           onClick={addKegiatan}
           className="mt-3 flex items-center justify-center w-full py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-blue-600 font-medium hover:bg-blue-50 hover:border-blue-300 transition-colors"
        >
           <PlusCircle className="w-5 h-5 mr-2" />
           Tambah Kegiatan
        </button>
      </div>
      
      <div>
         <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Hobby dan Minat</h2>
         
         <div className="space-y-6">
             <div>
                <label className="block text-sm font-medium text-gray-700">Hobby Dan Kegiatan Di Waktu Luang</label>
                <textarea name="hobby" className="w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border" rows={3} required></textarea>
             </div>

             <div className="mt-8">
                 <label className="block text-sm font-medium text-gray-700 mb-4">Frekuensi Membaca Buku / Majalah (Online/Offline)</label>
                 <div className="space-y-4 list-membaca">
                    {['Buku', 'Majalah'].map(item => (
                       <div key={item} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                          <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                             {item}
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 divide-y md:divide-y-0 lg:divide-x border-b border-gray-200">
                             <div className="flex flex-col p-3">
                                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Media</label>
                                <select className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 bg-white border border-gray-200 rounded cursor-pointer">
                                   <option value=""></option>
                                   <option value="Online">Online</option>
                                   <option value="Offline">Offline</option>
                                   <option value="Keduanya">Keduanya</option>
                                </select>
                             </div>
                             <div className="flex flex-col p-3">
                                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Pokok / Judul Yang Dibaca</label>
                                <input type="text" className="w-full text-sm outline-none px-2 py-1.5 focus:bg-blue-50 bg-white border border-gray-200 rounded" />
                             </div>
                             <div className="flex flex-col p-3">
                                <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Frekuensi Membaca</label>
                                <div className="flex flex-wrap gap-4 mt-1">
                                   <label className="flex items-center gap-1.5 cursor-pointer text-sm"><input type="radio" value="Banyak" name={`${item.toLowerCase()}_freq`} className="cursor-pointer" /> Banyak</label>
                                   <label className="flex items-center gap-1.5 cursor-pointer text-sm"><input type="radio" value="Sedang" name={`${item.toLowerCase()}_freq`} className="cursor-pointer" /> Sedang</label>
                                   <label className="flex items-center gap-1.5 cursor-pointer text-sm"><input type="radio" value="Sedikit" name={`${item.toLowerCase()}_freq`} className="cursor-pointer" /> Sedikit</label>
                                </div>
                             </div>
                          </div>
                       </div>
                    ))}
                 </div>
             </div>
         </div>
      </div>

    </div>
  );
}
