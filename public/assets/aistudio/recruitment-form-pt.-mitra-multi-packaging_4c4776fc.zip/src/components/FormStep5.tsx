import React, { useState, useRef, useEffect } from 'react';
import { X, RefreshCw, Check } from 'lucide-react';
import SignatureCanvas from 'react-signature-canvas';

const questions = [
  "Apakah anda bersedia menjalani masa percobaan 3 bulan ?",
  "Apakah anda bersedia memberikan waktu selambat-lambatnya 2 bulan bagi perusahaan jika anda mengundurkan diri ?",
  "Apakah anda terikat kontrak dengan perusahaan tempat anda bekerja saat ini ?",
  "Apakah anda bersedia dimutasikan ?",
  "Apakah anda mempunyai pekerjaan sampingan/part time ? Dimana dan sebagai apa?",
  "Apakah anda mempunyai teman/sanak saudara yang bekerja diperusahaan ini? Sebutkan !",
  "Apakah anda pernah menderita sakit kronis/kecelakaan berat/operasi ? Bilamana dan penyakit apa? Jelaskan !",
  "Apakah anda sedang hamil ?",
  "Apakah anda bersedia untuk tidak hamil dalam kurun waktu selama 1 tahun?",
  "Bila diterima, bersediahkan anda ditempatkan diluar kota ?"
];

export function FormStep5() {
  const sigCanvas = useRef<SignatureCanvas>(null);
  const [signatureData, setSignatureData] = useState<string>('');

  useEffect(() => {
    const savedSig = sessionStorage.getItem('pelamar_signature');
    if (savedSig && savedSig.length > 50) {
      setSignatureData(savedSig);
      const hiddenInputs = document.querySelectorAll<HTMLInputElement>('#base64_signature_data');
      hiddenInputs.forEach(input => { input.value = savedSig; });
    } else {
      const hiddenInput = document.getElementById('base64_signature_data') as HTMLInputElement;
      if (hiddenInput && hiddenInput.value && hiddenInput.value.length > 50) {
        setSignatureData(hiddenInput.value);
        sessionStorage.setItem('pelamar_signature', hiddenInput.value);
      }
    }
  }, []);

  const handleSignatureEnd = () => {
    if (sigCanvas.current && !sigCanvas.current.isEmpty()) {
       let dataUrl = '';
       try {
          dataUrl = sigCanvas.current.getTrimmedCanvas().toDataURL('image/png');
       } catch {
          dataUrl = sigCanvas.current.getCanvas().toDataURL('image/png');
       }
       if (dataUrl && dataUrl.length > 50) {
          setSignatureData(dataUrl);
          sessionStorage.setItem('pelamar_signature', dataUrl);
          const hiddenInputs = document.querySelectorAll<HTMLInputElement>('#base64_signature_data');
          hiddenInputs.forEach(input => { input.value = dataUrl; });
       }
    }
  };

  const clearSignature = () => {
    if (sigCanvas.current) {
        sigCanvas.current.clear();
    }
    setSignatureData('');
    sessionStorage.removeItem('pelamar_signature');
    const hiddenInputs = document.querySelectorAll<HTMLInputElement>('#base64_signature_data');
    hiddenInputs.forEach(input => { input.value = ''; });
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Kuesioner</h2>
        <div className="space-y-4 p-4 bg-gray-50/50">
                  {questions.map((q, idx) => (
                     <div key={idx} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                        <p className="text-sm font-medium text-gray-800 mb-3">{idx + 1}. {q}</p>
                        <div className="flex flex-col md:flex-row gap-4">
                           <div className="flex gap-6 md:w-1/4">
                               <label className="flex items-center gap-2 cursor-pointer">
                                  <input type="radio" value="Ya" name={`q_${idx}`} className="w-4 h-4 text-blue-600 focus:ring-blue-500 cursor-pointer" required />
                                  <span className="text-sm text-gray-700 font-medium">Ya</span>
                               </label>
                               <label className="flex items-center gap-2 cursor-pointer">
                                  <input type="radio" value="Tidak" name={`q_${idx}`} className="w-4 h-4 text-blue-600 focus:ring-blue-500 cursor-pointer" required />
                                  <span className="text-sm text-gray-700 font-medium">Tidak</span>
                               </label>
                           </div>
                           <div className="md:w-3/4">
                               <textarea name={`q_expl_${idx}`} className="w-full h-full min-h-[60px] p-2 text-sm border border-gray-200 rounded-md outline-none bg-gray-50 focus:bg-white focus:border-blue-500 transition-colors resize-y" placeholder="Jelaskan bila perlu..."></textarea>
                           </div>
                     </div>
                     </div>
                   ))}
            </div>
      </div>

      <div className="space-y-4 pt-4 border-t">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Dari mana anda mengetahui lowongan pekerjaan ini?</label>
            <input name="info_lowongan" type="text" className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border" placeholder="Sebutkan sumber informasi lowongan pekerjaan (contoh: Instagram, Jobstreet, Teman, dll)..." required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mengapa anda ingin bekerja di perusahaan ini?</label>
            <textarea name="alasan_kerja" className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border" required></textarea>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Jenis pekerjaan apakah yang sesuai dengan cita-cita anda ?</label>
            <input name="cita_cita" type="text" className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Jenis pekerjaan apakah yang tidak anda sukai ?</label>
            <textarea name="job_tidak_suka" className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border" required></textarea>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bila diterima, kapankah anda mulai bekerja ?</label>
            <input name="siap_kerja" type="text" className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border md:w-1/2" required />
          </div>
      </div>
      
      <div className="mt-12 p-6 bg-blue-50 rounded-xl border border-blue-100">
         <h3 className="font-semibold text-blue-900 mb-3">* Pernyataan & Tanda Tangan</h3>
         <p className="text-sm text-blue-800 leading-relaxed mb-6">
            Dengan ini saya menyatakan bahwa keterangan yang saya berikan di atas benar isinya. 
            Bilamana ternyata terdapat ketidakbenaran, saya bertanggung jawab penuh atas akibatnya.
         </p>
         
         <div className="flex flex-col md:flex-row justify-between items-end gap-8">
            <div className="flex flex-col gap-2 w-full md:w-auto">
                <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-700 w-20">Tempat:</span>
                    <input name="kota_ttd" type="text" className="w-full md:w-48 border-b-2 border-gray-300 bg-white/50 focus:bg-white focus:outline-none focus:border-blue-600 px-2 py-1 text-sm font-medium text-gray-800 rounded-t-md transition-colors" placeholder="Kota" required />
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-700 w-20">Tanggal:</span>
                    <input name="tanggal_ttd" type="date" className="w-full md:w-48 border-b-2 border-gray-300 bg-white/50 focus:bg-white focus:outline-none focus:border-blue-600 px-2 py-1 text-sm font-medium text-gray-800 rounded-t-md transition-colors" required />
                </div>
            </div>

            <div className="flex flex-col items-center">
                
                <div className="relative border-2 border-dashed border-gray-300 rounded-lg w-56 h-32 bg-white mb-2 overflow-hidden group">
                    <input type="hidden" id="base64_signature_data" value={signatureData} />
                    {signatureData && signatureData.length > 50 ? (
                      <div className="relative w-full h-full flex flex-col items-center justify-center p-2 bg-white">
                        <img src={signatureData} alt="Tanda Tangan Pelamar" className="max-h-20 max-w-full object-contain" />
                        <span className="text-[11px] text-green-600 font-semibold mt-1 flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" /> Tanda Tangan Tersimpan
                        </span>
                        <button type="button"
                            onClick={clearSignature}
                            className="absolute top-1 right-1 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-md p-1 transition-opacity z-10"
                            title="Hapus / Ulang Tanda Tangan"
                        >
                            <RefreshCw className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <SignatureCanvas 
                            ref={sigCanvas}
                            penColor="black"
                            onEnd={handleSignatureEnd}
                            canvasProps={{width: 224, height: 128, className: 'signature-canvas cursor-crosshair'}}
                        />
                        <button type="button"
                            onClick={clearSignature}
                            className="absolute top-1 right-1 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-md p-1 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity"
                            title="Hapus / Ulang Tanda Tangan"
                        >
                            <RefreshCw className="w-4 h-4" />
                        </button>
                        <div className="pointer-events-none absolute bottom-1 left-0 w-full text-center opacity-30 text-xs font-semibold text-gray-500">
                            Tanda Tangan Disini
                        </div>
                      </>
                    )}
                </div>

                <div className="border-b-2 border-gray-800 w-full mb-1"></div>
                <span className="text-sm font-bold text-gray-700 uppercase tracking-wider">Pelamar</span>
            </div>
         </div>
      </div>
    </div>
  );
}
