import React, { useState } from 'react';
import { PlusCircle, Trash2 } from 'lucide-react';

interface AreaItem {
  id: string;
  name: string;
}

const toTitleCase = (str: string) => {
  if (!str) return "";
  return str.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
};

export function FormStep1() {
  const [keluarga, setKeluarga] = useState([
    { id: 1, hubungan: '' }
  ]);

  // Cascading Address Dropdown States - KTP
  const [provinces, setProvinces] = useState<AreaItem[]>([]);
  const [regencies, setRegencies] = useState<AreaItem[]>([]);
  const [districts, setDistricts] = useState<AreaItem[]>([]);
  const [villages, setVillages] = useState<AreaItem[]>([]);

  const [selectedProvince, setSelectedProvince] = useState("");
  const [selectedRegency, setSelectedRegency] = useState("");
  const [selectedDistrict, setSelectedDistrict] = useState("");
  const [selectedVillage, setSelectedVillage] = useState("");
  const [streetAddress, setStreetAddress] = useState("");

  const [loadingProvince, setLoadingProvince] = useState(false);
  const [loadingRegency, setLoadingRegency] = useState(false);
  const [loadingDistrict, setLoadingDistrict] = useState(false);
  const [loadingVillage, setLoadingVillage] = useState(false);

  // Cascading Address Dropdown States - Domisili
  const [domRegencies, setDomRegencies] = useState<AreaItem[]>([]);
  const [domDistricts, setDomDistricts] = useState<AreaItem[]>([]);
  const [domVillages, setDomVillages] = useState<AreaItem[]>([]);

  const [selectedDomProvince, setSelectedDomProvince] = useState("");
  const [selectedDomRegency, setSelectedDomRegency] = useState("");
  const [selectedDomDistrict, setSelectedDomDistrict] = useState("");
  const [selectedDomVillage, setSelectedDomVillage] = useState("");
  const [domStreetAddress, setDomStreetAddress] = useState("");

  const [loadingDomRegency, setLoadingDomRegency] = useState(false);
  const [loadingDomDistrict, setLoadingDomDistrict] = useState(false);
  const [loadingDomVillage, setLoadingDomVillage] = useState(false);

  const [domisiliSamaKtp, setDomisiliSamaKtp] = useState(false);

  // Fetch Provinces on mount (Shared between KTP & Domisili)
  React.useEffect(() => {
    const fetchProvinces = async () => {
      setLoadingProvince(true);
      try {
        const response = await fetch('https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json');
        if (!response.ok) throw new Error('Failed to fetch provinces');
        const data = await response.json();
        // Sort alphabetically A-Z
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setProvinces(sorted);
      } catch (error) {
        console.error('Error fetching provinces:', error);
      } finally {
        setLoadingProvince(false);
      }
    };
    fetchProvinces();
  }, []);

  // Fetch Regencies when KTP province changes
  React.useEffect(() => {
    if (!selectedProvince) {
      setRegencies([]);
      setSelectedRegency("");
      return;
    }
    const fetchRegencies = async () => {
      setLoadingRegency(true);
      try {
        const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/regencies/${selectedProvince}.json`);
        if (!response.ok) throw new Error('Failed to fetch regencies');
        const data = await response.json();
        // Sort alphabetically A-Z
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setRegencies(sorted);
      } catch (error) {
        console.error('Error fetching regencies:', error);
      } finally {
        setLoadingRegency(false);
      }
    };
    fetchRegencies();
    setSelectedRegency("");
    setDistricts([]);
    setSelectedDistrict("");
    setVillages([]);
    setSelectedVillage("");
  }, [selectedProvince]);

  // Fetch Districts when KTP regency changes
  React.useEffect(() => {
    if (!selectedRegency) {
      setDistricts([]);
      setSelectedDistrict("");
      return;
    }
    const fetchDistricts = async () => {
      setLoadingDistrict(true);
      try {
        const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/districts/${selectedRegency}.json`);
        if (!response.ok) throw new Error('Failed to fetch districts');
        const data = await response.json();
        // Sort alphabetically A-Z
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setDistricts(sorted);
      } catch (error) {
        console.error('Error fetching districts:', error);
      } finally {
        setLoadingDistrict(false);
      }
    };
    fetchDistricts();
    setSelectedDistrict("");
    setVillages([]);
    setSelectedVillage("");
  }, [selectedRegency]);

  // Fetch Villages when KTP district changes
  React.useEffect(() => {
    if (!selectedDistrict) {
      setVillages([]);
      setSelectedVillage("");
      return;
    }
    const fetchVillages = async () => {
      setLoadingVillage(true);
      try {
        const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/villages/${selectedDistrict}.json`);
        if (!response.ok) throw new Error('Failed to fetch villages');
        const data = await response.json();
        // Sort alphabetically A-Z
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setVillages(sorted);
      } catch (error) {
        console.error('Error fetching villages:', error);
      } finally {
        setLoadingVillage(false);
      }
    };
    fetchVillages();
    setSelectedVillage("");
  }, [selectedDistrict]);

  // Fetch Regencies for Domisili
  React.useEffect(() => {
    if (domisiliSamaKtp) return;
    if (!selectedDomProvince) {
      setDomRegencies([]);
      setSelectedDomRegency("");
      return;
    }
    const fetchRegencies = async () => {
      setLoadingDomRegency(true);
      try {
        const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/regencies/${selectedDomProvince}.json`);
        if (!response.ok) throw new Error('Failed to fetch regencies');
        const data = await response.json();
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setDomRegencies(sorted);
      } catch (error) {
        console.error('Error fetching dom regencies:', error);
      } finally {
        setLoadingDomRegency(false);
      }
    };
    fetchRegencies();
    setSelectedDomRegency("");
    setDomDistricts([]);
    setSelectedDomDistrict("");
    setDomVillages([]);
    setSelectedDomVillage("");
  }, [selectedDomProvince, domisiliSamaKtp]);

  // Fetch Districts for Domisili
  React.useEffect(() => {
    if (domisiliSamaKtp) return;
    if (!selectedDomRegency) {
      setDomDistricts([]);
      setSelectedDomDistrict("");
      return;
    }
    const fetchDistricts = async () => {
      setLoadingDomDistrict(true);
      try {
        const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/districts/${selectedDomRegency}.json`);
        if (!response.ok) throw new Error('Failed to fetch districts');
        const data = await response.json();
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setDomDistricts(sorted);
      } catch (error) {
        console.error('Error fetching dom districts:', error);
      } finally {
        setLoadingDomDistrict(false);
      }
    };
    fetchDistricts();
    setSelectedDomDistrict("");
    setDomVillages([]);
    setSelectedDomVillage("");
  }, [selectedDomRegency, domisiliSamaKtp]);

  // Fetch Villages for Domisili
  React.useEffect(() => {
    if (domisiliSamaKtp) return;
    if (!selectedDomDistrict) {
      setDomVillages([]);
      setSelectedDomVillage("");
      return;
    }
    const fetchVillages = async () => {
      setLoadingDomVillage(true);
      try {
        const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/villages/${selectedDomDistrict}.json`);
        if (!response.ok) throw new Error('Failed to fetch villages');
        const data = await response.json();
        const sorted = (data as AreaItem[]).sort((a, b) => a.name.localeCompare(b.name));
        setDomVillages(sorted);
      } catch (error) {
        console.error('Error fetching dom villages:', error);
      } finally {
        setLoadingDomVillage(false);
      }
    };
    fetchVillages();
    setSelectedDomVillage("");
  }, [selectedDomDistrict, domisiliSamaKtp]);

  // Synthesize full KTP address
  const provinceName = provinces.find(p => p.id === selectedProvince)?.name || "";
  const regencyName = regencies.find(r => r.id === selectedRegency)?.name || "";
  const districtName = districts.find(d => d.id === selectedDistrict)?.name || "";
  const villageName = villages.find(v => v.id === selectedVillage)?.name || "";

  const parts = [
    streetAddress.trim(),
    villageName ? `Kel. ${toTitleCase(villageName)}` : "",
    districtName ? `Kec. ${toTitleCase(districtName)}` : "",
    regencyName ? toTitleCase(regencyName) : "",
    provinceName ? `Prov. ${toTitleCase(provinceName)}` : ""
  ].filter(Boolean);

  const fullAddress = parts.join(', ');

  // Synthesize full Domisili address
  const domProvinceName = provinces.find(p => p.id === selectedDomProvince)?.name || "";
  const domRegencyName = domRegencies.find(r => r.id === selectedDomRegency)?.name || "";
  const domDistrictName = domDistricts.find(d => d.id === selectedDomDistrict)?.name || "";
  const domVillageName = domVillages.find(v => v.id === selectedDomVillage)?.name || "";

  const domParts = [
    domStreetAddress.trim(),
    domVillageName ? `Kel. ${toTitleCase(domVillageName)}` : "",
    domDistrictName ? `Kec. ${toTitleCase(domDistrictName)}` : "",
    domRegencyName ? toTitleCase(domRegencyName) : "",
    domProvinceName ? `Prov. ${toTitleCase(domProvinceName)}` : ""
  ].filter(Boolean);

  const domFullAddress = domisiliSamaKtp ? fullAddress : domParts.join(', ');

  // Synchronize when checkbox checked
  React.useEffect(() => {
    if (domisiliSamaKtp) {
      setSelectedDomProvince("");
      setSelectedDomRegency("");
      setSelectedDomDistrict("");
      setSelectedDomVillage("");
      setDomStreetAddress("");
    }
  }, [domisiliSamaKtp, fullAddress]);

  const addKeluarga = () => {
    setKeluarga([...keluarga, { id: Date.now(), hubungan: 'Saudara/Lainnya' }]);
  };

  const removeKeluarga = (id: number) => {
    setKeluarga(keluarga.filter(k => k.id !== id));
  };

  const jobOptions = [
    "DIREKTUR PABRIKASI", "DIREKTUR UTAMA", "GENERAL MANAGER", "IT, TEKNIK MANAGER", "SUPPLY CHAIN MANAGER",
    "QA MANAGER", "PRODUKSI MANAGER", "SALES MANAGER", "HCGA MANAGER", "FAT MANAGER", "PROCUREMENT MANAGER",
    "TEKNIK SUPERVISOR", "PRODUKSI SUPERVISOR", "QC SUPERVISOR", "WAREHOUSE SUPERVISOR", "LABORATORIUM SUPERVISOR",
    "PPIC SUPERVISOR", "R & D SUPERVISOR", "QMS SUPERVISOR", "FINANCE SUPERVISOR", "STAFF COLOR MATCHING",
    "OPERATOR TINTA", "OPERATOR PRINTING", "OPERATOR DRY", "OPERATOR SLITTING", "OPERATOR REWIND",
    "OPERATOR INSPECTION", "OPERATOR BAG MAKING", "INSPEKTOR LAMINASI", "INSPEKTOR PRINTING",
    "INSPEKTOR SLITTING", "INSPEKTOR BAG MAKING", "STAFF ADMIN QA", "INSPEKTOR LAB", "STAFF TEKNIK",
    "CORPORATE SALES", "STAFF ADMIN SALES", "STAFF CASHIER", "STAFF ADMIN GA", "STAFF ADMIN PRODUKSI LAPANGAN",
    "STAFF HUMAS", "STAFF ADMIN HC", "STAFF ADMIN INVENTORY", "STAFF ADMIN WAREHOUSE FG",
    "STAFF ADMIN SUPPLY CHAIN", "STAFF ADMIN PPIC", "STAFF ADMIN PRODUKSI SYSTEM", "STAFF ADMIN ACCOUNTING",
    "STAFF ADMIN TEKNIK & IT", "STAFF ADMIN WAREHOUSE RM", "STAFF ADMIN CYLINDER", "STAFF ADMIN TAX",
    "STAFF ADMIN PROCUREMENT", "STAFF SMO", "HELPER"
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Pekerjaan Yang Dilamar</h2>
        <input 
           name="pekerjaan_dilamar" 
           list="job-options"
           placeholder="-- KETIK / PILIH PEKERJAAN DILAMAR --"
           className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white" 
           required 
        />
        <datalist id="job-options">
           {jobOptions.map(job => (
              <option key={job} value={job}>{job}</option>
           ))}
        </datalist>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Data Pribadi</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="col-span-full">
            <label className="block text-sm font-medium text-gray-700">Nama Lengkap / Nama Kecil</label>
            <input name="nama_lengkap" type="text" className="w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^a-zA-Z\s\/]/g, ''); }} required />
          </div>

          <div className="col-span-full bg-gray-50/70 p-5 rounded-xl border border-gray-200 shadow-sm space-y-4">
            <h3 className="text-sm font-semibold text-gray-800 border-b pb-1">Alamat Sesuai KTP</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Provinsi */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                  <span>Provinsi <span className="text-red-500">*</span></span>
                  {loadingProvince && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                </label>
                <select
                  value={selectedProvince}
                  onChange={(e) => setSelectedProvince(e.target.value)}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none"
                  required
                >
                  <option value="">-- Pilih Provinsi --</option>
                  {provinces.map((prov) => (
                    <option key={prov.id} value={prov.id}>
                      {toTitleCase(prov.name)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Kabupaten / Kota */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                  <span>Kabupaten / Kota <span className="text-red-500">*</span></span>
                  {loadingRegency && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                </label>
                <select
                  value={selectedRegency}
                  onChange={(e) => setSelectedRegency(e.target.value)}
                  disabled={!selectedProvince || loadingRegency}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none disabled:bg-gray-100 disabled:text-gray-400"
                  required
                >
                  <option value="">-- Pilih Kabupaten / Kota --</option>
                  {regencies.map((reg) => (
                    <option key={reg.id} value={reg.id}>
                      {toTitleCase(reg.name)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Kecamatan */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                  <span>Kecamatan <span className="text-red-500">*</span></span>
                  {loadingDistrict && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                </label>
                <select
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  disabled={!selectedRegency || loadingDistrict}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none disabled:bg-gray-100 disabled:text-gray-400"
                  required
                >
                  <option value="">-- Pilih Kecamatan --</option>
                  {districts.map((dist) => (
                    <option key={dist.id} value={dist.id}>
                      {toTitleCase(dist.name)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Kelurahan / Desa */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                  <span>Kelurahan / Desa <span className="text-red-500">*</span></span>
                  {loadingVillage && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                </label>
                <select
                  value={selectedVillage}
                  onChange={(e) => setSelectedVillage(e.target.value)}
                  disabled={!selectedDistrict || loadingVillage}
                  className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none disabled:bg-gray-100 disabled:text-gray-400"
                  required
                >
                  <option value="">-- Pilih Kelurahan / Desa --</option>
                  {villages.map((vil) => (
                    <option key={vil.id} value={vil.id}>
                      {toTitleCase(vil.name)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Detail Jalan */}
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Detail Jalan, RT/RW, No. Rumah / Blok <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={streetAddress}
                onChange={(e) => setStreetAddress(e.target.value)}
                placeholder="Contoh: Jl. Mangga Raya No. 12, RT 02/RW 05"
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none"
                required
              />
            </div>

            {/* Preview Alamat Lengkap */}
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">
                Preview Susunan Alamat Lengkap
              </label>
              <textarea
                name="alamat_dalam_kota"
                value={fullAddress}
                readOnly
                placeholder="Alamat lengkap akan terangkai otomatis setelah pilihan diisi..."
                className="w-full border-gray-300 bg-gray-100 text-gray-600 rounded-md shadow-sm p-2 border cursor-not-allowed text-sm focus:outline-none font-medium"
                rows={2}
                required
              />
            </div>

            {/* No HP */}
            <div className="pt-2 text-sm text-gray-600 flex items-center gap-2 border-t border-gray-200">
              <span className="font-medium text-xs text-gray-600">No. Hp/Telp <span className="text-red-500">*</span> :</span>
              <input
                name="no_hp"
                type="text"
                maxLength={15}
                onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }}
                className="border-gray-300 rounded-md shadow-sm flex-1 p-2 border text-sm focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
          </div>

          <div className="col-span-full bg-gray-50/70 p-5 rounded-xl border border-gray-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-1.5">
              <h3 className="text-sm font-semibold text-gray-800">Alamat Domisili</h3>
              <label className="inline-flex items-center gap-2 text-xs font-medium text-blue-600 cursor-pointer hover:text-blue-700 transition">
                <input
                  type="checkbox"
                  checked={domisiliSamaKtp}
                  onChange={(e) => setDomisiliSamaKtp(e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <span>Sama dengan Alamat KTP</span>
              </label>
            </div>
            
            {!domisiliSamaKtp && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Provinsi */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                      <span>Provinsi <span className="text-red-500">*</span></span>
                      {loadingProvince && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                    </label>
                    <select
                      value={selectedDomProvince}
                      onChange={(e) => setSelectedDomProvince(e.target.value)}
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none"
                      required={!domisiliSamaKtp}
                    >
                      <option value="">-- Pilih Provinsi --</option>
                      {provinces.map((prov) => (
                        <option key={prov.id} value={prov.id}>
                          {toTitleCase(prov.name)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Kabupaten / Kota */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                      <span>Kabupaten / Kota <span className="text-red-500">*</span></span>
                      {loadingDomRegency && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                    </label>
                    <select
                      value={selectedDomRegency}
                      onChange={(e) => setSelectedDomRegency(e.target.value)}
                      disabled={!selectedDomProvince || loadingDomRegency}
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none disabled:bg-gray-100 disabled:text-gray-400"
                      required={!domisiliSamaKtp}
                    >
                      <option value="">-- Pilih Kabupaten / Kota --</option>
                      {domRegencies.map((reg) => (
                        <option key={reg.id} value={reg.id}>
                          {toTitleCase(reg.name)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Kecamatan */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                      <span>Kecamatan <span className="text-red-500">*</span></span>
                      {loadingDomDistrict && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                    </label>
                    <select
                      value={selectedDomDistrict}
                      onChange={(e) => setSelectedDomDistrict(e.target.value)}
                      disabled={!selectedDomRegency || loadingDomDistrict}
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none disabled:bg-gray-100 disabled:text-gray-400"
                      required={!domisiliSamaKtp}
                    >
                      <option value="">-- Pilih Kecamatan --</option>
                      {domDistricts.map((dist) => (
                        <option key={dist.id} value={dist.id}>
                          {toTitleCase(dist.name)}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Kelurahan / Desa */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center justify-between">
                      <span>Kelurahan / Desa <span className="text-red-500">*</span></span>
                      {loadingDomVillage && <span className="text-blue-600 text-[10px] animate-pulse">Memuat data...</span>}
                    </label>
                    <select
                      value={selectedDomVillage}
                      onChange={(e) => setSelectedDomVillage(e.target.value)}
                      disabled={!selectedDomDistrict || loadingDomVillage}
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none disabled:bg-gray-100 disabled:text-gray-400"
                      required={!domisiliSamaKtp}
                    >
                      <option value="">-- Pilih Kelurahan / Desa --</option>
                      {domVillages.map((vil) => (
                        <option key={vil.id} value={vil.id}>
                          {toTitleCase(vil.name)}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Detail Jalan */}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Detail Jalan, RT/RW, No. Rumah / Blok <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={domStreetAddress}
                    onChange={(e) => setDomStreetAddress(e.target.value)}
                    placeholder="Contoh: Jl. Mangga Raya No. 12, RT 02/RW 05"
                    className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-2 border bg-white text-sm outline-none"
                    required={!domisiliSamaKtp}
                  />
                </div>
              </>
            )}

            {/* Preview Alamat Lengkap */}
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">
                Preview Susunan Alamat Domisili
              </label>
              <textarea
                name="alamat_luar_kota"
                value={domFullAddress}
                readOnly
                placeholder="Alamat domisili akan terangkai otomatis setelah pilihan diisi..."
                className="w-full border-gray-300 bg-gray-100 text-gray-600 rounded-md shadow-sm p-2 border cursor-not-allowed text-sm focus:outline-none font-medium"
                rows={2}
                required
              />
            </div>

            {/* No HP Domisili */}
            <div className="pt-2 text-sm text-gray-600 flex items-center gap-2 border-t border-gray-200">
              <span className="font-medium text-xs text-gray-600">No. Hp/Telp Domisili:</span>
              <input
                name="no_hp_luar_kota"
                type="text"
                maxLength={15}
                onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }}
                className="border-gray-300 rounded-md shadow-sm flex-1 p-2 border text-sm focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div>
             <label className="block text-sm font-medium text-gray-700">Jenis Kelamin</label>
             <div className="mt-2 flex items-center gap-4">
                <label className="flex items-center gap-2"><input type="radio" name="gender" value="Pria" required /> Pria</label>
                <label className="flex items-center gap-2"><input type="radio" name="gender" value="Wanita" required /> Wanita</label>
             </div>
          </div>

          <div className="grid grid-cols-3 gap-4 col-span-1 md:col-span-1">
              <div>
                 <label className="block text-sm font-medium text-gray-700">Tinggi (cm)</label>
                 <input name="tinggi_badan" type="text" maxLength={3} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full mt-1 border-gray-300 rounded-md shadow-sm p-2 border" required />
              </div>
              <div>
                 <label className="block text-sm font-medium text-gray-700">Berat (kg)</label>
                 <input name="berat_badan" type="text" maxLength={3} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full mt-1 border-gray-300 rounded-md shadow-sm p-2 border" required />
              </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Agama</label>
            <select name="agama" className="w-full mt-1 border-gray-300 rounded-md shadow-sm p-2 border outline-none bg-white" required>
               <option value="">-- Pilih Agama --</option>
               <option value="Islam">Islam</option>
               <option value="Kristen Protestan">Kristen Protestan</option>
               <option value="Katolik">Katolik</option>
               <option value="Hindu">Hindu</option>
               <option value="Buddha">Buddha</option>
               <option value="Konghucu">Konghucu</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Kebangsaan</label>
            <select name="kebangsaan" className="w-full mt-1 border-gray-300 rounded-md shadow-sm p-2 border outline-none bg-white" required>
               <option value="">-- Pilih Kebangsaan --</option>
               <option value="WNI">Warga Negara Indonesia (WNI)</option>
               <option value="WNA">Warga Negara Asing (WNA)</option>
            </select>
          </div>
          
          <div className="col-span-full">
             <label className="block text-sm font-medium text-gray-700">Tempat, Tanggal Lahir</label>
             <div className="grid grid-cols-2 gap-4 mt-1">
                <input name="tempat_lahir" type="text" placeholder="Tempat" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^a-zA-Z\s]/g, ''); }} className="border-gray-300 rounded-md shadow-sm p-2 border" required />
                <input name="tanggal_lahir" type="date" className="border-gray-300 rounded-md shadow-sm p-2 border" required />
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
           <h3 className="text-lg font-medium text-gray-900 border-b pb-2 mb-4">Status Perkawinan</h3>
           <div className="grid grid-cols-2 gap-4">
              <label className="flex items-center gap-2"><input type="radio" value="Belum Kawin" name="marital" required /> Belum Kawin</label>
              <label className="flex items-center gap-2"><input type="radio" value="Janda/Duda" name="marital" required /> Janda/Duda</label>
              <label className="flex items-center gap-2"><input type="radio" value="Kawin" name="marital" required /> Kawin</label>
              <label className="flex items-center gap-2"><input type="radio" value="Cerai" name="marital" required /> Cerai</label>
           </div>
        </div>
        
        <div>
           <h3 className="text-lg font-medium text-gray-900 border-b pb-2 mb-4">Identitas</h3>
           <div className="space-y-3">
              <div className="flex items-center gap-4">
                 <label className="w-24 text-sm font-medium text-gray-700">No. KTP</label>
                 <input name="ktp" type="text" maxLength={16} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="flex-1 border-gray-300 rounded-md shadow-sm p-2 border" />
              </div>
              <div className="flex items-center gap-4">
                 <label className="w-24 text-sm font-medium text-gray-700">No. NPWP</label>
                 <input name="npwp" type="text" maxLength={16} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="flex-1 border-gray-300 rounded-md shadow-sm p-2 border" />
              </div>
              <div className="flex items-center gap-4">
                 <label className="w-24 text-sm font-medium text-gray-700">No. SIM</label>
                 <div className="flex flex-1 gap-2">
                    <input name="sim_a" type="text" placeholder="A" maxLength={14} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-1/3 border-gray-300 rounded-md shadow-sm p-2 border" />
                    <input name="sim_b" type="text" placeholder="B" maxLength={14} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-1/3 border-gray-300 rounded-md shadow-sm p-2 border" />
                    <input name="sim_c" type="text" placeholder="C" maxLength={14} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-1/3 border-gray-300 rounded-md shadow-sm p-2 border" />
                 </div>
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
         <div>
            <h3 className="text-lg font-medium text-gray-900 border-b pb-2 mb-4">Lain-Lain</h3>
            <div className="space-y-4">
                <div>
                   <label className="block text-sm font-medium text-gray-700 mb-2">Rumah / Tempat Tinggal</label>
                   <div className="grid grid-cols-2 gap-2">
                      <label className="flex items-center gap-2"><input type="radio" value="Milik Sendiri" name="house" /> Milik Sendiri</label>
                      <label className="flex items-center gap-2"><input type="radio" value="Sewa Kontrak" name="house" /> Sewa Kontrak</label>
                      <label className="flex items-center gap-2"><input type="radio" value="Milik Orang Tua" name="house" /> Milik Orang Tua</label>
                      <div className="flex items-center gap-2 text-sm justify-start">
                         <input type="radio" value="Lain-lain" name="house" className="mt-1" />
                         <span>Lain-lain:</span>
                         <input name="house_other" type="text" className="border-b border-gray-400 focus:outline-none focus:border-blue-500 w-20 flex-1 ml-1" />
                      </div>
                   </div>
                </div>
            </div>
         </div>
         <div>
            <h3 className="text-lg font-medium text-gray-900 border-b pb-2 mb-4 text-transparent select-none">-</h3>
            <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Kendaraan</label>
                  <input name="kendaraan_jenis" type="text" placeholder="Jenis / Merk / Tahun" className="w-full border-gray-300 rounded-md shadow-sm p-2 border mb-2" />
                  <div className="flex items-center text-sm font-medium text-gray-700 mb-1">Milik:</div>
                  <div className="grid grid-cols-2 gap-2">
                      <label className="flex items-center gap-2"><input type="radio" value="Sendiri" name="vehicle" /> Sendiri</label>
                      <label className="flex items-center gap-2"><input type="radio" value="Orang Tua" name="vehicle" /> Orang Tua</label>
                      <label className="flex items-center gap-2"><input type="radio" value="Kantor" name="vehicle" /> Kantor</label>
                      <div className="flex items-center gap-2 text-sm justify-start">
                         <input type="radio" value="Lain-lain" name="vehicle" className="mt-1" />
                         <span>Lain-lain:</span>
                         <input name="vehicle_other" type="text" className="border-b border-gray-400 focus:outline-none focus:border-blue-500 w-20 flex-1 ml-1" />
                      </div>
                  </div>
                </div>
            </div>
         </div>
      </div>
      
      <div>
         <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900">Susunan Keluarga</h2>
         </div>
         <div className="space-y-4 list-keluarga">
            {keluarga.map((k, index) => (
              <div key={k.id} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button type="button" onClick={() => removeKeluarga(k.id)} className="text-gray-400 hover:text-red-500 p-1 bg-white rounded shadow-sm">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                     Anggota Keluarga <span className="ml-1">{index + 1}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Hubungan Keluarga</label>
                        <select defaultValue={k.hubungan} className="w-full text-sm outline-none px-1 py-1 cursor-pointer bg-transparent">
                           <option value=""></option>
                           <option value="Ayah">Ayah</option>
                           <option value="Ibu">Ibu</option>
                           <option value="Kakak">Kakak</option>
                           <option value="Adik">Adik</option>
                           <option value="Suami">Suami</option>
                           <option value="Istri">Istri</option>
                           <option value="Anak">Anak</option>
                        </select>
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Nama</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent" />
                     </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 border-b border-gray-200 divide-x hide-first-divider">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">L/P</label>
                        <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer bg-transparent"><option value=""></option><option value="L">L</option><option value="P">P</option></select>
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Usia</label>
                        <input type="text" maxLength={3} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent" />
                     </div>
                     <div className="flex flex-col p-2 col-span-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Pendidikan Terakhir</label>
                        <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer bg-transparent">
                           <option value=""></option>
                           <option value="SD">SD</option>
                           <option value="SMP">SMP</option>
                           <option value="SMA/SMK">SMA/SMK</option>
                           <option value="D1">D1</option>
                           <option value="D2">D2</option>
                           <option value="D3">D3</option>
                           <option value="S1/D4">S1/D4</option>
                           <option value="S2">S2</option>
                           <option value="S3">S3</option>
                           <option value="Belum Sekolah">Belum Sekolah</option>
                           <option value="Lainnya">Lainnya</option>
                        </select>
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x p-2">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jabatan Terakhir</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent" placeholder="Jabatan" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Perusahaan Terakhir</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent" placeholder="Perusahaan" />
                     </div>
                  </div>
              </div>
            ))}
         </div>
         <button type="button"
            onClick={addKeluarga}
            className="mt-3 flex items-center justify-center w-full py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-blue-600 font-medium hover:bg-blue-50 hover:border-blue-300 transition-colors"
         >
            <PlusCircle className="w-5 h-5 mr-2" />
            Tambah Anggota Keluarga
         </button>
      </div>
    </div>
  );
}
