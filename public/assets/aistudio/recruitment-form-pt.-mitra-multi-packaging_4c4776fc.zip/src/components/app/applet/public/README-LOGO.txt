letakkan logo Anda di folder public ini, misalnya dengan nama logo.png. Lalu panggil di kode dengan src="/logo.png".
