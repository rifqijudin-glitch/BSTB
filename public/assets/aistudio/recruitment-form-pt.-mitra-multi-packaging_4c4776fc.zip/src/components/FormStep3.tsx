import React, { useState } from 'react';
import { PlusCircle, Trash2 } from 'lucide-react';

export function FormStep3() {
  const [pekerjaans, setPekerjaans] = useState<Array<{ id: number, status: 'berhenti' | 'masih_bekerja' }>>([
    { id: 1, status: 'berhenti' }
  ]);

  const [referensis, setReferensis] = useState([
    { id: 1 }
  ]);

  const [kontaks, setKontaks] = useState([
    { id: 1 }
  ]);

  const addPekerjaan = () => setPekerjaans([...pekerjaans, { id: Date.now(), status: 'berhenti' }]);
  const removePekerjaan = (id: number) => setPekerjaans(pekerjaans.filter(p => p.id !== id));
  
  const addReferensi = () => setReferensis([...referensis, { id: Date.now() }]);
  const removeReferensi = (id: number) => setReferensis(referensis.filter(r => r.id !== id));

  const addKontak = () => setKontaks([...kontaks, { id: Date.now() }]);
  const removeKontak = (id: number) => setKontaks(kontaks.filter(k => k.id !== id));

  return (
    <div className="space-y-8">
      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900">Riwayat Pekerjaan <span className="text-sm font-normal text-gray-500">(Dimulai dengan pekerjaan sekarang)</span></h2>
        </div>
        
        <div className="space-y-8 list-pekerjaan">
          {pekerjaans.map((p, index) => (
             <div key={p.id} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button type="button" onClick={() => removePekerjaan(p.id)} className="text-gray-400 hover:text-red-500 p-1 bg-white rounded shadow-sm">
                       <Trash2 className="w-4 h-4" />
                    </button>
                </div>
                <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                   Pengalaman <span className="ml-1">{index + 1}</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-12 border-b">
                   <div className="md:col-span-3 border-r flex flex-col">
                      <div className="flex border-b">
                         <div className="w-1/2 p-2 bg-gray-50 border-r text-xs font-semibold text-center uppercase tracking-wider text-gray-600">Bulan</div>
                         <div className="w-1/2 p-2 bg-gray-50 text-xs font-semibold text-center uppercase tracking-wider text-gray-600">Thn</div>
                      </div>
                      <div className="flex border-b">
                         <div className="w-1/2 p-1 border-r flex items-center">
                            <span className="text-xs text-gray-500 w-10 px-1">Dari</span>
                            <select className="flex-1 text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent"><option value=""></option><option value="Januari">Jan</option><option value="Februari">Feb</option><option value="Maret">Mar</option><option value="April">Apr</option><option value="Mei">Mei</option><option value="Juni">Jun</option><option value="Juli">Jul</option><option value="Agustus">Agu</option><option value="September">Sep</option><option value="Oktober">Okt</option><option value="November">Nov</option><option value="Desember">Des</option></select>
                         </div>
                         <div className="w-1/2 p-1">
                            <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent"><option value=""></option><option value="2036">2036</option><option value="2035">2035</option><option value="2034">2034</option><option value="2033">2033</option><option value="2032">2032</option><option value="2031">2031</option><option value="2030">2030</option><option value="2029">2029</option><option value="2028">2028</option><option value="2027">2027</option><option value="2026">2026</option><option value="2025">2025</option><option value="2024">2024</option><option value="2023">2023</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option><option value="1917">1917</option><option value="1916">1916</option><option value="1915">1915</option><option value="1914">1914</option><option value="1913">1913</option><option value="1912">1912</option><option value="1911">1911</option><option value="1910">1910</option><option value="1909">1909</option><option value="1908">1908</option><option value="1907">1907</option><option value="1906">1906</option><option value="1905">1905</option><option value="1904">1904</option><option value="1903">1903</option><option value="1902">1902</option><option value="1901">1901</option><option value="1900">1900</option><option value="1899">1899</option><option value="1898">1898</option><option value="1897">1897</option><option value="1896">1896</option><option value="1895">1895</option><option value="1894">1894</option><option value="1893">1893</option><option value="1892">1892</option><option value="1891">1891</option><option value="1890">1890</option><option value="1889">1889</option><option value="1888">1888</option><option value="1887">1887</option></select>
                         </div>
                      </div>
                      <div className="flex">
                         <div className="w-1/2 p-1 border-r flex items-center">
                            <span className="text-xs text-gray-500 w-10 px-1 truncate" title="Sampai">Smpai</span>
                            <select disabled={p.status === 'masih_bekerja'} className={`flex-1 text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent ${p.status === 'masih_bekerja' ? 'opacity-50 cursor-not-allowed' : ''}`}><option value=""></option><option value="Januari">Jan</option><option value="Februari">Feb</option><option value="Maret">Mar</option><option value="April">Apr</option><option value="Mei">Mei</option><option value="Juni">Jun</option><option value="Juli">Jul</option><option value="Agustus">Agu</option><option value="September">Sep</option><option value="Oktober">Okt</option><option value="November">Nov</option><option value="Desember">Des</option></select>
                         </div>
                         <div className="w-1/2 p-1">
                            <select disabled={p.status === 'masih_bekerja'} className={`w-full text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent ${p.status === 'masih_bekerja' ? 'opacity-50 cursor-not-allowed' : ''}`}><option value=""></option><option value="2036">2036</option><option value="2035">2035</option><option value="2034">2034</option><option value="2033">2033</option><option value="2032">2032</option><option value="2031">2031</option><option value="2030">2030</option><option value="2029">2029</option><option value="2028">2028</option><option value="2027">2027</option><option value="2026">2026</option><option value="2025">2025</option><option value="2024">2024</option><option value="2023">2023</option><option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option><option value="1917">1917</option><option value="1916">1916</option><option value="1915">1915</option><option value="1914">1914</option><option value="1913">1913</option><option value="1912">1912</option><option value="1911">1911</option><option value="1910">1910</option><option value="1909">1909</option><option value="1908">1908</option><option value="1907">1907</option><option value="1906">1906</option><option value="1905">1905</option><option value="1904">1904</option><option value="1903">1903</option><option value="1902">1902</option><option value="1901">1901</option><option value="1900">1900</option><option value="1899">1899</option><option value="1898">1898</option><option value="1897">1897</option><option value="1896">1896</option><option value="1895">1895</option><option value="1894">1894</option><option value="1893">1893</option><option value="1892">1892</option><option value="1891">1891</option><option value="1890">1890</option><option value="1889">1889</option><option value="1888">1888</option><option value="1887">1887</option></select>
                         </div>
                      </div>
                   </div>
                   
                   <div className="md:col-span-6 border-r flex flex-col border-t md:border-t-0 p-2 min-h-[96px]">
                       <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Nama Perusahaan / No Telpon Perusahaan</label>
                       <textarea className="flex-1 w-full outline-none text-sm resize-none" placeholder="Masukkan detail perusahaan..." />
                   </div>

                   <div className="md:col-span-3 flex flex-col border-t md:border-t-0 p-2 min-h-[96px]">
                       <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jabatan</label>
                       <input type="text" className="w-full outline-none text-sm" placeholder="Jabatan anda..." />
                   </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                    <div className="flex flex-col p-2">
                       <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jenis Usaha</label>
                       <input type="text" className="w-full outline-none text-sm" />
                    </div>
                    <div className="flex flex-col p-2">
                       <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Jumlah Karyawan</label>
                       <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full outline-none text-sm" />
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                    <div className="flex flex-col p-2">
                       <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Nama Atasan Langsung</label>
                       <input type="text" className="w-full outline-none text-sm" />
                    </div>
                    <div className="flex flex-col p-2">
                       <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Nama Direktur</label>
                       <input type="text" className="w-full outline-none text-sm" />
                    </div>
                </div>

                <div className="p-3 border-b border-gray-200">
                    <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2 block">Status Pekerjaan</label>
                    <div className="flex gap-4">
                        <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                           <input type="radio" name={`statusPekerjaan_${p.id}`} value="masih_bekerja" checked={p.status === 'masih_bekerja'} onChange={() => setPekerjaans(pekerjaans.map(x => x.id === p.id ? { ...x, status: 'masih_bekerja' } : x))} className="w-4 h-4 text-blue-600 focus:ring-blue-500" /> Masih Bekerja
                        </label>
                        <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                           <input type="radio" name={`statusPekerjaan_${p.id}`} value="berhenti" checked={p.status === 'berhenti'} onChange={() => setPekerjaans(pekerjaans.map(x => x.id === p.id ? { ...x, status: 'berhenti' } : x))} className="w-4 h-4 text-blue-600 focus:ring-blue-500" /> Sudah Berhenti
                        </label>
                    </div>
                </div>

                {p.status === 'berhenti' && (
                  <div className="p-2 border-b-0 bg-red-50/20">
                      <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Alasan Berhenti</label>
                      <textarea className="w-full outline-none text-sm resize-none bg-transparent" rows={2} />
                  </div>
                )}
             </div>
          ))}
        </div>
        <button type="button"
           onClick={addPekerjaan}
           className="mt-4 flex items-center justify-center w-full py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-blue-600 font-medium hover:bg-blue-50 hover:border-blue-300 transition-colors"
        >
           <PlusCircle className="w-5 h-5 mr-2" />
           Tambah Riwayat Pekerjaan
        </button>
      </div>

      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900">Referensi <span className="text-sm font-normal text-gray-500">(Kepada siapa kami dapat menanyakan mengenai diri anda lebih lengkap)</span></h2>
         </div>
         <div className="space-y-4 list-referensi">
            {referensis.map((r, index) => (
              <div key={r.id} className="bg-white border rounded-lg overflow-hidden shadow-sm relative group">
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button type="button" onClick={() => removeReferensi(r.id)} className="text-gray-400 hover:text-red-500 p-1 bg-white rounded shadow-sm">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  <div className="bg-gray-50 px-4 py-2 border-b flex items-center font-medium text-gray-700">
                     Referensi <span className="ml-1">{index + 1}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Nama</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Alamat</label>
                        <input type="text" className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x border-gray-200">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">No. Telepon</label>
                        <input type="text" maxLength={14} minLength={9} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" placeholder="08xxxxxxxxxx" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Pekerjaan</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1 block">Hubungan</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-blue-50" />
                     </div>
                  </div>
              </div>
            ))}
         </div>
         <button type="button"
            onClick={addReferensi}
            className="mt-4 flex items-center justify-center w-full py-2.5 border border-dashed border-gray-300 rounded-lg text-sm text-blue-600 font-medium hover:bg-blue-50 hover:border-blue-300 transition-colors"
         >
            <PlusCircle className="w-5 h-5 mr-2" />
            Tambah Referensi
         </button>
      </div>

      <div>
        <div className="border-b pb-2 mb-4 mt-8">
            <h2 className="text-xl font-semibold text-gray-900 text-red-600">Kontak Darurat <span className="text-sm font-normal text-gray-500">(Orang yang dapat dihubungi segera dalam keadaan mendesak)</span></h2>
         </div>
         <div className="space-y-4 list-kontak">
            {kontaks.map((k, index) => (
              <div key={k.id} className="bg-white border border-red-200 rounded-lg overflow-hidden shadow-sm relative group">
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                     <button type="button" onClick={() => removeKontak(k.id)} className="text-red-400 hover:text-red-600 p-1 bg-white rounded shadow-sm border border-red-100">
                        <Trash2 className="w-4 h-4" />
                     </button>
                  </div>
                  <div className="bg-red-50 px-4 py-2 border-b border-red-100 flex items-center font-medium text-red-800">
                     Kontak Darurat <span className="ml-1">{index + 1}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-b border-red-100 bg-white">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-red-600 uppercase tracking-wider mb-1 block">Nama</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-red-50" required />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-red-600 uppercase tracking-wider mb-1 block">Alamat</label>
                        <input type="text" className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-red-50" required />
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x border-red-100 bg-white">
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-red-600 uppercase tracking-wider mb-1 block">Telepon</label>
                        <input type="text" maxLength={15} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-red-50" required />
                     </div>
                     <div className="flex flex-col p-2">
                        <label className="text-xs font-semibold text-red-600 uppercase tracking-wider mb-1 block">Hubungan</label>
                        <input type="text" onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/^[^a-zA-Z]+/g, ''); }} className="w-full text-sm outline-none px-1 py-1 bg-transparent focus:bg-red-50" required />
                     </div>
                  </div>
              </div>
            ))}
         </div>
         <button type="button"
            onClick={addKontak}
            className="mt-4 flex items-center justify-center w-full py-2.5 border border-dashed border-red-300 rounded-lg text-sm text-red-600 font-medium hover:bg-red-50 hover:border-red-400 transition-colors"
         >
            <PlusCircle className="w-5 h-5 mr-2" />
            Tambah Kontak Darurat
         </button>
      </div>

    </div>
  );
}
