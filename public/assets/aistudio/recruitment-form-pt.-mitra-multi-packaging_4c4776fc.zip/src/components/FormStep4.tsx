import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';

export function FormStep4() {
  const [image, setImage] = useState<string | null>(null);
  const [inputType, setInputType] = useState<'upload' | 'tulis'>('upload');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Uraian Tugas & Tanggung Jawab</h2>
        <div className="flex flex-col">
           <label className="text-sm font-medium text-gray-700 mb-2">Uraikan tugas dan tanggung jawab anda pada jabatan yang terakhir</label>
           <textarea 
              name="uraian_tugas"
              className="w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-4 min-h-[300px] leading-7" 
              placeholder="- Mengelola tim...&#10;- Bertanggung jawab atas penjualan...&#10;- Melaporkan progress..."
              required
           />
           <div className="text-xs text-gray-500 mt-2 italic">* Gunakan poin-poin untuk memudahkan pembacaan</div>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Struktur Organisasi</h2>
        <div className="flex flex-col">
           <label className="text-sm font-medium text-gray-700 mb-2">Gambarkan atau tuliskan struktur organisasi yang memperlihatkan posisi anda di tempat terakhir bekerja</label>
           
           <div className="flex items-center gap-4 mb-4">
              <label className="flex items-center gap-2 cursor-pointer">
                 <input type="radio" value="upload" checked={inputType === 'upload'} onChange={() => setInputType('upload')} name="struktur_method" /> Unggah Gambar
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                 <input type="radio" value="tulis" checked={inputType === 'tulis'} onChange={() => setInputType('tulis')} name="struktur_method" /> Tulis Teks
              </label>
           </div>
           
           {inputType === 'upload' ? (
              !image ? (
                <label 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-12 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 hover:border-blue-400 cursor-pointer transition-colors w-full"
                >
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileChange}
                    required={!image && inputType === 'upload'}
                  />
                  <Upload className="w-12 h-12 mb-4 text-gray-400" />
                  <p className="font-medium text-gray-700">Klik untuk mengunggah gambar struktur organisasi</p>
                  <p className="text-sm mt-1">PNG, JPG, max 5MB</p>
                </label>
              ) : (
                <div className="relative border rounded-lg overflow-hidden bg-gray-50">
                  <button type="button" 
                    onClick={() => setImage(null)}
                    className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-md hover:bg-gray-100 text-gray-600 transition"
                    title="Hapus gambar"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <img src={image} alt="Struktur Organisasi" className="w-full h-auto max-h-[500px] object-contain" />
                </div>
              )
           ) : (
              <textarea 
                 name="struktur_organisasi_teks"
                 className="w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 p-4 min-h-[200px]"
                 placeholder="Tuliskan struktur organisasi anda (contoh: General Manager -> Manager Produksi -> Supervisor -> Posisi Saya -> Staff)"
                 required={inputType === 'tulis'}
              />
           )}
        </div>
      </div>
    </div>
  );
}
