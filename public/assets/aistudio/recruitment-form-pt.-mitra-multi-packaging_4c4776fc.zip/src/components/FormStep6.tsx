import React, { useState, useEffect } from 'react';
import { Upload, FileText, Camera, Check, X } from 'lucide-react';

export function FormStep6() {
  const [cvName, setCvName] = useState<string | null>(null);
  const [fotoPreview, setFotoPreview] = useState<string | null>(null);
  const [fotoName, setFotoName] = useState<string | null>(null);

  useEffect(() => {
    // Sync with existing hidden values if available
    const existingFoto = (document.getElementById('base64_foto_data') as HTMLInputElement)?.value;
    const existingFotoName = (document.getElementById('foto_file_name') as HTMLInputElement)?.value;
    if (existingFoto) setFotoPreview(existingFoto);
    if (existingFotoName) setFotoName(existingFotoName);

    const existingCvName = (document.getElementById('cv_file_name') as HTMLInputElement)?.value;
    if (existingCvName) setCvName(existingCvName);
  }, []);

  const handleFotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (!file.type.startsWith('image/')) {
        alert('File harus berupa gambar (JPG, JPEG, PNG, WEBP)');
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        alert('Ukuran foto maksimal 10MB');
        return;
      }
      setFotoName(file.name);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setFotoPreview(base64);
        
        const hiddenInput = document.getElementById('base64_foto_data') as HTMLInputElement;
        const hiddenName = document.getElementById('foto_file_name') as HTMLInputElement;
        const hiddenMime = document.getElementById('foto_mime_type') as HTMLInputElement;
        
        if (hiddenInput) hiddenInput.value = base64;
        if (hiddenName) hiddenName.value = file.name;
        if (hiddenMime) hiddenMime.value = file.type;
      };
      reader.readAsDataURL(file);
    }
  };

  const removeFoto = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setFotoPreview(null);
    setFotoName(null);
    const hiddenInput = document.getElementById('base64_foto_data') as HTMLInputElement;
    const hiddenName = document.getElementById('foto_file_name') as HTMLInputElement;
    const hiddenMime = document.getElementById('foto_mime_type') as HTMLInputElement;
    if (hiddenInput) hiddenInput.value = '';
    if (hiddenName) hiddenName.value = '';
    if (hiddenMime) hiddenMime.value = '';
  };

  const handleCvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCvName(file.name);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const cvBase64 = event.target?.result as string;
        const hiddenInput = document.getElementById('base64_cv_data') as HTMLInputElement;
        const hiddenName = document.getElementById('cv_file_name') as HTMLInputElement;
        const hiddenMime = document.getElementById('cv_mime_type') as HTMLInputElement;
        
        if (hiddenInput) hiddenInput.value = cvBase64;
        if (hiddenName) hiddenName.value = file.name;
        if (hiddenMime) hiddenMime.value = file.type;
      };
      reader.readAsDataURL(file);
    }
  };

  const removeCv = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCvName(null);
    const hiddenInput = document.getElementById('base64_cv_data') as HTMLInputElement;
    const hiddenName = document.getElementById('cv_file_name') as HTMLInputElement;
    const hiddenMime = document.getElementById('cv_mime_type') as HTMLInputElement;
    if (hiddenInput) hiddenInput.value = '';
    if (hiddenName) hiddenName.value = '';
    if (hiddenMime) hiddenMime.value = '';
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-gray-900 border-b pb-2 mb-4">Upload Dokumen Pelamar</h2>
        
        {/* Hidden Storage Inputs */}
        <input type="hidden" id="base64_foto_data" name="foto_pelamar" />
        <input type="hidden" id="foto_file_name" />
        <input type="hidden" id="foto_mime_type" />

        <input type="hidden" id="base64_cv_data" name="cv_pelamar" />
        <input type="hidden" id="cv_file_name" />
        <input type="hidden" id="cv_mime_type" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Upload Pas Foto */}
            <div className="flex flex-col">
               <label className="text-sm font-semibold text-gray-800 mb-2 flex items-center justify-between">
                 <span>Pas Foto Pelamar <span className="text-red-500">* Wajib</span></span>
                 {fotoPreview && <span className="text-xs text-green-600 font-semibold flex items-center gap-1"><Check className="w-4 h-4" /> Terunggah</span>}
               </label>
               <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 flex flex-col items-center justify-center bg-gray-50 hover:bg-gray-100/80 transition-all h-64 relative overflow-hidden group">
                 {fotoPreview ? (
                   <div className="relative w-full h-full flex flex-col items-center justify-center">
                     <img src={fotoPreview} alt="Preview Foto Pelamar" className="max-h-44 max-w-full rounded-lg object-contain shadow-md border bg-white p-1" />
                     <p className="text-xs text-gray-600 truncate max-w-xs mt-2 font-medium">{fotoName}</p>
                     <button
                       type="button"
                       onClick={removeFoto}
                       className="absolute top-0 right-0 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow transition-transform hover:scale-110 z-30"
                       title="Hapus / Ganti Foto"
                     >
                       <X className="w-4 h-4" />
                     </button>
                   </div>
                 ) : (
                   <label className="w-full h-full flex flex-col items-center justify-center cursor-pointer">
                     <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                       <Camera className="w-7 h-7" />
                     </div>
                     <span className="text-gray-800 font-semibold text-sm text-center">Upload Pas Foto Terbaru</span>
                     <span className="text-xs text-gray-500 mt-1 text-center">Format: JPG, JPEG, PNG (Maks 10MB)</span>
                     <span className="mt-3 text-xs bg-blue-600 text-white px-3.5 py-1.5 rounded-full font-medium shadow-sm">Pilih Pas Foto</span>
                     <input type="file" accept="image/*" onChange={handleFotoChange} className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-20" required />
                   </label>
                 )}
               </div>
            </div>

            {/* Upload CV */}
            <div className="flex flex-col">
               <label className="text-sm font-semibold text-gray-800 mb-2 flex items-center justify-between">
                 <span>Curriculum Vitae (CV) <span className="text-red-500">* Wajib</span></span>
                 {cvName && <span className="text-xs text-green-600 font-semibold flex items-center gap-1"><Check className="w-4 h-4" /> Terunggah</span>}
               </label>
               <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 flex flex-col items-center justify-center bg-gray-50 hover:bg-gray-100/80 transition-all h-64 relative overflow-hidden group">
                 {cvName ? (
                   <div className="relative w-full h-full flex flex-col items-center justify-center p-4">
                     <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mb-3 shadow-sm">
                       <FileText className="w-8 h-8" />
                     </div>
                     <p className="text-sm font-semibold text-gray-800 text-center truncate max-w-xs">{cvName}</p>
                     <p className="text-xs text-green-600 font-medium mt-1">File Siap Terkirim</p>
                     <button
                       type="button"
                       onClick={removeCv}
                       className="absolute top-0 right-0 bg-red-500 hover:bg-red-600 text-white rounded-full p-1.5 shadow transition-transform hover:scale-110 z-30"
                       title="Hapus / Ganti CV"
                     >
                       <X className="w-4 h-4" />
                     </button>
                   </div>
                 ) : (
                   <label className="w-full h-full flex flex-col items-center justify-center cursor-pointer">
                     <div className="w-14 h-14 bg-red-100 text-red-600 rounded-full flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                       <Upload className="w-7 h-7" />
                     </div>
                     <span className="text-gray-800 font-semibold text-sm text-center">Upload Curriculum Vitae (CV)</span>
                     <span className="text-xs text-gray-500 mt-1 text-center">Format: PDF (Maks 10MB)</span>
                     <span className="mt-3 text-xs bg-red-600 text-white px-3.5 py-1.5 rounded-full font-medium shadow-sm">Pilih File PDF</span>
                     <input type="file" accept=".pdf" onChange={handleCvChange} className="opacity-0 absolute inset-0 w-full h-full cursor-pointer z-20" required />
                   </label>
                 )}
               </div>
            </div>
        </div>
      </div>
    </div>
  );
}


