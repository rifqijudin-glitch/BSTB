import fs from "fs";

let text = fs.readFileSync("src/pages/DashboardPage.tsx", "utf-8");

// 1. Add state for advanced filters
const stateAdditionPattern = "const [appliedSelectedSkills, setAppliedSelectedSkills] = useState<string[]>([]);";
if (!text.includes(stateAdditionPattern)) {
    text = text.replace(
        "const [activeTab, setActiveTab] = useState('dashboard');",
        `const [eduFilters, setEduFilters] = useState<{tingkat: string, jurusan: string}[]>([]);\n  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);\n  const [appliedEduFilters, setAppliedEduFilters] = useState<{tingkat: string, jurusan: string}[]>([]);\n  const [appliedSelectedSkills, setAppliedSelectedSkills] = useState<string[]>([]);\n\n  const activeEduLevels = ['SD', 'SLTP', 'SLTA/SMU', 'D1/D2/D3', 'S1', 'S2/S3'];\n\n  const [activeTab, setActiveTab] = useState('dashboard');`
    );
}

// 2. Adjust filteredApplicants memo
const oldMemo = `  const filteredApplicants = useMemo(() => {
    return applicants.filter(app => {
      const matchSearch = searchTerm === '' || 
                          app.nama.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          app.kode.toLowerCase().includes(searchTerm.toLowerCase());
      const matchPosisi = posisiFilter === '' || app.posisi.toLowerCase().includes(posisiFilter.toLowerCase());
      return matchSearch && matchPosisi;
    });
  }, [applicants, searchTerm, posisiFilter]);`;

const newMemo = `  const filteredApplicants = useMemo(() => {
    return applicants.filter(app => {
      const matchSearch = searchTerm === '' || 
                          app.nama.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          app.kode.toLowerCase().includes(searchTerm.toLowerCase());
      const matchPosisi = posisiFilter === '' || app.posisi.toLowerCase().includes(posisiFilter.toLowerCase());
      
      let matchEdu = true;
      if (appliedEduFilters.length > 0) {
         const eduText = app.rawData && app.rawData['Riwayat Pendidikan Formal '];
         if (eduText) {
             const rows = eduText.split('\\n');
             matchEdu = appliedEduFilters.some(filter => {
                return rows.some((row: string) => {
                   const cols = row.split(' | ');
                   if (cols.length >= 4) {
                       const tingkatMatch = !filter.tingkat || filter.tingkat === 'Semua' || cols[0].trim() === filter.tingkat;
                       const jurusanMatch = !filter.jurusan || cols[3].toLowerCase().includes(filter.jurusan.toLowerCase());
                       return tingkatMatch && jurusanMatch;
                   }
                   return false;
                });
             });
         } else {
             matchEdu = false;
         }
      }

      let matchSkills = true;
      if (appliedSelectedSkills.length > 0) {
         const skillText = app.rawData && app.rawData['Teknikal / Hardskill'];
         if (skillText) {
             matchSkills = appliedSelectedSkills.every(s => skillText.toLowerCase().includes(s.toLowerCase()));
         } else {
             matchSkills = false;
         }
      }
      
      return matchSearch && matchPosisi && matchEdu && matchSkills;
    });
  }, [applicants, searchTerm, posisiFilter, appliedEduFilters, appliedSelectedSkills]);`;

if (text.includes(oldMemo)) {
    text = text.replace(oldMemo, newMemo);
}

// 3. Reset filters on handleHapusFilter
const oldHapus = `  const handleHapusFilter = () => {
    setPosisiFilterDropdown('');
    setPosisiFilter('');
    setSearchTerm('');
  };`;

const newHapus = `  const handleHapusFilter = () => {
    setPosisiFilterDropdown('');
    setPosisiFilter('');
    setSearchTerm('');
    setAppliedEduFilters([]);
    setEduFilters([]);
    setAppliedSelectedSkills([]);
    setSelectedSkills([]);
  };`;

if (text.includes(oldHapus)) {
    text = text.replace(oldHapus, newHapus);
}


fs.writeFileSync("src/pages/DashboardPage.tsx", text);
