import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAxEEVEZ4Qu8MSPV2ThNTxuPgXqOyclN2c",
  authDomain: "mmp-recruitment.firebaseapp.com",
  projectId: "mmp-recruitment",
  storageBucket: "mmp-recruitment.firebasestorage.app",
  messagingSenderId: "935811814528",
  appId: "1:935811814528:web:b4e3e1fa24e3eb5b3e0265",
  measurementId: "G-JG1DG6WDVR"
};

const app = initializeApp(firebaseConfig);
let analytics;
// Only initialize analytics in browser environment
if (typeof window !== "undefined") {
  analytics = getAnalytics(app);
}
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);

export { app, analytics, db, auth, storage };
