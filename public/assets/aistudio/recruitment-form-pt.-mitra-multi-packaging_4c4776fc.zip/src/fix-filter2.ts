import fs from "fs";

let text = fs.readFileSync("src/pages/DashboardPage.tsx", "utf-8");

const oldModalContent = `                  {/* Education */}
                  <div>
                     <div className="flex justify-between items-center mb-2">
                        <h4 className="font-bold text-gray-700">Education</h4>
                        <ChevronDown className="w-4 h-4 text-gray-400" />
                     </div>
                     <div className="space-y-2">
                        <label className="flex items-center gap-2"><input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" /> <span className="text-gray-600">SMU</span> <span className="text-xs text-gray-400 ml-auto">(2)</span></label>
                        <button className="flex items-center gap-1 text-gray-500 hover:text-blue-600 mt-1"><Plus className="w-3 h-3" /> Add</button>
                     </div>
                  </div>

                                    {/* Skills */}
                  <div>
                     <div className="flex justify-between items-center mb-2">
                        <h4 className="font-bold text-gray-700">Skills</h4>
                        <ChevronDown className="w-4 h-4 text-gray-400" />
                     </div>
                     <div className="space-y-2">
                        {skillList.map(skill => (
                           <label key={skill} className="flex items-center gap-2"><input type="checkbox" className="rounded text-blue-600 focus:ring-blue-500" /> <span className="text-gray-600">{skill}</span></label>
                        ))}
                     </div>
                  </div>`;

const newModalContent = `                  {/* Education Filter */}
                  <div>
                     <div className="flex justify-between items-center mb-4">
                        <h4 className="font-bold text-gray-700">Pendidikan & Jurusan</h4>
                     </div>
                     
                     <div className="space-y-3">
                         {eduFilters.map((ef, idx) => (
                             <div key={idx} className="flex flex-col gap-2 p-2 border border-blue-100 rounded bg-blue-50/20 relative">
                                 <button onClick={() => setEduFilters(eduFilters.filter((_, i) => i !== idx))} className="absolute top-1 right-1 text-gray-400 hover:text-red-500 p-1">
                                    <X className="w-3.5 h-3.5" />
                                 </button>
                                 <div className="flex flex-col mt-3">
                                     <label className="text-xs text-gray-500">Tingkat Pendidikan</label>
                                     <select 
                                        value={ef.tingkat} 
                                        onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, tingkat: e.target.value} : f))}
                                        className="border-gray-200 rounded px-2 py-1 text-sm outline-none w-full bg-white mt-1 border"
                                     >
                                         <option value="Semua">Semua Tingkat</option>
                                         {activeEduLevels.map(lvl => <option key={lvl} value={lvl}>{lvl}</option>)}
                                     </select>
                                 </div>
                                 <div className="flex flex-col">
                                     <label className="text-xs text-gray-500">Ketik Jurusan (mengandung kata)</label>
                                     <input 
                                        type="text"
                                        placeholder="Min. ketik kata kunci..."
                                        value={ef.jurusan}
                                        onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))}
                                        className="border-gray-200 rounded px-2 py-1 text-sm outline-none w-full bg-white mt-1 border"
                                     />
                                 </div>
                             </div>
                         ))}
                         
                         <button onClick={() => setEduFilters([...eduFilters, { tingkat: 'Semua', jurusan: '' }])} className="flex items-center gap-1 text-blue-600 hover:text-blue-700 mt-2 text-sm font-medium">
                             <Plus className="w-4 h-4" /> Tambah Filter Pendidikan
                         </button>
                     </div>
                  </div>

                  {/* Skills */}
                  <div className="mt-6 pt-4 border-t border-gray-100">
                     <div className="flex justify-between items-center mb-3">
                        <h4 className="font-bold text-gray-700">Skills (Harus memiliki)</h4>
                     </div>
                     <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                        {skillList.map(skill => (
                           <label key={skill} className="flex items-center gap-2 cursor-pointer">
                              <input 
                                 type="checkbox" 
                                 checked={selectedSkills.includes(skill)}
                                 onChange={(e) => {
                                     if(e.target.checked) setSelectedSkills([...selectedSkills, skill]);
                                     else setSelectedSkills(selectedSkills.filter(s => s !== skill));
                                 }}
                                 className="rounded border-gray-300 text-blue-600 focus:ring-blue-500" 
                              /> 
                              <span className="text-sm text-gray-600">{skill}</span>
                           </label>
                        ))}
                     </div>
                  </div>`;
                  
if(text.includes(oldModalContent)) {
    text = text.replace(oldModalContent, newModalContent);
}

// Update apply button
const oldApply = `<button onClick={() => setIsFilterModalOpen(false)} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Terapkan Filter</button>`;
const newApply = `<button onClick={() => {
                     setAppliedEduFilters([...eduFilters]);
                     setAppliedSelectedSkills([...selectedSkills]);
                     setIsFilterModalOpen(false);
                  }} className="px-4 py-2 bg-blue-600 text-white rounded font-medium hover:bg-blue-700">Terapkan Filter</button>`;
                  
if(text.includes(oldApply)) {
    text = text.replace(oldApply, newApply);
}

fs.writeFileSync("src/pages/DashboardPage.tsx", text);
