import fs from "fs";
let f = fs.readFileSync("src/components/FormStep2.tsx", "utf8");

const defaultSkills = ["Microsoft Office", "Finance", "B2B Sales", "Printing", "Extrusion", "Dry", "Quality Control", "Laboratorium", "Slitting", "Bag Making", "Warehouse", "PPIC", "Procurement"];

const startGrid = f.indexOf("<div className=\"flex-1 grid grid-cols-2 md:grid-cols-5 gap-4\">");
const endGrid = f.indexOf("</div>\n           </div>\n        </div>\n\n      <div>\n        <div className=\"border-b pb-2 mb-4 mt-8\">");

if (startGrid !== -1 && endGrid !== -1) {
    const rawList = `           <div className="flex-1 grid grid-cols-2 md:grid-cols-5 gap-4">
               {(() => {
                   let skills = ${JSON.stringify(defaultSkills)};
                   try {
                       const saved = localStorage.getItem('setting_skill');
                       if (saved) skills = JSON.parse(saved);
                   } catch (e) {}

                   return skills.map((skill: string) => (
                       <label key={skill} className="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer mb-3">
                           <input type="checkbox" name="hardskill" value={skill} className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" />
                           <span>{skill}</span>
                       </label>
                   ));
               })()}
            `;
    f = f.slice(0, startGrid) + rawList + f.slice(endGrid);
}

fs.writeFileSync("src/components/FormStep2.tsx", f);
