const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');
code = code.replace(/<Edit className="w-6 h-6" \/>/, '');
code = code.replace(/<\/div>\n<\/nav>/, '<\/nav>');
// Let's run a TS checker
fs.writeFileSync('src/pages/DashboardPage.tsx', code);
