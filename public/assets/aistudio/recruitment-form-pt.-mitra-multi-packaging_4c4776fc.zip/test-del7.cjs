const ts = '6/3/2026, 15:47:29';
fetch('https://sheetdb.io/api/v1/g6pseexgmqoyq/Timestamp (Waktu Submit)/' + encodeURIComponent(ts) + '?clear_empty=true', {method: 'DELETE'})
  .then(r=>r.json())
  .then(console.log);
