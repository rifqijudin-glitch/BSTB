const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const listSMU = [
    "MIPA", "IPS", "Ekonomi", "Bahasa dan Budaya", "Teknik Konstruksi dan Perumahan",
    "Teknik Geomatika dan Geospasial", "Teknik Ketenagalistrikan", "Teknik Mesin",
    "Teknik Otomotif", "Teknik Elektronika", "Teknik Perkapalan",
    "Pengembangan Perangkat Lunak dan Gim (PPLG)", "Teknik Jaringan Komputer dan Telekomunikasi (TJKT)",
    "Layanan Kesehatan", "Farmasi", "Pekerjaan Sosial", "Akuntansi dan Keuangan Lembaga (AKL)",
    "Manajemen Perkantoran dan Layanan Bisnis (MPLB)", "Pemasaran", "Kuliner", "Perhotelan",
    "Usaha Layanan Pariwisata", "Tata Kecantikan dan Rambut", "Tata Busana",
    "Desain Komunikasi Visual (DKV)", "Animasi", "Penyiaran dan Produksi Film",
    "Seni Pertunjukan", "Kriya Kreatif", "Agribisnis Tanaman", "Agribisnis Ternak",
    "Agriteknologi Pengolahan Hasil Pertanian (APHP)", "Kehutanan",
    "Nautika Kapal Penangkap Ikan / Niaga", "Teknika Kapal Penangkap Ikan / Niaga",
    "Agribisnis Perikanan", "Teknik Perminyakan", "Teknik Pertambangan", "Teknik Kimia Industri", "Lainnya"
];

const listS1 = [
    "Pendidikan Dokter", "Pendidikan Dokter Gigi", "Kedokteran Hewan", "Ilmu Keperawatan",
    "Kebidanan", "Farmasi", "Kesehatan Masyarakat", "Gizi Kesehatan", "Fisioterapi",
    "Okupasi Terapi", "Sains Kedokteran Tropis", "Keselamatan dan Kesehatan Kerja",
    "Teknik Sipil", "Teknik Arsitektur", "Teknik Mesin", "Teknik Elektro", "Teknik Kimia",
    "Teknik Industri", "Teknik Lingkungan", "Teknik Perencanaan Wilayah dan Kota",
    "Teknik Metalurgi dan Material", "Teknik Dirgantara", "Teknik Kelautan", "Teknik Nuklir",
    "Teknik Biomedis", "Teknik Informatika", "Sistem Informasi", "Ilmu Komputer", "Sains Data",
    "Keamanan Siber", "Rekayasa Perangkat Lunak", "Matematika", "Fisika", "Kimia", "Biologi",
    "Astronomi", "Geofisika", "Meteorologi", "Statistika", "Aktuaria", "Agroteknologi",
    "Agribisnis", "Ilmu Kelautan", "Oseanografi", "Teknologi Pangan",
    "Manajemen Sumberdaya Perairan", "Kehutanan", "Hubungan Internasional", "Ilmu Komunikasi",
    "Jurnalistik", "Penyiaran", "Hubungan Masyarakat", "Ilmu Pemerintahan", "Ilmu Politik",
    "Sosiologi", "Antropologi Sosial", "Ilmu Administrasi Publik", "Ilmu Administrasi Bisnis",
    "Kriminologi", "Psikologi", "Akuntansi", "Manajemen", "Manajemen Keuangan",
    "Manajemen Pemasaran", "Manajemen Sumber Daya Manusia", "Ilmu Ekonomi",
    "Ekonomi Pembangunan", "Ekonomi Syariah", "Perbankan Syariah", "Ilmu Hukum",
    "Hukum Perdata", "Hukum Pidana", "Hukum Internasional", "Hukum Tata Negara",
    "Sastra Inggris", "Sastra Indonesia", "Sastra Jepang", "Sastra Arab", "Sastra Korea",
    "Sastra Mandarin", "Linguistik", "Ilmu Sejarah", "Arkeologi", "Ilmu Filsafat",
    "Desain Interior", "Desain Produk", "Seni Rupa Murni", "Fotografi", "Etnomusikologi",
    "Penciptaan Musik", "Seni Teater", "Pendidikan Guru Sekolah Dasar",
    "Pendidikan Guru Anak Usia Dini", "Pendidikan Luar Biasa", "Bimbingan dan Konseling",
    "Pendidikan Bahasa Indonesia", "Pendidikan Bahasa Inggris", "Pendidikan Matematika",
    "Pendidikan Fisika", "Pendidikan Kimia", "Pendidikan Biologi", "Pendidikan Sejarah",
    "Pendidikan Geografi", "Pendidikan Ekonomi", "Lainnya"
];

const listS2 = [
    "Magister Manajemen", "Magister Hukum", "Magister Ilmu Komunikasi",
    "Magister Administrasi Publik", "Magister Teknik Sipil", "Magister Kenotariatan",
    "Magister Psikologi Profesi", "Doktor Ilmu Hukum", "Doktor Ilmu Ekonomi",
    "Doktor Ilmu Manajemen", "Doktor Ilmu Sosial", "Lainnya"
];

const definitionList = `
const JURUSAN_SMU = ${JSON.stringify(listSMU)};
const JURUSAN_S1 = ${JSON.stringify(listS1)};
const JURUSAN_S2 = ${JSON.stringify(listS2)};
`;

code = code.replace(/import \{ Link \} from 'react-router-dom';/, "import { Link } from 'react-router-dom';\n" + definitionList);

const oldSelect = /<select value=\{ef\.jurusan\}[^>]*>\s*<option value="">Semua Jurusan<\/option>\s*\{activeJurusanList\.map\(jur => <option key=\{jur\} value=\{jur\}>\{jur\}<\/option>\)\}\s*<\/select>/;

const newSelect = `
                                     {ef.tingkat === 'SLTA/SMU' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_SMU.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : (ef.tingkat === 'S1' || ef.tingkat === 'D1/D2/D3') ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_S1.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : ef.tingkat === 'S2/S3' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {JURUSAN_S2.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : ef.tingkat === 'Semua' ? (
                                        <select value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border">
                                           <option value="">Semua Jurusan</option>
                                           {activeJurusanList.map(jur => <option key={jur} value={jur}>{jur}</option>)}
                                        </select>
                                     ) : (
                                        <input type="text" value={ef.jurusan} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))} placeholder="Ketik jurusan..." className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border" />
                                     )}
`;

code = code.replace(oldSelect, newSelect.trim());

code = code.replace(/<select value=\{ef\.tingkat\} onChange=\{\(e\) => setEduFilters\(eduFilters\.map\(\(f, i\) => i === idx \? \{\.\.\.f, tingkat: e\.target\.value\} : f\)\)\} className="border-gray-300 rounded px-2 py-1\.5 outline-none bg-white border">/, '<select value={ef.tingkat} onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, tingkat: e.target.value, jurusan: ""} : f))} className="border-gray-300 rounded px-2 py-1.5 outline-none bg-white border">');

fs.writeFileSync('src/pages/DashboardPage.tsx', code);
