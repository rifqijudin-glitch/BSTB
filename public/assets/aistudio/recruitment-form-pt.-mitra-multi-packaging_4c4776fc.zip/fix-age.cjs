const fs = require('fs');
let text = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const parseDOBFunc = `
function parseDOB(dateStr: string): Date {
   let d = new Date(dateStr);
   if (!isNaN(Number(dateStr)) && Number(dateStr) > 10000 && Number(dateStr) < 100000) {
      d = new Date(Math.round((Number(dateStr) - 25569) * 86400 * 1000));
   }
   return d;
}
`;

text = text.replace(
  `const formatTanggalIndo = (dateStr: string) => {`,
  `${parseDOBFunc}\nconst formatTanggalIndo = (dateStr: string) => {`
);

text = text.replaceAll(
  `const birthDate = new Date(item["Tanggal Lahir"]);`,
  `const birthDate = parseDOB(item["Tanggal Lahir"]);`
);

fs.writeFileSync('src/pages/DashboardPage.tsx', text);
