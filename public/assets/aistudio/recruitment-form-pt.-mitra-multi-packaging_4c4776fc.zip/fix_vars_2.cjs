const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const regex1 = /const activeJurusanList = useMemo\(\(\) => \{.+?\}, \[applicants\]\);/s;
const match1 = code.match(regex1);
if (match1) {
    code = code.replace(match1[0], '');
    code = code.replace(/const \[applicants, setApplicants\] = useState<any\[\]>\(\[\]\);/, "const [applicants, setApplicants] = useState<any[]>([]);\n\n" + match1[0]);
}

const regex2 = /const skillList = useMemo\(\(\) => \{.+?\}, \[applicants\]\);/s;
const match2 = code.match(regex2);
if (match2) {
    code = code.replace(match2[0], '');
    code = code.replace(/const \[applicants, setApplicants\] = useState<any\[\]>\(\[\]\);/, "const [applicants, setApplicants] = useState<any[]>([]);\n\n" + match2[0]);
}

fs.writeFileSync('src/pages/DashboardPage.tsx', code);
