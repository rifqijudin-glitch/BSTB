const fs = require('fs');
let c2 = fs.readFileSync('src/components/FormStep2.tsx', 'utf8');

const yearOptions = `<option value=""></option>` + Array.from({length: 50}, (_, i) => new Date().getFullYear() - i).map(y => `<option value="${y}">${y}</option>`).join('');

c2 = c2.replace(
  /<td className="border p-0 w-\[80px\]"><input type="text" maxLength=\{4\} onInput=\{\(e\) => \{ e.currentTarget.value = e.currentTarget.value.replace\(\/\[\^0-9\]\/g, ''\); \}\} className="w-full px-2 py-1.5 outline-none focus:bg-blue-50 text-center" \/><\/td>/g,
  `<td className="border p-0 w-[80px]"><select className="w-full px-2 py-1.5 outline-none focus:bg-blue-50 text-center cursor-pointer appearance-none bg-transparent">${yearOptions}</select></td>`
);

c2 = c2.replace(
  /<td className="border-r p-1"><input type="text" maxLength=\{4\} onInput=\{\(e\) => \{ e.currentTarget.value = e.currentTarget.value.replace\(\/\[\^0-9\]\/g, ''\); \}\} className="w-full px-2 py-1.5 outline-none bg-transparent text-center" \/><\/td>/g,
  `<td className="border-r p-1"><select className="w-full px-2 py-1.5 outline-none bg-transparent text-center cursor-pointer appearance-none">${yearOptions}</select></td>`
);

fs.writeFileSync('src/components/FormStep2.tsx', c2);

let c3 = fs.readFileSync('src/components/FormStep3.tsx', 'utf8');

const monthOptions = `
<option value=""></option>
<option value="Januari">Jan</option>
<option value="Februari">Feb</option>
<option value="Maret">Mar</option>
<option value="April">Apr</option>
<option value="Mei">Mei</option>
<option value="Juni">Jun</option>
<option value="Juli">Jul</option>
<option value="Agustus">Agu</option>
<option value="September">Sep</option>
<option value="Oktober">Okt</option>
<option value="November">Nov</option>
<option value="Desember">Des</option>
`.replace(/\n/g, '');

c3 = c3.replace(
  /<input type="text" maxLength=\{2\} onInput=\{\(e\) => \{ let val = e.currentTarget.value.replace\(\/\[\^0-9\]\/g, ''\); if\(val && parseInt\(val\) > 12\) val = '12'; e.currentTarget.value = val; \}\} className="flex-1 text-sm outline-none px-1 py-1" placeholder="MM" \/>/g,
  `<select className="flex-1 text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent">${monthOptions}</select>`
);

c3 = c3.replace(
  /<input type="text" maxLength=\{4\} onInput=\{\(e\) => \{ e.currentTarget.value = e.currentTarget.value.replace\(\/\[\^0-9\]\/g, ''\); \}\} className="w-full text-sm outline-none px-1 py-1" placeholder="YYYY" \/>/g,
  `<select className="w-full text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent">${yearOptions}</select>`
);

// Specifically for referensi
c3 = c3.replace(
  /<td className="border-r p-1"><input type="text" onInput=\{\(e\) => \{ e.currentTarget.value = e.currentTarget.value.replace\(\/\[\^0-9\]\/g, ''\); \}\} className="w-full px-2 py-1.5 outline-none bg-transparent" \/><\/td>/g,
  `<td className="border-r p-1"><input type="text" maxLength={14} minLength={9} onInput={(e) => { e.currentTarget.value = e.currentTarget.value.replace(/[^0-9]/g, ''); }} className="w-full px-2 py-1.5 outline-none bg-transparent" placeholder="08xxxxxxxxxx" /></td>`
);

fs.writeFileSync('src/components/FormStep3.tsx', c3);
console.log('done replacing step2 & step3');
