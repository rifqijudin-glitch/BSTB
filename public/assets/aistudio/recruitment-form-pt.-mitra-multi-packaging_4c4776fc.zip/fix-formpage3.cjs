const fs = require('fs');
let text = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

text = text.replaceAll(
    `isFieldRequired = false;
             undefined
                 input.required = isFieldRequired;
             }`,
    `isFieldRequired = false;
             } else if (input.name === 'jurusan_sd_smp') {
                isFieldRequired = false;
             }
             if (input.hasAttribute('disabled')) isFieldRequired = false;
             if (input.type !== 'checkbox' && input.type !== 'file') {
                 input.required = isFieldRequired;
             }`
);

fs.writeFileSync('src/pages/FormPage.tsx', text);
