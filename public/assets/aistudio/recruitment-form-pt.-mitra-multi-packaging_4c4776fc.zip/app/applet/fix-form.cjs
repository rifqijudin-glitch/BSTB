const fs = require('fs');

// --- FormStep2 Fixes ---
let c2 = fs.readFileSync('src/components/FormStep2.tsx', 'utf8');

c2 = c2.replace(/<select className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_smu">\n\s*<option value="">-- Pilih Jurusan --<\/option>([\s\S]*?)<\/select>/g, (match, options) => {
    return `<input type="text" list="jurusan_smu_list" className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_smu" placeholder="-- Ketik/Pilih Jurusan --" />
                                <datalist id="jurusan_smu_list">${options}</datalist>`;
});

c2 = c2.replace(/<select className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_s1">\n\s*<option value="">-- Pilih Jurusan --<\/option>([\s\S]*?)<\/select>/g, (match, options) => {
    return `<input type="text" list="jurusan_s1_list" className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" name="jurusan_s1" placeholder="-- Ketik/Pilih Jurusan --" />
                                <datalist id="jurusan_s1_list">${options}</datalist>`;
});

c2 = c2.replace(/<select className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50">\n\s*<option value="">-- Pilih Jurusan --<\/option>([\s\S]*?)<\/select>/g, (match, options) => {
    return `<input type="text" list="jurusan_pilihan_list" className="w-full px-2 py-1.5 outline-none bg-transparent text-sm focus:bg-blue-50" placeholder="-- Ketik/Pilih Jurusan --" />
                                <datalist id="jurusan_pilihan_list">${options}</datalist>`;
});

const oldOnInput = `e.currentTarget.value = e.currentTarget.value.replace(/[^a-zA-Z\\s]/g, '');`;
const newOnInput = `let val = e.currentTarget.value.replace(/[^a-zA-Z0-9\\s]/g, ''); val = val.replace(/^[^a-zA-Z]+/, ''); e.currentTarget.value = val;`;

c2 = c2.split(oldOnInput).join(newOnInput);

fs.writeFileSync('src/components/FormStep2.tsx', c2);

// --- FormStep3 Fixes ---
let c3 = fs.readFileSync('src/components/FormStep3.tsx', 'utf8');

if (!c3.includes('masihBekerja: false')) {
  c3 = c3.replace(
      `const [pekerjaans, setPekerjaans] = useState([\n    { id: 1 }\n  ]);`,
      `const [pekerjaans, setPekerjaans] = useState<any[]>([\n    { id: 1, masihBekerja: false }\n  ]);`
  );
  
  c3 = c3.replace(
      `setPekerjaans([...pekerjaans, { id: Date.now() }]);`,
      `setPekerjaans([...pekerjaans, { id: Date.now(), masihBekerja: false }]);`
  );

  const toggleFunction = `  const toggleMasihBekerja = (id: number) => {
    setPekerjaans(pekerjaans.map(p => p.id === id ? { ...p, masihBekerja: !p.masihBekerja } : p));
  };
  
  const addPekerjaan = () => {`;
  c3 = c3.replace('  const addPekerjaan = () => {', toggleFunction);
}

const rgxSampaiBlock = /                             <span className="text-xs text-gray-500 w-10 px-1 truncate" title="Sampai">Smpai<\/span>\n                            <select className="flex-1 text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent">([\s\S]*?)<\/select>\n                         <\/div>\n                         <div className="w-1\/2 p-1">\n                            <select className="w-full text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent">([\s\S]*?)<\/select>/g;
c3 = c3.replace(rgxSampaiBlock, 
  `                             <span className="text-xs text-gray-500 w-10 px-1 truncate" title="Sampai">Smpai</span>
                            <select disabled={p.masihBekerja} className="flex-1 text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent disabled:opacity-30">$1</select>
                         </div>
                         <div className="w-1/2 p-1">
                            <select disabled={p.masihBekerja} className="w-full text-sm outline-none px-1 py-1 cursor-pointer appearance-none bg-transparent disabled:opacity-30">$2</select>`
);

const masihBekerjaCheckbox = `
                      <div className="p-2 border-t flex items-center gap-2">
                         <input type="checkbox" id={"masih-bekerja-"+p.id} checked={p.masihBekerja || false} onChange={() => toggleMasihBekerja(p.id)} className="cursor-pointer" />
                         <label htmlFor={"masih-bekerja-"+p.id} className="text-xs text-gray-600 cursor-pointer">Masih Bekerja</label>
                      </div>`;
c3 = c3.replace(
  /                      <\/div>\n                   <\/div>\n                   <div className="md:col-span-9 flex flex-col">/g,
  `                      </div>${masihBekerjaCheckbox}\n                   </div>\n                   <div className="md:col-span-9 flex flex-col">`
);

fs.writeFileSync('src/components/FormStep3.tsx', c3);
console.log('Fixed FormStep2 and FormStep3');
