import React from 'react';

export const LogoMMP = ({ className = "" }: { className?: string }) => {
  return (
    <svg viewBox="0 0 500 120" xmlns="http://www.w3.org/2000/svg" className={className}>
      {/* Target Logo Design: 
          Left: dots logo (cyan outer, magenta next, yellow next, black inner)
          Right: "mitra multi packaging" and "Flexible Packaging Manufacturer"
      */}
      <g transform="translate(60, 60)">
        {/* Ring 1: Black (offset slightly) */}
        {[...Array(8)].map((_, i) => {
          const angle = (i * Math.PI * 2) / 8;
          return <circle key={'b'+i} cx={Math.cos(angle) * 12} cy={Math.sin(angle) * 12} r="3.5" fill="#1b1b1b" />;
        })}
        {/* Ring 2: Yellow */}
        {[...Array(12)].map((_, i) => {
          const angle = (i * Math.PI * 2) / 12 + (Math.PI/12);
          return <circle key={'y'+i} cx={Math.cos(angle) * 22} cy={Math.sin(angle) * 22} r="4" fill="#fdec00" />;
        })}
        {/* Ring 3: Magenta */}
        {[...Array(12)].map((_, i) => {
          const angle = (i * Math.PI * 2) / 12;
          return <circle key={'m'+i} cx={Math.cos(angle) * 34} cy={Math.sin(angle) * 34} r="5" fill="#df007a" />;
        })}
        {/* Ring 4: Cyan */}
        {[...Array(16)].map((_, i) => {
          const angle = ((i + 0.5) * Math.PI * 2) / 16;
          return <circle key={'c'+i} cx={Math.cos(angle) * 48} cy={Math.sin(angle) * 48} r="6" fill="#00a7e6" />;
        })}
      </g>
      <text x="130" y="55" fontFamily="Inter, sans-serif" fontSize="42" fontWeight="400" letterSpacing="-1" fill="#1b1b1b">mitra multi packaging</text>
      <text x="135" y="85" fontFamily="Inter, sans-serif" fontSize="16" fontWeight="300" letterSpacing="4" fill="#4a4a4a">Flexible Packaging Manufacturer</text>
    </svg>
  );
};
