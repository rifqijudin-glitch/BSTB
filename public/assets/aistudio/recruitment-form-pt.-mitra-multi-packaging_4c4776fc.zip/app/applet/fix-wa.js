const fs = require('fs');
let c = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

c = c.replace(/https:\/\/wa\.me\/\$\{app\.telpHP\}/g, 'https://wa.me/${formatWhatsAppNumber(app.telpHP)}');
c = c.replace(/https:\/\/wa\.me\/\$\{selectedApplicant\.telpHP\}/g, 'https://wa.me/${formatWhatsAppNumber(selectedApplicant.telpHP)}');

fs.writeFileSync('src/pages/DashboardPage.tsx', c);
