const fs = require('fs');

let c = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

c = c.replace(/status: overrides\[index \+ 1\] \|\| "Kirim WA",/g, 'status: item["Status"] || overrides[index + 1] || "Kirim WA",\n              note: item["Notes"] || JSON.parse(localStorage.getItem(\'statusNotes\') || \'{}\')[index + 1] || "",');

const updateStatusCode = `                      const rawTimestamp = app?.rawData?.["Timestamp (Waktu Submit)"];
                      if (rawTimestamp) {
                          fetch(\`https://sheetdb.io/api/v1/g6pseexgmqoyq/Timestamp (Waktu Submit)/\${encodeURIComponent(rawTimestamp)}\`, {
                              method: 'PATCH',
                              headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
                              body: JSON.stringify({ data: { "Status": updateStatusVal, "Notes": updateStatusNote || "" } })
                          }).catch(err => console.error("Failed to sync status", err));
                      }
                      
                      setOpenStatusModalId(null);`;

// find the exact block for update Status
c = c.replace(/setOpenStatusModalId\(null\);/g, updateStatusCode);

fs.writeFileSync('src/pages/DashboardPage.tsx', c);
console.log("Successfully updated DashboardPage.tsx");
