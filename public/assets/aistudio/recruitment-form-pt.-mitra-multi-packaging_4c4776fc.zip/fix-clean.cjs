const fs = require('fs');
let c = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

const regex = /<button onClick=\{\(\) => \{\n\s*setUpdateStatusVal\(''\);\n\s*setUpdateStatusNote\(''\);\n\s*setGeneratedMessage\(''\);[\s\S]*?setOpenStatusModalId\(null\);\n\s*\}\} className="text-white\/80 hover:text-white">/g;

c = c.replace(regex, `<button onClick={() => {
                     setUpdateStatusVal('');
                     setUpdateStatusNote('');
                     setGeneratedMessage('');
                     setOpenStatusModalId(null);
                  }} className="text-white/80 hover:text-white">`);

fs.writeFileSync('src/pages/DashboardPage.tsx', c);
console.log('Cleaned X button');
