const fs = require('fs');
let code = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

const regex = /const payload = \{/;

const replacement = `const serializeKuesionerTable = () => {
           let rows = [];
           const questionsList = [
              "Apakah anda bersedia menjalani masa percobaan 3 bulan ?",
              "Apakah anda bersedia memberikan waktu selambat-lambatnya 2 bulan bagi perusahaan jika anda mengundurkan diri ?",
              "Apakah anda terikat kontrak dengan perusahaan tempat anda bekerja saat ini ?",
              "Apakah anda bersedia dimutasikan ?",
              "Apakah anda memiliki pekerjaan sampingan?",
              "Apakah anda mempunyai teman/sanak saudara di perusahaan ini?",
              "Apakah anda pernah menderita sakit kronis/kecelakaan ?",
              "Apakah anda sedang hamil ?",
              "Apakah anda bersedia tidak hamil dalam 1 tahun?",
              "Bersedia ditempatkan diluar kota ?"
           ];
           for (let i = 0; i < 10; i++) {
              if (rawData[\`q_\${i}\`]) {
                 rows.push(\`\${questionsList[i]} | \${rawData[\`q_\${i}\`]} | \${rawData[\`q_expl_\${i}\`] || '-'}\`);
              }
           }
           if (rows.length === 0) return "-";
           return "Pertanyaan | Ya/Tidak | Penjelasan Tambahan\\n" + rows.join('\\n');
        };

        const payload = {`;

code = code.replace(regex, replacement);

const payloadRegex = /"Kuesioner - Bersedia masa percobaan 3 bulan": rawData\["q_0"\] \? \(rawData\["q_0"\] \+ \(rawData\["q_expl_0"\] \? \` - \$\{rawData\["q_expl_0"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Bersedia memberikan waktu 2 bulan bila mengundurkan diri": rawData\["q_1"\] \? \(rawData\["q_1"\] \+ \(rawData\["q_expl_1"\] \? \` - \$\{rawData\["q_expl_1"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Terikat kontrak dengan perusahaan saat ini": rawData\["q_2"\] \? \(rawData\["q_2"\] \+ \(rawData\["q_expl_2"\] \? \` - \$\{rawData\["q_expl_2"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Bersedia dimutasikan": rawData\["q_3"\] \? \(rawData\["q_3"\] \+ \(rawData\["q_expl_3"\] \? \` - \$\{rawData\["q_expl_3"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Memiliki pekerjaan sampingan": rawData\["q_4"\] \? \(rawData\["q_4"\] \+ \(rawData\["q_expl_4"\] \? \` - \$\{rawData\["q_expl_4"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Mempunyai teman\/sanak saudara di perusahaan ini": rawData\["q_5"\] \? \(rawData\["q_5"\] \+ \(rawData\["q_expl_5"\] \? \` - \$\{rawData\["q_expl_5"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Pernah menderita sakit kronis \/ kecelakaan": rawData\["q_6"\] \? \(rawData\["q_6"\] \+ \(rawData\["q_expl_6"\] \? \` - \$\{rawData\["q_expl_6"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Sedang hamil": rawData\["q_7"\] \? \(rawData\["q_7"\] \+ \(rawData\["q_expl_7"\] \? \` - \$\{rawData\["q_expl_7"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Bersedia tidak hamil dalam 1 tahun": rawData\["q_8"\] \? \(rawData\["q_8"\] \+ \(rawData\["q_expl_8"\] \? \` - \$\{rawData\["q_expl_8"\]\}\` : ""\)\) : "-",\s*"Kuesioner - Bersedia ditempatkan di luar kota": rawData\["q_9"\] \? \(rawData\["q_9"\] \+ \(rawData\["q_expl_9"\] \? \` - \$\{rawData\["q_expl_9"\]\}\` : ""\)\) : "-",/;

code = code.replace(payloadRegex, '"Jawaban Kuesioner (1-10)": serializeKuesionerTable(),\n');

fs.writeFileSync('src/pages/FormPage.tsx', code);
