const fs = require('fs');
let code = fs.readFileSync('src/pages/DashboardPage.tsx', 'utf8');

// Remove activeTab === 'edit' header and sidebar link
code = code.replace(/<div onClick=\{\(\) => setActiveTab\('edit'\)\}.*?<\/div>/s, '');
code = code.replace(/\{activeTab === 'edit' && 'Edit Data Master'\}/, '');

// Remove the whole edit tab block
// Note: We'll use a regex that matches {activeTab === 'edit' && ( ... )}
const editTabRegex = /\{activeTab === 'edit' && \(\s*<div className="bg-white p-6 rounded shadow-sm border border-gray-200 max-w-6xl">.*?\}\)/s;
code = code.replace(editTabRegex, '');

// Fix 'Riwayat Pendidikan Formal ' -> 'Riwayat Pendidikan Formal'
code = code.replace(/'Riwayat Pendidikan Formal '/g, "'Riwayat Pendidikan Formal'");

// Make activeEduLevels dynamic
// We need to remove: const activeEduLevels = ['SD', 'SLTP', 'SLTA/SMU', 'D1/D2/D3', 'S1', 'S2/S3'];
// And replace with a memoized extraction.
const activeEduLevelsReplacement = `
  const activeEduLevels = useMemo(() => {
     const levels = new Set<string>();
     applicants.forEach(app => {
        const eduText = app.rawData?.['Riwayat Pendidikan Formal'];
        if (eduText) {
            const rows = eduText.split('\\n');
            // Assuming header is first row if it starts with 'Tingkat'
            rows.forEach((row: string) => {
               const cols = row.split(' | ');
               if (cols.length >= 4 && cols[0] !== 'Tingkat') {
                   const level = cols[0].trim();
                   if (level && level !== '-') levels.add(level);
               }
            });
        }
     });
     return Array.from(levels).sort();
  }, [applicants]);

  const activeJurusanList = useMemo(() => {
     const jurusan = new Set<string>();
     applicants.forEach(app => {
        const eduText = app.rawData?.['Riwayat Pendidikan Formal'];
        if (eduText) {
            const rows = eduText.split('\\n');
            rows.forEach((row: string) => {
               const cols = row.split(' | ');
               if (cols.length >= 4 && cols[3] !== 'Jurusan') {
                   const jur = cols[3].trim();
                   if (jur && jur !== '-') jurusan.add(jur);
               }
            });
        }
     });
     return Array.from(jurusan).sort();
  }, [applicants]);

  const skillList = useMemo(() => {
     const skills = new Set<string>();
     applicants.forEach(app => {
        const skillText = app.rawData?.['Teknikal / Hardskill'];
        if (skillText && skillText !== '-') {
            skillText.split(',').forEach((s: string) => {
                const trimmed = s.trim();
                if (trimmed) skills.add(trimmed);
            });
        }
     });
     return Array.from(skills).sort();
  }, [applicants]);
`;

code = code.replace(/const activeEduLevels = \['SD', 'SLTP', 'SLTA\/SMU', 'D1\/D2\/D3', 'S1', 'S2\/S3'\];/, activeEduLevelsReplacement);

// Remove the useState for skillList and newSkill
code = code.replace(/const \[skillList, setSkillList\][^;]+;/g, '');
code = code.replace(/const \[newSkill, setNewSkill\][^;]+;/g, '');

// Now fix the input for "Jurusan" inside the filter modal to be a dropdown
// Original: 
// <input 
//    type="text"
//    placeholder="Min. ketik kata kunci..."
//    value={ef.jurusan}
//    onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))}
//    className="border-gray-200 rounded px-2 py-1 text-sm outline-none w-full bg-white mt-1 border"
// />
const inputJurusanRegex = /<input[^>]+value=\{ef.jurusan\}[^>]+onChange=\{\(e\) => setEduFilters\(eduFilters\.map\(\(f, i\) => i === idx \? \{\.\.\.f, jurusan: e\.target\.value\} : f\)\)\}[^>]+>/s;

const jurusanSelect = `<select
   value={ef.jurusan}
   onChange={(e) => setEduFilters(eduFilters.map((f, i) => i === idx ? {...f, jurusan: e.target.value} : f))}
   className="border-gray-200 rounded px-2 py-1.5 text-sm outline-none w-full bg-white mt-1 border"
>
   <option value="">Semua Jurusan</option>
   {activeJurusanList.map(jur => <option key={jur} value={jur}>{jur}</option>)}
</select>`;

code = code.replace(inputJurusanRegex, jurusanSelect);

fs.writeFileSync('src/pages/DashboardPage.tsx', code);
