fetch('https://sheetdb.io/api/v1/g6pseexgmqoyq/No%20HP%20%2F%20Telp%20Dalam%20Kota/131141111111111', {method: 'DELETE'})
  .then(r=>r.json())
  .then(console.log);
