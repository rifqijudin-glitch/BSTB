const fs = require('fs');
let code = fs.readFileSync('src/pages/FormPage.tsx', 'utf8');

const replacement = `         };

        const sigCanvasObj = formRef.current?.querySelector('.signature-canvas') as HTMLCanvasElement;
        let signatureBase64 = "-";
        try {
            if (sigCanvasObj) {
                signatureBase64 = sigCanvasObj.toDataURL('image/png');
            }
        } catch (e) {
            console.error(e);
        }

         const payload = {`;

code = code.replace("         };\n\n         const payload = {", replacement);
fs.writeFileSync('src/pages/FormPage.tsx', code);
